# Kế Hoạch Triển Khai: Tự Tải Ảnh, Lưu Trữ Vĩnh Viễn & Hoàn Thiện Nhận Diện CLB (ĐÃ HOÀN THÀNH ✓)

Cập nhật tính năng tải ảnh trực tiếp từ máy (avatar, bìa bài viết, ảnh locket), cơ chế bảo tồn dữ liệu vĩnh cửu qua các bản build với công cụ backup JSON cho BCN, tinh chỉnh hiệu ứng Dynamic Island mở thẳng khung vuông bo góc mượt mà, và chuẩn hóa thông tin chân trang theo bản sắc Hội sinh viên Trường Đại học An Giang.

## User Review & Critical Decisions

> [!IMPORTANT]
> **Quyết định đã thống nhất qua khảo sát:**
> 1. **Tải ảnh từ thiết bị:** Tích hợp bộ chọn tệp hình ảnh trực tiếp (`<input type="file" accept="image/*">`) với bộ nén và chuyển đổi DataURL/Base64 tức thì tại cả 3 vị trí: Đăng ký thành viên (Avatar), Đăng bài viết / Tản văn (Ảnh bìa), và Đăng khoảnh khắc Locket.
> 2. **Bảo tồn dữ liệu:** Toàn bộ dữ liệu (thành viên, kế hoạch, thu chi, báo cáo, bài viết, locket) tự động cập nhật liên tục vào cả `data/club_db.json` và `data/seed.json`. Đồng thời bổ sung nút **"Tải về file dự phòng (JSON)"** và **"Khôi phục từ file JSON"** trong BCN Command Center.
> 3. **Chân trang nhận diện:** Dòng chữ khẩu hiệu đổi thành *"Định vị tư duy, bản lĩnh tri thức"*, địa điểm giữ *"Trường Đại học An Giang"*, thương hiệu chia làm 2 dòng: dòng trên nhỏ ghi *"Hội sinh viên Trường Đại học An Giang"*, dòng dưới ghi *"Câu lạc bộ Đọc và Giới thiệu sách"*.
> 4. **Dynamic Island:** Loại bỏ bước chuyển đổi qua khung oval trung gian giật cục; khi bấm mở sẽ bung trực tiếp ra khung vuông bo góc (`rounded-3xl`) mượt mà, tự nhiên.

---

## 1. Tổng Quan & Trải Nghiệm Cốt Lõi

- **Đối tượng sử dụng:** Toàn thể sinh viên thành viên CLB Đọc và Giới thiệu sách cùng Ban Chủ Nhiệm (BCN) Hội sinh viên Trường Đại học An Giang.
- **Giá trị cốt lõi:**
  - Người dùng có thể dùng chính hình chụp thật từ điện thoại / máy tính để làm avatar, đăng ảnh chụp trang sách tản văn hoặc khoảnh khắc Locket mà không cần phải dán link ảnh URL từ bên ngoài.
  - Toàn bộ dữ liệu thành viên, sổ thu chi quỹ, kế hoạch đề án và các bài viết được lưu trữ chắc chắn qua các lần update của AI Studio, đi kèm công cụ xuất nhập JSON dự phòng.
  - Nhận diện thương hiệu trang trọng, đúng chuẩn chỉ đạo của Hội sinh viên Trường ĐH An Giang với slogan mới đầy nhiệt huyết: *"Định vị tư duy, bản lĩnh tri thức"*.

---

## 2. Thiết Kế Trực Quan & Luồng Trải Nghiệm

### A. Tải ảnh từ thiết bị
- **Giao diện tải ảnh:** Cung cấp khu vực kéo thả hoặc nút bấm *"Tải ảnh từ thiết bị"* kèm icon máy ảnh / upload trực quan.
- **Xem trước tức thì (Preview):** Hiển thị ngay ảnh vừa chọn, cho phép đổi ảnh khác hoặc gỡ bỏ trước khi đăng.
- **Tối ưu dung lượng:** Tự động điều chỉnh kích thước và nén ảnh mượt mà để lưu trữ đồng bộ tốc độ cao trên toàn hệ thống đa máy.

### B. Dynamic Island thế hệ mới
- **Trạng thái đóng:** Viên ngọc sách nhỏ gọn, tinh tế trên đỉnh trang.
- **Trạng thái mở:** Khi chạm mở, phần tử bung mở thẳng trực tiếp thành khung hộp bo góc thanh thoát (`rounded-3xl`), loại bỏ hoàn toàn cảm giác co giật qua lại giữa hình oval và hình chữ nhật lớn.

### C. Chân trang chuẩn nhận diện ĐH An Giang
- **Cấu trúc 2 dòng thương hiệu:**
  - Dòng 1 (nhỏ hơn, chữ hoa trang trọng): `HỘI SINH VIÊN TRƯỜNG ĐẠI HỌC AN GIANG`
  - Dòng 2 (to bản, font chữ có chân vintage): `Câu Lạc Bộ Đọc và Giới Thiệu Sách`
- **Khẩu hiệu mới:** `Định vị tư duy, bản lĩnh tri thức`
- **Địa điểm:** `Trường Đại học An Giang - ĐHQG-HCM`

---

## 3. Quyết Định Kỹ Thuật & Kiến Trúc Dữ Liệu

```
┌────────────────────────────────────────────────────────┐
│               THIẾT BỊ NGƯỜI DÙNG                      │
│   (Điện thoại / Laptop / Máy tính bảng sinh viên)      │
└───────────────────────────┬────────────────────────────┘
                            │
               Tải ảnh thật / Lưu dữ liệu
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│                  FRONTEND (REACT)                      │
│  - ImagePicker (File input -> FileReader Base64)       │
│  - DynamicIsland (Transition trực tiếp rounded-3xl)    │
│  - BcnCommandCenter (Công cụ Backup & Restore JSON)    │
│  - Footer chuẩn nhận diện Hội Sinh Viên AGU            │
└───────────────────────────┬────────────────────────────┘
                            │
           POST /api/backup, /api/restore, /api/*
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│             EXPRESS BACKEND (server.ts)                │
│  - Tự động ghi đồng thời 2 file trên đĩa cứng:         │
│      1. /data/club_db.json (Active Database)           │
│      2. /data/seed.json (Permanent Baseline Seed)      │
│  - Endpoint /api/backup-download & /api/restore-upload │
└────────────────────────────────────────────────────────┘
```

- **Cơ chế chống mất dữ liệu khi cập nhật AI:**
  - Mỗi khi có bất kỳ thay đổi nào (thêm thành viên, viết bài, thu chi, kế hoạch), `server.ts` lập tức đồng bộ sang cả `seed.json`. Do đó, ngay cả khi AI Studio cập nhật lại bản build, `seed.json` đã chứa 100% dữ liệu mới nhất.
  - Bổ sung 2 endpoint chuyên dụng:
    - `GET /api/backup/download`: Xuất toàn bộ dữ liệu hệ thống thành file `agu_club_backup.json` tải về máy BCN.
    - `POST /api/backup/restore`: Cho phép BCN tải file JSON lên để khôi phục toàn bộ hệ thống bất cứ lúc nào chỉ bằng 1 cú nhấp chuột.

---

## 4. Kế Hoạch Triển Khai Chi Tiết

1. **Backend (`server.ts`):**
   - Bổ sung endpoint sao lưu dữ liệu `GET /api/backup/export` và nạp phục hồi `POST /api/backup/import`.
   - Nâng giới hạn kích thước nhận JSON lên `25mb` để hỗ trợ tải ảnh base64 sắc nét.
   - Bảo đảm hàm `persistDb` luôn đồng bộ sang cả `seed.json`.
2. **Thành phần tải ảnh (`src/components/ImageUploader.tsx` hoặc tích hợp trực tiếp):**
   - Hỗ trợ tải tệp ảnh từ máy, nén tự động và tạo ảnh xem trước (Preview) ở cả 3 khu vực:
     - Form đăng ký thành viên mới (`InitialAuthGate.tsx`).
     - Form đăng bài tản văn / E-News / Góc sách (`NewfeedSection.tsx`).
     - Form đăng khoảnh khắc Locket (`NewfeedSection.tsx`).
3. **Chân trang (`src/App.tsx` & footer):**
   - Điều chỉnh cấu trúc hiển thị 2 dòng: *"Hội sinh viên Trường Đại học An Giang"* và *"Câu lạc bộ Đọc và Giới thiệu sách"*.
   - Đổi khẩu hiệu thành: *"Định vị tư duy, bản lĩnh tri thức"*.
   - Khẳng định địa điểm *"Trường Đại học An Giang"*.
4. **Dynamic Island (`src/components/DynamicIsland.tsx`):**
   - Tinh chỉnh CSS animation và transition: mở trực tiếp ra khung vuông bo tròn `rounded-3xl` mượt mà, loại bỏ hiệu ứng oval trung gian.
5. **Công cụ Sao lưu & Khôi phục BCN (`BcnCommandCenter.tsx`):**
   - Thêm nút tải file JSON sao lưu dự phòng và nút chọn file JSON khôi phục dữ liệu an toàn.
6. **Kiểm thử & Biên dịch:**
   - Kiểm tra `compile_applet` và `lint_applet` đảm bảo ứng dụng chạy mượt mà, không lỗi cú pháp.
