import React, { useState } from 'react';
import { 
  UserPlus, 
  Sparkles, 
  Link as LinkIcon, 
  CheckCircle2, 
  XCircle, 
  Plus, 
  Trash2, 
  Copy, 
  ExternalLink, 
  HelpCircle, 
  Check, 
  Send, 
  Clock, 
  Filter, 
  Eye, 
  FileText,
  Crown,
  Share2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  RecruitmentQuestion, 
  RecruitmentApplication, 
  UserProfile, 
  DepartmentType 
} from '../types';

interface RecruitmentSectionProps {
  currentUser: UserProfile;
  isMasterRoot: boolean;
  questions: RecruitmentQuestion[];
  applications: RecruitmentApplication[];
  onAddQuestion: (q: Omit<RecruitmentQuestion, 'id'>) => void;
  onDeleteQuestion: (id: string) => void;
  onSubmitApplication: (app: Omit<RecruitmentApplication, 'id' | 'status' | 'submittedAt'>) => void;
  onReviewApplication: (appId: string, status: 'approved' | 'rejected', notes: string) => void;
}

export const RecruitmentSection: React.FC<RecruitmentSectionProps> = ({
  currentUser,
  isMasterRoot,
  questions,
  applications,
  onAddQuestion,
  onDeleteQuestion,
  onSubmitApplication,
  onReviewApplication
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'review' | 'builder' | 'candidate_form'>('review');
  const [copiedLink, setCopiedLink] = useState(false);
  const [filterDept, setFilterDept] = useState<string>('all');
  const [selectedApp, setSelectedApp] = useState<RecruitmentApplication | null>(null);
  const [reviewNoteInput, setReviewNoteInput] = useState('');

  // Form states for creating new question
  const [newQText, setNewQText] = useState('');
  const [newQType, setNewQType] = useState<'multiple_choice' | 'short_answer'>('short_answer');
  const [newQOptions, setNewQOptions] = useState('Lựa chọn A, Lựa chọn B, Lựa chọn C');

  // Candidate submission test form
  const [candName, setCandName] = useState('');
  const [candNickname, setCandNickname] = useState('');
  const [candStudentId, setCandStudentId] = useState('');
  const [candFaculty, setCandFaculty] = useState('Khoa Sư phạm');
  const [candEmail, setCandEmail] = useState('');
  const [candPhone, setCandPhone] = useState('');
  const [candDept, setCandDept] = useState<DepartmentType>('Nội dung');
  const [candAnswers, setCandAnswers] = useState<Record<string, string>>({});

  const recruitmentShareUrl = `${window.location.origin}/tuyen-thanh-vien-k26`;

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(recruitmentShareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleCreateQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQText.trim()) return;

    onAddQuestion({
      text: newQText.trim(),
      type: newQType,
      options: newQType === 'multiple_choice' 
        ? newQOptions.split(',').map(s => s.trim()).filter(Boolean) 
        : undefined,
      required: true
    });

    setNewQText('');
    confetti({ particleCount: 40, spread: 50, origin: { y: 0.5 } });
  };

  const handleCandidateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!candName.trim() || !candStudentId.trim()) return;

    onSubmitApplication({
      fullName: candName.trim(),
      nickname: candNickname.trim() || undefined,
      studentId: candStudentId.toUpperCase().trim(),
      faculty: candFaculty,
      email: candEmail || `${candStudentId.toLowerCase()}@agu.edu.vn`,
      phone: candPhone || '09xx.xxx.xxx',
      desiredDept: candDept,
      answers: candAnswers
    });

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.5 },
      colors: ['#3B6E47', '#6AD5A1', '#F59E0B']
    });

    alert('Đã gửi đơn sơ tuyển thành công! Ban Chủ Nhiệm sẽ chấm hồ sơ và phản hồi sớm nhất.');
    setCandName('');
    setCandNickname('');
    setCandStudentId('');
    setCandAnswers({});
    setActiveSubTab('review');
  };

  const handleApprove = (app: RecruitmentApplication) => {
    onReviewApplication(app.id, 'approved', reviewNoteInput || 'Đạt yêu cầu sơ tuyển! Chúc mừng bạn chính thức trở thành thành viên CLB.');
    setSelectedApp(null);
    setReviewNoteInput('');
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.4 } });
  };

  const handleReject = (app: RecruitmentApplication) => {
    onReviewApplication(app.id, 'rejected', reviewNoteInput || 'Hồ sơ chưa phù hợp trong đợt này. Hẹn gặp lại bạn vào đợt tuyển mùa sau nhé!');
    setSelectedApp(null);
    setReviewNoteInput('');
  };

  const filteredApps = applications.filter(a => filterDept === 'all' || a.desiredDept === filterDept);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Exclusive Header Banner */}
      <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-[#19321E] via-[#24482B] to-[#36683E] text-white border-2 border-amber-400 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold border border-amber-400/40">
              <Crown className="w-3.5 h-3.5" />
              <span>Chức Năng Ẩn Độc Quyền • Cổng Tuyển Thành Viên CLB</span>
            </div>
            
            <h2 className="text-xl sm:text-2xl font-bold font-serif-vintage tracking-tight">
              Quản Trị & Xét Duyệt Đơn Tuyển Thành Viên Mới
            </h2>
            
            <p className="text-xs text-emerald-100/90 leading-relaxed">
              Chỉ <strong>Tài khoản chính (Câu lạc bộ Đọc và Giới thiệu sách)</strong> và <strong>3 Chủ nhiệm nhiệm kỳ</strong> mới có quyền truy cập. Tạo bộ câu hỏi trắc nghiệm / tự luận ngắn, sinh link nộp đơn, và duyệt hồ sơ sơ tuyển ứng viên trực tiếp.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleCopyLink}
              className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-900 text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm cursor-pointer transition bubble-3d"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-800" /> : <Copy className="w-4 h-4" />}
              <span>{copiedLink ? 'Đã copy link tuyển!' : 'Copy Link Tuyển Dụng'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveSubTab('candidate_form')}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/30 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Thử Nộp Đơn (Test Form)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-2 border-b border-[#DCD1BE] pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveSubTab('review')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap ${
            activeSubTab === 'review'
              ? 'bg-[#23432B] text-white shadow-xs'
              : 'bg-white text-[#4A6450] hover:bg-[#F2ECE0] border border-[#D5CBBC]'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Danh Sách Đơn Sơ Tuyển ({applications.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('builder')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap ${
            activeSubTab === 'builder'
              ? 'bg-[#23432B] text-white shadow-xs'
              : 'bg-white text-[#4A6450] hover:bg-[#F2ECE0] border border-[#D5CBBC]'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>Thiết Lập Bộ Câu Hỏi ({questions.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('candidate_form')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap ${
            activeSubTab === 'candidate_form'
              ? 'bg-[#23432B] text-white shadow-xs'
              : 'bg-white text-[#4A6450] hover:bg-[#F2ECE0] border border-[#D5CBBC]'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          <span>Xem Trước Form Nộp Đơn Ứng Viên</span>
        </button>
      </div>

      {/* SUB-TAB 1: Review Applications */}
      {activeSubTab === 'review' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-[#DED4C3]">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#23432B]">Lọc theo Ban ứng tuyển:</span>
              <select
                value={filterDept}
                onChange={(e) => setFilterDept(e.target.value)}
                className="px-2.5 py-1 rounded-lg border border-[#C5BCAB] bg-[#FAF8F2] text-xs font-medium"
              >
                <option value="all">Tất cả các ban ({applications.length})</option>
                <option value="Truyền thông">Ban Truyền thông</option>
                <option value="Nội dung">Ban Nội dung</option>
                <option value="Nhân sự & Kế hoạch">Ban Nhân sự & Kế hoạch</option>
                <option value="Hậu cần">Ban Hậu cần</option>
              </select>
            </div>

            <div className="text-xs text-[#5E7A63]">
              Số lượng: <strong>{filteredApps.length}</strong> đơn đăng ký sơ tuyển
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3.5">
            {filteredApps.map((app) => (
              <div
                key={app.id}
                className="bg-white p-4 sm:p-5 rounded-2xl border border-[#DED4C3] shadow-xs space-y-3 hover:border-[#8BAE90] transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-[#EFE8DA]">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="font-bold text-sm text-[#23432B]">
                      {app.fullName}
                    </span>
                    {app.nickname && (
                      <span className="text-xs text-amber-700 italic font-semibold">
                        ({app.nickname})
                      </span>
                    )}
                    <span className="text-[10px] font-mono bg-stone-100 px-2 py-0.5 rounded text-stone-600">
                      {app.studentId}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E5F0E4] text-[#2C5734]">
                      Nguyện vọng: {app.desiredDept}
                    </span>
                    <span className="text-[10px] text-stone-400">
                      • {app.faculty}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                      app.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                        : app.status === 'rejected'
                        ? 'bg-rose-100 text-rose-800 border-rose-300'
                        : 'bg-amber-100 text-amber-800 border-amber-300'
                    }`}>
                      {app.status === 'approved' && '✓ Đã Phê Duyệt Tuyển Dụng'}
                      {app.status === 'rejected' && '✕ Đã Từ Chối'}
                      {app.status === 'pending' && '⏳ Chờ BCN Chấm Sơ Tuyển'}
                    </span>
                    <span className="text-[10px] text-stone-400">Nộp: {app.submittedAt}</span>
                  </div>
                </div>

                {/* Answers list */}
                <div className="space-y-2 bg-[#FAF7F0] p-3 rounded-xl border border-[#E9E1CE] text-xs">
                  <div className="font-bold text-[#23432B] text-[11px] uppercase tracking-wide">
                    Câu trả lời sơ tuyển của ứng viên:
                  </div>

                  {questions.map((q) => (
                    <div key={q.id} className="text-xs space-y-0.5 pl-1 border-l-2 border-[#5E936B]/60">
                      <div className="font-semibold text-[#1F3D26]">{q.text}</div>
                      <div className="text-[#3C5240] italic">
                        ↳ {app.answers[q.id] || '(Chưa trả lời)'}
                      </div>
                    </div>
                  ))}
                </div>

                {app.reviewNotes && (
                  <div className="p-2.5 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 text-xs">
                    <strong>Ghi chú từ BCN:</strong> {app.reviewNotes}
                  </div>
                )}

                {/* Review Action Controls */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-1 text-xs">
                  <input
                    type="text"
                    placeholder="Ghi nhận xét hoặc lời chúc mừng khi duyệt..."
                    value={selectedApp?.id === app.id ? reviewNoteInput : ''}
                    onChange={(e) => {
                      setSelectedApp(app);
                      setReviewNoteInput(e.target.value);
                    }}
                    className="flex-1 px-3 py-1.5 rounded-xl border border-[#D5CBBC] bg-white text-xs focus:ring-1 focus:ring-[#3B6E47]"
                  />

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      type="button"
                      onClick={() => handleReject(app)}
                      className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs cursor-pointer"
                    >
                      Từ Chối
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApprove(app)}
                      className="px-4 py-1.5 rounded-xl bg-[#2D5337] hover:bg-[#1E3B26] text-white font-bold text-xs shadow-xs bubble-3d flex items-center gap-1.5 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5 text-emerald-300" />
                      <span>Duyệt Nhận Vào CLB</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: Questions Builder */}
      {activeSubTab === 'builder' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Add Question Form */}
          <div className="bg-white p-5 rounded-2xl border border-[#DED4C3] shadow-xs space-y-3.5 text-xs">
            <div className="flex items-center gap-2">
              <Plus className="w-4 h-4 text-[#3B6E47]" />
              <h3 className="font-bold text-sm text-[#23432B] font-serif-vintage">
                Thêm Câu Hỏi Sơ Tuyển Mới
              </h3>
            </div>

            <form onSubmit={handleCreateQuestion} className="space-y-3">
              <div>
                <label className="block font-bold text-[#23432B] mb-1">Dạng câu hỏi *</label>
                <select
                  value={newQType}
                  onChange={(e) => setNewQType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-[#FAF8F2] text-xs"
                >
                  <option value="short_answer">Tự luận ngắn (Short answer)</option>
                  <option value="multiple_choice">Trắc nghiệm chọn lựa (Multiple choice)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Nội dung câu hỏi *</label>
                <textarea
                  rows={3}
                  required
                  value={newQText}
                  onChange={(e) => setNewQText(e.target.value)}
                  placeholder="Ví dụ: Bạn ấn tượng nhất với câu nói nào trong một cuốn sách bạn từng đọc?..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs"
                />
              </div>

              {newQType === 'multiple_choice' && (
                <div>
                  <label className="block font-bold text-[#23432B] mb-1">
                    Các lựa chọn (phân cách bằng dấu phẩy) *
                  </label>
                  <input
                    type="text"
                    value={newQOptions}
                    onChange={(e) => setNewQOptions(e.target.value)}
                    placeholder="Lựa chọn 1, Lựa chọn 2, Lựa chọn 3"
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs"
                  />
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-[#23432B] hover:bg-[#1A3320] text-white font-bold text-xs shadow-xs bubble-3d flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4 text-emerald-300" />
                <span>Thêm Vào Bộ Câu Hỏi Tuyển</span>
              </button>
            </form>
          </div>

          {/* Current Question List */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="font-bold text-sm text-[#23432B] font-serif-vintage">
              Danh Sách Câu Hỏi Trong Đơn Sơ Tuyển ({questions.length})
            </h4>

            <div className="space-y-2.5">
              {questions.map((q, idx) => (
                <div
                  key={q.id}
                  className="bg-white p-3.5 rounded-xl border border-[#DED4C3] flex items-start justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#E8F1E7] text-[#2C5734] font-bold flex items-center justify-center text-[10px]">
                        {idx + 1}
                      </span>
                      <span className="font-bold text-[#1F3D26] text-xs sm:text-sm">
                        {q.text}
                      </span>
                    </div>

                    <div className="pl-7 text-[11px] text-stone-500">
                      Loại: {q.type === 'multiple_choice' ? 'Trắc nghiệm' : 'Tự luận ngắn'}
                      {q.options && ` • Tùy chọn: [${q.options.join(', ')}]`}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onDeleteQuestion(q.id)}
                    className="p-1 rounded-lg hover:bg-rose-50 text-stone-400 hover:text-rose-600 cursor-pointer transition"
                    title="Xóa câu hỏi"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: Candidate Preliminary Form (Xem Trước / Nộp Thử) */}
      {activeSubTab === 'candidate_form' && (
        <div className="max-w-2xl mx-auto bg-white p-6 rounded-2xl border border-[#DED4C3] shadow-md space-y-5 text-xs">
          <div className="text-center space-y-1 pb-3 border-b border-[#EFE8DA]">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#3B6E47] bg-[#E8F1E7] px-2.5 py-0.5 rounded-full">
              Đơn Đăng Ký Sơ Tuyển Mùa K26
            </span>
            <h3 className="text-xl font-bold font-serif-vintage text-[#1F3D26]">
              Gia Nhập CLB Đọc Và Giới Thiệu Sách
            </h3>
            <p className="text-xs text-[#526B57]">
              Hãy điền thông tin sơ tuyển dưới đây để Ban Chủ Nhiệm liên hệ phỏng vấn và chào đón bạn!
            </p>
          </div>

          <form onSubmit={handleCandidateSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-[#23432B] mb-1">Họ và tên của bạn *</label>
                <input
                  type="text"
                  required
                  value={candName}
                  onChange={(e) => setCandName(e.target.value)}
                  placeholder="Ví dụ: Trần Minh Thư"
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-[#FAF8F2] text-xs focus:ring-1 focus:ring-[#3B6E47]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Bút danh / Nickname yêu thích</label>
                <input
                  type="text"
                  value={candNickname}
                  onChange={(e) => setCandNickname(e.target.value)}
                  placeholder="Ví dụ: Thư Mọt Sách 📚"
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-[#FAF8F2] text-xs focus:ring-1 focus:ring-[#3B6E47]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-[#23432B] mb-1">Mã số sinh viên *</label>
                <input
                  type="text"
                  required
                  value={candStudentId}
                  onChange={(e) => setCandStudentId(e.target.value)}
                  placeholder="Ví dụ: DTH243912"
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-[#FAF8F2] font-mono text-xs focus:ring-1 focus:ring-[#3B6E47]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Khoa / Ngành học</label>
                <input
                  type="text"
                  value={candFaculty}
                  onChange={(e) => setCandFaculty(e.target.value)}
                  placeholder="Khoa Sư phạm / Ngoại ngữ / CNTT..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-[#FAF8F2] text-xs focus:ring-1 focus:ring-[#3B6E47]"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-[#23432B] mb-1">Ban chuyên môn muốn ứng tuyển *</label>
              <select
                value={candDept}
                onChange={(e) => setCandDept(e.target.value as DepartmentType)}
                className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs font-bold text-[#1F3D26]"
              >
                <option value="Truyền thông">Ban Truyền thông (Thiết kế poster, viết E-News, TikTok)</option>
                <option value="Nội dung">Ban Nội dung (Biên tập sách, kịch bản đàm đạo văn học)</option>
                <option value="Nhân sự & Kế hoạch">Ban Nhân sự & Kế hoạch (Lên plan, tổ chức, SV5T)</option>
                <option value="Hậu cần">Ban Hậu cần (Quản lý tủ sách, âm thanh, quà tặng)</option>
              </select>
            </div>

            {/* Render dynamic question fields */}
            <div className="pt-2 border-t border-[#EFE8DA] space-y-3.5">
              <span className="font-bold text-[#1F3D26] text-xs uppercase tracking-wide block">
                Phần Trả Lời Câu Hỏi Sơ Tuyển:
              </span>

              {questions.map((q, idx) => (
                <div key={q.id} className="space-y-1.5">
                  <label className="block font-semibold text-[#23432B]">
                    {idx + 1}. {q.text} {q.required && <span className="text-rose-600">*</span>}
                  </label>

                  {q.type === 'multiple_choice' && q.options ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {q.options.map((opt) => (
                        <div
                          key={opt}
                          onClick={() => setCandAnswers(prev => ({ ...prev, [q.id]: opt }))}
                          className={`p-2 rounded-xl border text-xs cursor-pointer transition ${
                            candAnswers[q.id] === opt 
                              ? 'bg-[#E8F1E7] border-[#3B6E47] font-bold text-[#1F3D26]' 
                              : 'bg-white border-[#DCD1BF] text-stone-600 hover:border-emerald-300'
                          }`}
                        >
                          {opt}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <textarea
                      rows={2}
                      required={q.required}
                      value={candAnswers[q.id] || ''}
                      onChange={(e) => setCandAnswers(prev => ({ ...prev, [q.id]: e.target.value }))}
                      placeholder="Nhập câu trả lời của bạn..."
                      className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-[#FAF8F2] text-xs focus:ring-1 focus:ring-[#3B6E47]"
                    />
                  )}
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-[#EFE8DA] flex items-center justify-end gap-2.5">
              <button
                type="submit"
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-[#2D5337] hover:bg-[#1E3B26] text-white font-bold text-xs shadow-md bubble-3d flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4 text-emerald-300" />
                <span>Nộp Đơn Đăng Ký Sơ Tuyển</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
