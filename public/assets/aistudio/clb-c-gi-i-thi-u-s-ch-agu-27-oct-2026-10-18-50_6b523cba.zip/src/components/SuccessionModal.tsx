import React, { useState } from 'react';
import { 
  Crown, 
  Sparkles, 
  UserCheck, 
  X, 
  ArrowRight, 
  CheckCircle2, 
  ShieldCheck, 
  Archive,
  Search,
  Users2,
  Medal,
  HelpCircle,
  Check,
  AlertTriangle,
  HeartHandshake
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UserProfile, HallOfFameItem } from '../types';

export interface SuccessionTransferPayload {
  targetPositionKey: 'lead' | 'vice1' | 'vice2';
  positionTitle: string;
  outgoingLeader: UserProfile;
  incomingMemberId: string;
  isNewCustomMember: boolean;
  newCustomInfo?: {
    name: string;
    nickname: string;
    studentId: string;
    faculty: string;
    favoriteBook: string;
  };
  hallOfFameRecord: HallOfFameItem;
  termStructure: '2_members' | '3_members';
}

interface SuccessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  bcnAccounts: UserProfile[];
  userList: UserProfile[];
  currentOperator: UserProfile;
  onTransferSuccession: (payload: SuccessionTransferPayload) => void;
}

export const SuccessionModal: React.FC<SuccessionModalProps> = ({
  isOpen,
  onClose,
  bcnAccounts,
  userList,
  currentOperator,
  onTransferSuccession
}) => {
  // Structure: 2 members (Chủ nhiệm + 1 Phó chủ nhiệm) OR 3 members (Chủ nhiệm + 2 Phó chủ nhiệm)
  const [termStructure, setTermStructure] = useState<'2_members' | '3_members'>('3_members');

  // Selected position to hand over
  const [selectedPositionKey, setSelectedPositionKey] = useState<'lead' | 'vice1' | 'vice2'>('lead');

  // Mode of picking incoming leader: 'from_list' (đích danh) OR 'custom' (nhập mới)
  const [incomingMode, setIncomingMode] = useState<'from_list' | 'custom'>('from_list');

  // Selected member from userList (nominated successor)
  const [nominatedMemberId, setNominatedMemberId] = useState<string>('');
  const [searchMemberQuery, setSearchMemberQuery] = useState('');

  // Legacy details for outgoing leader
  const [legacyContributions, setLegacyContributions] = useState('');
  const [legacyQuote, setLegacyQuote] = useState('');
  const [termYears, setTermYears] = useState('2025 - 2026');

  // Custom new leader info (if not selecting existing member)
  const [customName, setCustomName] = useState('');
  const [customNickname, setCustomNickname] = useState('');
  const [customStudentId, setCustomStudentId] = useState('');
  const [customFaculty, setCustomFaculty] = useState('Khoa Sư phạm - Ngữ Văn K23');
  const [customFavoriteBook, setCustomFavoriteBook] = useState('Chiến Binh Cầu Vồng');

  if (!isOpen) return null;

  // Identify elected accounts for Lead, Vice 1, Vice 2
  const electedAccounts = bcnAccounts.filter(a => a.adminType === 'bcn_elected');
  const currentLead = electedAccounts.find(a => a.position.toLowerCase().includes('chủ nhiệm clb') && !a.position.toLowerCase().includes('phó')) || electedAccounts[0];
  const currentVice1 = electedAccounts.find(a => a.id === 'bcn-lead-2' || a.position.toLowerCase().includes('học thuật') || a.position.toLowerCase().includes('nội dung')) || electedAccounts[1];
  const currentVice2 = electedAccounts.find(a => a.id === 'bcn-lead-3' || a.position.toLowerCase().includes('phong trào') || a.position.toLowerCase().includes('kế hoạch')) || electedAccounts[2];

  // Outgoing leader mapped to currently selected position
  let outgoingLeader: UserProfile | undefined;
  let targetPositionTitle = 'Chủ nhiệm CLB (Sinh viên)';

  if (selectedPositionKey === 'lead') {
    outgoingLeader = currentLead;
    targetPositionTitle = 'Chủ nhiệm CLB (Sinh viên)';
  } else if (selectedPositionKey === 'vice1') {
    outgoingLeader = currentVice1;
    targetPositionTitle = 'Phó Chủ nhiệm Học thuật & Nội dung';
  } else {
    outgoingLeader = currentVice2;
    targetPositionTitle = 'Phó Chủ nhiệm Phong trào & Kế hoạch';
  }

  // Filter available members to nominate (exclude root account and the current leader)
  const eligibleMembers = userList.filter(u => {
    if (u.adminType === 'master_root') return false;
    if (outgoingLeader && u.id === outgoingLeader.id) return false;
    if (!searchMemberQuery.trim()) return true;
    const q = searchMemberQuery.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      (u.nickname && u.nickname.toLowerCase().includes(q)) ||
      u.studentId.toLowerCase().includes(q) ||
      u.department.toLowerCase().includes(q)
    );
  });

  const selectedNominatedMember = userList.find(u => u.id === nominatedMemberId);

  const handleExecuteTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!outgoingLeader) return;

    if (incomingMode === 'from_list') {
      if (!nominatedMemberId || !selectedNominatedMember) {
        alert('Vui lòng chọn đích danh một thành viên từ danh sách để bàn giao chức vụ!');
        return;
      }
    } else {
      if (!customName.trim() || !customStudentId.trim()) {
        alert('Vui lòng nhập đầy đủ họ tên và mã số sinh viên của người kế nhiệm!');
        return;
      }
    }

    const hofItem: HallOfFameItem = {
      id: `hof-${Date.now()}`,
      name: outgoingLeader.name,
      nickname: outgoingLeader.nickname,
      studentId: outgoingLeader.studentId,
      title: `${outgoingLeader.position} (${outgoingLeader.term || 'Nhiệm kỳ vừa qua'})`,
      termYears: termYears.trim() || '2025 - 2026',
      bestContributions: legacyContributions.trim() || 'Hoàn thành xuất sắc nhiệm kỳ dẫn dắt CLB, duy trì chuỗi hoạt động E-News và gắn kết các ban.',
      avatar: outgoingLeader.avatar,
      legacyQuote: legacyQuote.trim() || 'Thanh xuân cùng CLB Đọc Sách là trang sách đẹp nhất của đời sinh viên.'
    };

    onTransferSuccession({
      targetPositionKey: selectedPositionKey,
      positionTitle: targetPositionTitle,
      outgoingLeader,
      incomingMemberId: incomingMode === 'from_list' ? nominatedMemberId : '',
      isNewCustomMember: incomingMode === 'custom',
      newCustomInfo: incomingMode === 'custom' ? {
        name: customName.trim(),
        nickname: customNickname.trim() || `${customName.split(' ').slice(-1)[0]} Trưởng Bản 👑`,
        studentId: customStudentId.toUpperCase().trim(),
        faculty: customFaculty,
        favoriteBook: customFavoriteBook.trim()
      } : undefined,
      hallOfFameRecord: hofItem,
      termStructure
    });

    confetti({
      particleCount: 120,
      spread: 90,
      origin: { y: 0.5 },
      colors: ['#F59E0B', '#10B981', '#3B82F6', '#8B5CF6']
    });

    const newLeaderName = incomingMode === 'from_list' ? selectedNominatedMember?.name : customName;
    alert(`Bàn giao đích danh vị trí "${targetPositionTitle}" cho bạn "${newLeaderName}" thành công! Dữ liệu của tiền bối "${outgoingLeader.name}" được bảo toàn trọn vẹn trong danh sách và vinh danh vĩnh viễn tại Bảo Tàng Thành Tựu.`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-[#FAF7F0] rounded-2xl border-2 border-amber-400 shadow-2xl w-full max-w-3xl max-h-[94vh] overflow-hidden flex flex-col">
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-[#172E1A] via-[#234527] to-[#2E5834] text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center border border-amber-400/40 shrink-0">
              <Crown className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold font-serif-vintage tracking-wide">
                  Bàn Giao Nhiệm Kỳ Đích Danh & Bảo Tồn Tiền Nhiệm
                </h3>
                <span className="bg-amber-400/30 text-amber-200 text-[10px] font-bold px-2 py-0.5 rounded border border-amber-300/40">
                  Quyền Quản Trị CLB
                </span>
              </div>
              <p className="text-xs text-emerald-100/80 mt-0.5">
                Chuyển giao chức vụ cho thành viên chỉ định • Thông tin người cũ được bảo lưu vĩnh viễn
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-white/80 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Policy Highlight Banner */}
        <div className="bg-[#EFE7D5] px-5 py-2.5 border-b border-[#D8CDB5] text-xs text-[#3E5C42] shrink-0">
          <div className="flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div className="space-y-0.5 text-[11px] leading-relaxed">
              <strong className="text-[#1D3B23]">Cam Kết Bảo Tồn Dữ Liệu 100%:</strong>
              <p>
                Khi thực hiện bàn giao, tài khoản của người cũ <strong>không bị mất đi</strong> mà vẫn tồn tại trong hệ thống dưới tư cách <em>"Cựu BCN (Tiền bối danh dự)"</em>. Toàn bộ chuỗi ngày, bài viết, và thành tựu được giữ trọn vẹn và vinh danh trang trọng tại <strong>Bảo Tàng Thành Tựu (Hall of Fame)</strong>.
              </p>
            </div>
          </div>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleExecuteTransfer} className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs">
          {/* Step 1: Select Term Structure (2 or 3 members) */}
          <div className="bg-white p-3.5 rounded-xl border border-[#D5CBBA]">
            <div className="flex items-center justify-between mb-2">
              <label className="font-bold text-[#1E3A24] flex items-center gap-1.5">
                <Users2 className="w-4 h-4 text-[#3B6E47]" />
                <span>1. Cơ cấu nhân sự Ban Chủ Nhiệm nhiệm kỳ mới:</span>
              </label>
              <span className="text-[11px] text-stone-500">
                (Tùy chỉnh linh hoạt theo số lượng nhân sự khóa mới)
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setTermStructure('2_members')}
                className={`p-2.5 rounded-xl border text-left cursor-pointer transition flex items-center gap-2.5 ${
                  termStructure === '2_members'
                    ? 'bg-[#E8F1E7] border-[#3B6E47] ring-1 ring-[#3B6E47] font-bold text-[#1E3A24]'
                    : 'bg-[#FAF7F0] border-[#DED4C3] text-stone-600 hover:border-emerald-300'
                }`}
              >
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                  termStructure === '2_members' ? 'border-[#3B6E47] bg-[#3B6E47] text-white' : 'border-stone-400'
                }`}>
                  {termStructure === '2_members' && <Check className="w-2.5 h-2.5" />}
                </div>
                <div>
                  <div className="font-bold text-xs">Nhiệm kỳ 2 người</div>
                  <div className="text-[10px] text-stone-500">1 Chủ nhiệm + 1 Phó chủ nhiệm</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setTermStructure('3_members')}
                className={`p-2.5 rounded-xl border text-left cursor-pointer transition flex items-center gap-2.5 ${
                  termStructure === '3_members'
                    ? 'bg-[#E8F1E7] border-[#3B6E47] ring-1 ring-[#3B6E47] font-bold text-[#1E3A24]'
                    : 'bg-[#FAF7F0] border-[#DED4C3] text-stone-600 hover:border-emerald-300'
                }`}
              >
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                  termStructure === '3_members' ? 'border-[#3B6E47] bg-[#3B6E47] text-white' : 'border-stone-400'
                }`}>
                  {termStructure === '3_members' && <Check className="w-2.5 h-2.5" />}
                </div>
                <div>
                  <div className="font-bold text-xs">Nhiệm kỳ 3 người (Tiêu chuẩn)</div>
                  <div className="text-[10px] text-stone-500">1 Chủ nhiệm + 2 Phó chủ nhiệm</div>
                </div>
              </button>
            </div>
          </div>

          {/* Step 2: Select position to transfer */}
          <div>
            <label className="block font-bold text-[#1E3A24] mb-1.5">
              2. Chọn vị trí muốn bàn giao đích danh:
            </label>
            <div className={`grid gap-2.5 ${termStructure === '2_members' ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1 sm:grid-cols-3'}`}>
              {/* Position: Lead */}
              <div
                onClick={() => setSelectedPositionKey('lead')}
                className={`p-3 rounded-xl border text-left cursor-pointer transition ${
                  selectedPositionKey === 'lead'
                    ? 'bg-[#E8F1E7] border-[#3B6E47] ring-2 ring-[#3B6E47]/40 shadow-xs'
                    : 'bg-white border-[#D6CBB8] hover:border-emerald-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-900 text-xs flex items-center gap-1">
                    <Crown className="w-3.5 h-3.5 text-amber-600" />
                    Chủ Nhiệm CLB
                  </span>
                  {selectedPositionKey === 'lead' && (
                    <span className="text-[10px] bg-emerald-700 text-white font-bold px-1.5 py-0.2 rounded">
                      Đang chọn
                    </span>
                  )}
                </div>
                <div className="text-[11px] font-semibold text-stone-800 mt-1 truncate">
                  Tiền nhiệm: {currentLead?.name || 'Đang chờ'}
                </div>
                <div className="text-[10px] text-stone-500">{currentLead?.studentId}</div>
              </div>

              {/* Position: Vice 1 */}
              <div
                onClick={() => setSelectedPositionKey('vice1')}
                className={`p-3 rounded-xl border text-left cursor-pointer transition ${
                  selectedPositionKey === 'vice1'
                    ? 'bg-[#E8F1E7] border-[#3B6E47] ring-2 ring-[#3B6E47]/40 shadow-xs'
                    : 'bg-white border-[#D6CBB8] hover:border-emerald-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-900 text-xs flex items-center gap-1">
                    <Medal className="w-3.5 h-3.5 text-emerald-600" />
                    Phó Chủ Nhiệm 1
                  </span>
                  {selectedPositionKey === 'vice1' && (
                    <span className="text-[10px] bg-emerald-700 text-white font-bold px-1.5 py-0.2 rounded">
                      Đang chọn
                    </span>
                  )}
                </div>
                <div className="text-[11px] font-semibold text-stone-800 mt-1 truncate">
                  Tiền nhiệm: {currentVice1?.name || 'Đang chờ'}
                </div>
                <div className="text-[10px] text-stone-500">Học thuật & Nội dung</div>
              </div>

              {/* Position: Vice 2 (if 3 members) */}
              {termStructure === '3_members' && (
                <div
                  onClick={() => setSelectedPositionKey('vice2')}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition ${
                    selectedPositionKey === 'vice2'
                      ? 'bg-[#E8F1E7] border-[#3B6E47] ring-2 ring-[#3B6E47]/40 shadow-xs'
                      : 'bg-white border-[#D6CBB8] hover:border-emerald-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sky-900 text-xs flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-sky-600" />
                      Phó Chủ Nhiệm 2
                    </span>
                    {selectedPositionKey === 'vice2' && (
                      <span className="text-[10px] bg-emerald-700 text-white font-bold px-1.5 py-0.2 rounded">
                        Đang chọn
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] font-semibold text-stone-800 mt-1 truncate">
                    Tiền nhiệm: {currentVice2?.name || 'Đang chờ'}
                  </div>
                  <div className="text-[10px] text-stone-500">Phong trào & Kế hoạch</div>
                </div>
              )}
            </div>
          </div>

          {/* Step 3: Preserving Outgoing Leader to Hall of Fame */}
          {outgoingLeader && (
            <div className="p-3.5 rounded-xl bg-amber-50/90 border border-amber-300/80 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-950 font-bold">
                  <Archive className="w-4 h-4 text-amber-700" />
                  <span>
                    Bảo Tồn & Vinh Danh Tiền Nhiệm: <span className="text-amber-800 font-extrabold">{outgoingLeader.name}</span>
                  </span>
                </div>
                <span className="text-[10px] bg-amber-200/80 text-amber-900 px-2 py-0.5 rounded font-mono font-bold">
                  {outgoingLeader.studentId}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-amber-950 mb-1 text-[11px]">
                    Đóng góp nổi bật trong nhiệm kỳ *
                  </label>
                  <input
                    type="text"
                    required
                    value={legacyContributions}
                    onChange={(e) => setLegacyContributions(e.target.value)}
                    placeholder="Ví dụ: Xây dựng không gian Tủ sách CLB và phát hành 12 số E-News..."
                    className="w-full px-3 py-1.5 rounded-lg border border-amber-300 bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-amber-950 mb-1 text-[11px]">
                    Khóa / Nhiệm kỳ
                  </label>
                  <input
                    type="text"
                    value={termYears}
                    onChange={(e) => setTermYears(e.target.value)}
                    placeholder="2025 - 2026"
                    className="w-full px-3 py-1.5 rounded-lg border border-amber-300 bg-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-amber-950 mb-1 text-[11px]">
                  Lời nhắn nhủ / Câu nói tâm đắc gửi lại thế hệ sau
                </label>
                <input
                  type="text"
                  value={legacyQuote}
                  onChange={(e) => setLegacyQuote(e.target.value)}
                  placeholder="Ví dụ: Đọc sách để sống trọn vẹn từng khoảnh khắc thanh xuân..."
                  className="w-full px-3 py-1.5 rounded-lg border border-amber-300 bg-white text-xs"
                />
              </div>
            </div>
          )}

          {/* Step 4: Pick Nominated Successor (BÀN GIAO ĐÍCH DANH) */}
          <div className="bg-white p-4 rounded-xl border border-[#D5CBBA] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <label className="font-bold text-[#1E3A24] flex items-center gap-1.5 text-xs">
                <UserCheck className="w-4 h-4 text-emerald-700" />
                <span>3. Bàn giao đích danh cho Tân {targetPositionTitle}:</span>
              </label>

              {/* Toggle: From List vs Custom Input */}
              <div className="flex items-center bg-[#EFE9DC] p-0.5 rounded-lg text-[11px]">
                <button
                  type="button"
                  onClick={() => setIncomingMode('from_list')}
                  className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                    incomingMode === 'from_list'
                      ? 'bg-[#23432B] text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Chọn Đích Danh ({userList.length} thành viên)
                </button>
                <button
                  type="button"
                  onClick={() => setIncomingMode('custom')}
                  className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                    incomingMode === 'custom'
                      ? 'bg-[#23432B] text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Nhập Mới Thủ Công
                </button>
              </div>
            </div>

            {/* Mode A: Select Nominated Member from userList */}
            {incomingMode === 'from_list' && (
              <div className="space-y-2.5">
                {/* Search Bar */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchMemberQuery}
                    onChange={(e) => setSearchMemberQuery(e.target.value)}
                    placeholder="Tìm theo tên thành viên, biệt danh, MSSV hoặc ban..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-[#C7BDB0] bg-[#FAF7F0] text-xs focus:ring-1 focus:ring-[#3B6E47]"
                  />
                </div>

                {/* Member selection cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto p-1 bg-[#FAF7F0] rounded-xl border border-[#DFD6C3]">
                  {eligibleMembers.length === 0 ? (
                    <div className="col-span-2 text-center py-4 text-stone-400 text-xs">
                      Không tìm thấy thành viên phù hợp với từ khóa tìm kiếm.
                    </div>
                  ) : (
                    eligibleMembers.map((member) => {
                      const isSelected = nominatedMemberId === member.id;
                      return (
                        <div
                          key={member.id}
                          onClick={() => setNominatedMemberId(member.id)}
                          className={`p-2.5 rounded-xl border text-left cursor-pointer transition flex items-center gap-2.5 ${
                            isSelected
                              ? 'bg-[#E8F1E7] border-[#3B6E47] ring-1 ring-[#3B6E47]'
                              : 'bg-white border-[#DFD6C3] hover:border-emerald-300'
                          }`}
                        >
                          <img
                            src={member.avatar}
                            alt={member.name}
                            className="w-9 h-9 rounded-lg object-cover ring-1 ring-[#5E936B]/40 shrink-0"
                          />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-xs text-[#1E3A24] truncate">
                                {member.name}
                              </span>
                              {isSelected && (
                                <CheckCircle2 className="w-3.5 h-3.5 text-[#3B6E47] shrink-0" />
                              )}
                            </div>
                            {member.nickname && (
                              <div className="text-[10px] text-emerald-800 font-medium italic truncate">
                                {member.nickname}
                              </div>
                            )}
                            <div className="text-[10px] text-stone-500 truncate">
                              {member.department} • {member.studentId}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Selected Preview Card */}
                {selectedNominatedMember && (
                  <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-300 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <HeartHandshake className="w-4 h-4 text-emerald-700 shrink-0" />
                      <span className="text-emerald-900">
                        Đã chọn đích danh: <strong>{selectedNominatedMember.name}</strong> ({selectedNominatedMember.studentId})
                      </span>
                    </div>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-2 py-0.5 rounded">
                      Sẵn Sàng Thăng Chức BCN
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Mode B: Manual Input for New Leader */}
            {incomingMode === 'custom' && (
              <div className="space-y-3 pt-1">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-[#23432B] mb-1 text-[11px]">Họ tên sinh viên mới *</label>
                    <input
                      type="text"
                      required={incomingMode === 'custom'}
                      value={customName}
                      onChange={(e) => setCustomName(e.target.value)}
                      placeholder="Ví dụ: Nguyễn Thành Trung"
                      className="w-full px-3 py-1.5 rounded-lg border border-[#C5BCAB] bg-white text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-[#23432B] mb-1 text-[11px]">Bút danh / Nickname *</label>
                    <input
                      type="text"
                      value={customNickname}
                      onChange={(e) => setCustomNickname(e.target.value)}
                      placeholder="Ví dụ: Trung Mọt Sách 👑"
                      className="w-full px-3 py-1.5 rounded-lg border border-[#C5BCAB] bg-white text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-[#23432B] mb-1 text-[11px]">Mã số sinh viên (MSSV) *</label>
                    <input
                      type="text"
                      required={incomingMode === 'custom'}
                      value={customStudentId}
                      onChange={(e) => setCustomStudentId(e.target.value)}
                      placeholder="Ví dụ: DTH230198"
                      className="w-full px-3 py-1.5 rounded-lg border border-[#C5BCAB] bg-white font-mono text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-[#23432B] mb-1 text-[11px]">Khoa / Ngành học</label>
                    <input
                      type="text"
                      value={customFaculty}
                      onChange={(e) => setCustomFaculty(e.target.value)}
                      placeholder="Khoa Sư phạm - Ngữ Văn K23"
                      className="w-full px-3 py-1.5 rounded-lg border border-[#C5BCAB] bg-white text-xs"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Footer */}
          <div className="pt-3 border-t border-[#DFD6C3] flex items-center justify-between gap-3">
            <span className="text-[11px] text-stone-500">
              Thực hiện bởi: <strong className="text-[#1E3A24]">{currentOperator.name}</strong>
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-stone-200 text-stone-700 font-semibold cursor-pointer text-xs"
              >
                Hủy
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 hover:from-amber-700 hover:to-amber-900 text-white font-bold text-xs shadow-md bubble-3d flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowRight className="w-4 h-4 text-amber-200" />
                <span>Xác Nhận Bàn Giao Đích Danh & Vinh Danh Tiền Nhiệm</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
