import React, { useState, useEffect } from 'react';
import {
  Award,
  PlusCircle,
  ShieldCheck,
  GraduationCap,
  Activity,
  HeartHandshake,
  Globe,
  FileText,
  ExternalLink,
  Send,
  X,
  Sparkles,
  Check,
  Upload,
  Trash2,
  Image as ImageIcon,
  Download
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { S5TCriterion, S5TProof, UserProfile } from '../types';
import { readFileAsDataUrl } from '../utils/fileUpload';

interface S5TTrackerSectionProps {
  currentUser: UserProfile;
  criteria: S5TCriterion[];
  proofs: S5TProof[];
  isBcnMode: boolean;
  onSubmitProof: (proof: Omit<S5TProof, 'id' | 'submittedAt' | 'status'>) => void;
  onReviewProof: (proofId: string, status: 'approved' | 'rejected', comment: string) => void;
  onDeleteProof?: (proofId: string) => void;
}

export const S5TTrackerSection: React.FC<S5TTrackerSectionProps> = ({
  currentUser,
  criteria,
  proofs,
  isBcnMode,
  onSubmitProof,
  onReviewProof,
  onDeleteProof
}) => {
  const isBcnAdmin = isBcnMode || currentUser.role === 'bcn_admin' || currentUser.adminType === 'master_root';

  const [activeTab, setActiveTab] = useState<'my_progress' | 'admin_review'>(
    isBcnAdmin ? 'admin_review' : 'my_progress'
  );

  // Sync tab when switching between normal member and BCN
  useEffect(() => {
    if (!isBcnAdmin && activeTab === 'admin_review') {
      setActiveTab('my_progress');
    }
  }, [isBcnAdmin, activeTab]);

  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [selectedProofToReview, setSelectedProofToReview] = useState<S5TProof | null>(null);
  const [reviewComment, setReviewComment] = useState('');
  const [previewProof, setPreviewProof] = useState<S5TProof | null>(null);

  // Form states for new proof submission
  const [targetCritId, setTargetCritId] = useState<string>(criteria[0]?.id || 'crit-1');
  const [activityTitle, setActivityTitle] = useState('');
  const [activityDate, setActivityDate] = useState('');
  const [proofUrl, setProofUrl] = useState('');
  const [attachmentType, setAttachmentType] = useState<'image' | 'pdf' | 'link'>('image');
  const [attachmentName, setAttachmentName] = useState('');
  const [proofDescription, setProofDescription] = useState('');
  const [uploadError, setUploadError] = useState('');

  // Ensure criterion crit-2 always shows 8.5 GPA (80-85 points) even if cached in localStorage
  const normalizedCriteria: S5TCriterion[] = criteria.map(c => {
    if (c.id === 'crit-2') {
      return {
        ...c,
        description:
          'Điểm trung bình học tập đạt từ 8.5/10 (hoặc 80 - 85 điểm) trở lên; Có ít nhất 1 bài viết chuyên đề / cảm nhận học thuật đăng trên E-News.'
      };
    }
    return c;
  });

  // Personal proofs belonging to the currently logged-in student
  const myProofs = proofs.filter(
    p =>
      p.userId === currentUser.id ||
      (p.studentId &&
        currentUser.studentId &&
        p.studentId.toLowerCase() === currentUser.studentId.toLowerCase()) ||
      (p.studentName && p.studentName.toLowerCase() === currentUser.name.toLowerCase())
  );

  // Calculate personal completion per criterion for the current user
  const personalCriteria = normalizedCriteria.map(crit => {
    const approvedForCrit = myProofs.filter(
      p => p.criterionId === crit.id && p.status === 'approved'
    ).length;
    const pendingForCrit = myProofs.filter(
      p => p.criterionId === crit.id && p.status === 'pending'
    ).length;
    // Give credit for reading streak on Ethics/Study if they have active streak or approved proofs
    const streakBonus =
      (crit.id === 'crit-1' && currentUser.readingStreak >= 5 ? 1 : 0) +
      (crit.id === 'crit-2' && currentUser.enewsStreak >= 3 ? 1 : 0);
    const completedCount = Math.min(
      crit.requiredCount,
      approvedForCrit + streakBonus
    );
    return {
      ...crit,
      completedCount,
      pendingCount: pendingForCrit
    };
  });

  const completedCriteriaCount = personalCriteria.filter(
    c => c.completedCount >= c.requiredCount
  ).length;
  const progressPercent =
    personalCriteria.length > 0
      ? Math.round((completedCriteriaCount / personalCriteria.length) * 100)
      : currentUser.s5tProgress || 0;

  const pendingProofs = proofs.filter(p => p.status === 'pending');

  // Icon mapper helper
  const getCriterionIcon = (iconName: string) => {
    switch (iconName) {
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-emerald-600" />;
      case 'GraduationCap':
        return <GraduationCap className="w-5 h-5 text-blue-600" />;
      case 'Activity':
        return <Activity className="w-5 h-5 text-amber-600" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-5 h-5 text-rose-600" />;
      case 'Globe':
        return <Globe className="w-5 h-5 text-indigo-600" />;
      default:
        return <Award className="w-5 h-5 text-emerald-600" />;
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError('');

    if (file.size > 15 * 1024 * 1024) {
      setUploadError('Kích thước tệp quá lớn (tối đa 15MB).');
      return;
    }

    try {
      const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
      const dataUrl = await readFileAsDataUrl(file, !isPdf);
      setProofUrl(dataUrl);
      setAttachmentName(file.name);
      setAttachmentType(isPdf ? 'pdf' : 'image');
    } catch (err: any) {
      setUploadError(err.message || 'Không thể tải tệp minh chứng lên.');
    }
  };

  const handleSubmitProof = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activityTitle.trim()) return;
    if (!proofUrl.trim()) {
      setUploadError('Vui lòng tải ảnh/file PDF minh chứng từ máy hoặc dán đường dẫn minh chứng.');
      return;
    }

    const chosenCrit = normalizedCriteria.find(c => c.id === targetCritId);

    onSubmitProof({
      userId: currentUser.id,
      studentId: currentUser.studentId,
      studentName: currentUser.name,
      department: currentUser.department,
      criterionId: targetCritId,
      criterionName: chosenCrit ? chosenCrit.name : 'Tiêu chí SV5T',
      activityTitle: activityTitle.trim(),
      activityDate: activityDate.trim() || new Date().toLocaleDateString('vi-VN'),
      proofUrl: proofUrl.trim(),
      attachmentType,
      attachmentName: attachmentName || 'Minh_Chung_SV5T',
      proofDescription: proofDescription.trim()
    });

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 }
    });

    setIsSubmitModalOpen(false);
    setActivityTitle('');
    setActivityDate('');
    setProofUrl('');
    setAttachmentName('');
    setProofDescription('');
    setUploadError('');
  };

  const handleApprove = (proof: S5TProof) => {
    if (!isBcnAdmin) return;
    onReviewProof(proof.id, 'approved', reviewComment || 'Đạt tiêu chuẩn Sinh viên 5 tốt AGU!');
    setSelectedProofToReview(null);
    setReviewComment('');
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.4 }
    });
  };

  const handleReject = (proof: S5TProof) => {
    if (!isBcnAdmin) return;
    onReviewProof(
      proof.id,
      'rejected',
      reviewComment || 'Hồ sơ chưa đủ minh chứng chi tiết, vui lòng bổ sung.'
    );
    setSelectedProofToReview(null);
    setReviewComment('');
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="glass-vintage rounded-2xl p-5 sm:p-6 border border-[#5E936B]/30 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
        <div className="space-y-1.5 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#E5F0E4] text-[#244A2B] text-xs font-bold border border-[#BEDBC1]">
            <Award className="w-3.5 h-3.5 text-amber-600" />
            <span>Tiêu Chuẩn Rèn Luyện & Danh Hiệu Sinh Viên</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-bold text-[#1F3D26] font-serif-vintage tracking-tight">
            Theo Dõi & Xét Duyệt Sinh Viên 5 Tốt
          </h2>

          <p className="text-xs text-[#48664D] leading-relaxed">
            Hệ thống hóa 5 tiêu chí: <strong>Đạo đức - Học tập (ĐTB ≥ 8.5 / 80-85 điểm) - Thể lực - Tình nguyện - Hội nhập</strong>. Tải ảnh chụp hoặc file PDF giấy chứng nhận trực tiếp từ điện thoại/máy tính của bạn.
          </p>
        </div>

        {/* Progress Metric Card */}
        <div className="bg-gradient-to-br from-[#214128] to-[#2E5837] text-white p-4 rounded-xl border border-white/20 shadow-sm text-center min-w-[220px] space-y-1.5">
          <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-200">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Tiến Độ SV5T Của {currentUser.name}</span>
          </div>

          <div className="text-3xl font-black text-amber-300 tracking-tight">
            {progressPercent}%
          </div>

          <div className="text-[11px] text-emerald-100 font-medium">
            Đạt <strong>{completedCriteriaCount}/{personalCriteria.length}</strong> tiêu chuẩn xét cấp Trường
          </div>

          <div className="w-full bg-white/20 rounded-full h-2 overflow-hidden">
            <div
              className="bg-gradient-to-r from-amber-400 to-emerald-400 h-full rounded-full transition-all duration-700"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Tabs Switcher: Member View vs Admin Approval */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-2 border-b border-[#DCD1BE]">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('my_progress')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
              activeTab === 'my_progress'
                ? 'bg-[#26492F] text-white shadow-xs'
                : 'bg-white hover:bg-[#F2EDE1] text-[#4A6450] border border-[#D5CBBC]'
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            <span>5 Tiêu Chuẩn & Minh Chứng Của Tôi ({myProofs.length})</span>
          </button>

          {isBcnAdmin && (
            <button
              type="button"
              onClick={() => setActiveTab('admin_review')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer relative ${
                activeTab === 'admin_review'
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-white hover:bg-[#F2EDE1] text-amber-900 border border-amber-300'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Hội Đồng BCN Duyệt Hồ Sơ</span>
              {pendingProofs.length > 0 && (
                <span className="px-1.5 py-0.2 text-[9px] font-extrabold bg-rose-500 text-white rounded-full">
                  {pendingProofs.length} chờ duyệt
                </span>
              )}
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={() => setIsSubmitModalOpen(true)}
          className="px-4 py-2 rounded-xl bg-[#3B6E47] hover:bg-[#2C5637] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs bubble-3d cursor-pointer"
        >
          <PlusCircle className="w-4 h-4 text-emerald-200" />
          <span>Tải Lên Minh Chứng Mới</span>
        </button>
      </div>

      {/* Tab 1: Member 5 Criteria Cards & Personal Proofs */}
      {activeTab === 'my_progress' && (
        <div className="space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-[#23432B] flex items-center gap-1.5">
                <span>5 Tiêu Chuẩn Sinh Viên 5 Tốt</span>
                <span className="text-[11px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 font-semibold">
                  ★ Học tập tốt: ĐTB ≥ 8.5/10 (80 - 85 điểm)
                </span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 pt-1">
              {personalCriteria.map((crit) => {
                const isDone = crit.completedCount >= crit.requiredCount;
                return (
                  <div
                    key={crit.id}
                    className={`glass-vintage rounded-2xl p-4 border-2 transition-all flex flex-col justify-between ${
                      isDone
                        ? 'border-emerald-500/60 bg-gradient-to-br from-emerald-50/70 to-white shadow-xs'
                        : crit.id === 'crit-2'
                        ? 'border-blue-300 bg-white'
                        : 'border-[#DAD0BD] bg-white'
                    }`}
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <div className="w-9 h-9 rounded-xl bg-[#F0EBE0] flex items-center justify-center shadow-2xs">
                          {getCriterionIcon(crit.iconName)}
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            isDone
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : 'bg-amber-100 text-amber-800 border-amber-300'
                          }`}
                        >
                          {isDone ? '✓ Đã đạt' : 'Đang tích lũy'}
                        </span>
                      </div>

                      <div>
                        <h4 className="font-bold text-sm sm:text-base text-[#1E3924] font-serif-vintage">
                          {crit.name}
                        </h4>
                        <p className="text-xs text-[#425B46] leading-relaxed mt-1">
                          {crit.description}
                        </p>
                      </div>
                    </div>

                    <div className="pt-3 mt-3 border-t border-[#EAE2D2] flex items-center justify-between text-xs font-semibold">
                      <span className="text-[#657E69] text-[11px]">
                        Tiến độ: <strong className="text-[#1F3D26]">{crit.completedCount}/{crit.requiredCount}</strong>
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setTargetCritId(crit.id);
                          setIsSubmitModalOpen(true);
                        }}
                        className="text-xs font-bold text-[#3B6E47] hover:underline cursor-pointer"
                      >
                        + Nộp minh chứng
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Personal Submitted Proofs List */}
          <div className="glass-vintage rounded-2xl p-6 border border-[#5E936B]/30 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-[#23432B] font-serif-vintage">
                Danh Sách Minh Chứng Đã Nộp Của Bạn ({myProofs.length})
              </h3>
              <span className="text-[11px] text-[#5B765F]">
                Tải lên được • Xóa được bất cứ lúc nào
              </span>
            </div>

            {myProofs.length === 0 ? (
              <div className="p-8 rounded-2xl bg-white border border-[#DED4C3] text-center space-y-2">
                <Award className="w-9 h-9 text-amber-500/60 mx-auto" />
                <h4 className="font-bold text-sm text-[#23432B]">
                  Bạn chưa nộp minh chứng Sinh Viên 5 Tốt nào
                </h4>
                <p className="text-xs text-[#617B65] max-w-md mx-auto">
                  Hãy bấm nút <strong>"+ Nộp minh chứng"</strong> ở từng tiêu chí phía trên để tải lên ảnh chụp bảng điểm (≥ 8.5), giấy chứng nhận hoặc hình ảnh hoạt động tình nguyện!
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {myProofs.map((proof) => {
                  const isPdf = proof.attachmentType === 'pdf' || proof.proofUrl?.startsWith('data:application/pdf');
                  return (
                    <div
                      key={proof.id}
                      className="bg-white p-4 rounded-2xl border border-[#DED4C3] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-start gap-3">
                        <div
                          onClick={() => setPreviewProof(proof)}
                          className="w-14 h-14 rounded-xl bg-stone-100 overflow-hidden shrink-0 border border-stone-200 flex items-center justify-center cursor-pointer hover:opacity-90"
                          title="Bấm để xem chi tiết minh chứng"
                        >
                          {isPdf ? (
                            <div className="text-center p-1">
                              <FileText className="w-6 h-6 text-rose-600 mx-auto" />
                              <span className="text-[9px] font-bold text-rose-800">PDF</span>
                            </div>
                          ) : (
                            <img src={proof.proofUrl} alt="proof" className="w-full h-full object-cover" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-sm text-[#23432B]">
                              {proof.activityTitle}
                            </span>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#E8F1E7] text-[#2C5C36] border border-[#C5DDC7]">
                              {proof.criterionName}
                            </span>
                          </div>
                          <p className="text-[#617B65] mt-0.5">
                            Ngày tham gia: {proof.activityDate} • Nộp ngày: {proof.submittedAt}
                          </p>
                          <p className="text-[#415545] mt-1 italic">
                            "{proof.proofDescription}"
                          </p>
                          {proof.reviewComment && (
                            <div className="mt-1.5 p-2 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 text-[11px]">
                              <strong>Nhận xét từ BCN ({proof.reviewedBy}):</strong> {proof.reviewComment}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                        <button
                          type="button"
                          onClick={() => setPreviewProof(proof)}
                          className="px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold text-[11px] cursor-pointer"
                        >
                          Xem file
                        </button>

                        <span
                          className={`px-3 py-1 rounded-full font-bold text-xs border ${
                            proof.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : proof.status === 'rejected'
                              ? 'bg-rose-100 text-rose-800 border-rose-300'
                              : 'bg-amber-100 text-amber-800 border-amber-300'
                          }`}
                        >
                          {proof.status === 'approved' && '✓ Đã phê duyệt'}
                          {proof.status === 'rejected' && '✕ Cần bổ sung'}
                          {proof.status === 'pending' && '⏳ Chờ BCN duyệt'}
                        </span>

                        {onDeleteProof && (
                          <button
                            type="button"
                            onClick={() => onDeleteProof(proof.id)}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition cursor-pointer"
                            title="Xóa minh chứng này"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Admin / BCN Approval Dashboard */}
      {activeTab === 'admin_review' && isBcnAdmin && (
        <div className="space-y-6">
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between text-xs text-amber-900">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-amber-700 shrink-0" />
              <span>
                <strong>Hội Đồng BCN Xét Duyệt Minh Chứng:</strong> Kiểm tra bảng điểm (ĐTB ≥ 8.5 / 80-85 điểm), giấy chứng nhận hoặc hình ảnh hoạt động để công nhận tiến độ Sinh viên 5 tốt cho thành viên.
              </span>
            </div>
          </div>

          <div className="space-y-4">
            {proofs.map((proof) => {
              const isPdf = proof.attachmentType === 'pdf' || proof.proofUrl?.startsWith('data:application/pdf');
              return (
                <div
                  key={proof.id}
                  className="glass-vintage rounded-2xl p-5 sm:p-6 border border-[#CAD9C8] shadow-sm space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-[#2D5037] text-white flex items-center justify-center font-bold font-serif-vintage">
                        {proof.studentName.slice(0, 1)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-bold text-sm text-[#23432B]">
                            {proof.studentName}
                          </h4>
                          <span className="text-[11px] text-stone-500 font-mono">
                            ({proof.studentId})
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E5F0E4] text-[#2C5734]">
                            {proof.department}
                          </span>
                        </div>
                        <p className="text-xs text-[#5C7760] font-medium mt-0.5">
                          Tiêu chí: <strong>{proof.criterionName}</strong> • Nộp ngày: {proof.submittedAt}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`px-3 py-1 rounded-full font-bold text-xs border ${
                          proof.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                            : proof.status === 'rejected'
                            ? 'bg-rose-100 text-rose-800 border-rose-300'
                            : 'bg-amber-100 text-amber-800 border-amber-300'
                        }`}
                      >
                        {proof.status === 'approved' && '✓ Đã Phê Duyệt'}
                        {proof.status === 'rejected' && '✕ Đã Từ Chối'}
                        {proof.status === 'pending' && '⏳ Chờ Xét Duyệt'}
                      </span>

                      {onDeleteProof && (
                        <button
                          type="button"
                          onClick={() => onDeleteProof(proof.id)}
                          className="p-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition cursor-pointer flex items-center gap-1 text-xs font-bold"
                          title="Xóa minh chứng này"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Xóa</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Proof content and photo/PDF */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-[#F8F5EE] p-4 rounded-2xl border border-[#E3DAC8]">
                    <div className="md:col-span-2 space-y-2 text-xs">
                      <h5 className="font-bold text-sm text-[#23432B]">
                        {proof.activityTitle}
                      </h5>
                      <p className="text-[#4F6753] leading-relaxed">
                        <strong>Mô tả chi tiết:</strong> {proof.proofDescription}
                      </p>
                      <p className="text-stone-500">
                        <strong>Thời gian diễn ra:</strong> {proof.activityDate}
                      </p>
                    </div>

                    <div
                      onClick={() => setPreviewProof(proof)}
                      className="rounded-xl overflow-hidden aspect-video bg-stone-200 border border-stone-300 relative group cursor-pointer flex items-center justify-center"
                    >
                      {isPdf ? (
                        <div className="text-center p-4 space-y-1">
                          <FileText className="w-10 h-10 text-rose-600 mx-auto" />
                          <div className="text-xs font-bold text-stone-800">
                            {proof.attachmentName || 'Tài liệu PDF Minh chứng'}
                          </div>
                          <span className="text-[10px] text-rose-700 font-semibold">
                            Bấm để mở xem file PDF
                          </span>
                        </div>
                      ) : (
                        <img src={proof.proofUrl} alt="evidence" className="w-full h-full object-cover" />
                      )}
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition text-xs font-bold gap-1">
                        <ExternalLink className="w-4 h-4" />
                        Xem minh chứng gốc
                      </div>
                    </div>
                  </div>

                  {/* Review Action Controls */}
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
                    <div className="flex-1">
                      <input
                        type="text"
                        placeholder="Ghi chú nhận xét hoặc lý do duyệt / từ chối..."
                        value={selectedProofToReview?.id === proof.id ? reviewComment : ''}
                        onChange={(e) => {
                          setSelectedProofToReview(proof);
                          setReviewComment(e.target.value);
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-[#D5CBBC] text-xs focus:ring-1 focus:ring-[#3B6E47]"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleReject(proof)}
                        className="px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition cursor-pointer"
                      >
                        Từ Chối
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApprove(proof)}
                        className="px-5 py-2 rounded-xl bg-[#2D5337] hover:bg-[#203E28] text-white text-xs font-bold shadow-sm bubble-3d flex items-center gap-1.5 cursor-pointer"
                      >
                        <Check className="w-4 h-4 text-emerald-300" />
                        Duyệt Đạt Minh Chứng
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Modal: Submit S5T Proof with Direct Image / PDF Upload */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#FAF7F0] rounded-2xl border-2 border-[#5E936B]/50 shadow-2xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
            <div className="bg-[#23432B] text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-300" />
                <h3 className="font-bold text-base font-serif-vintage">
                  Nộp Minh Chứng Sinh Viên 5 Tốt
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsSubmitModalOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitProof} className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-bold text-[#23432B] mb-1">
                  Chọn tiêu chí muốn tích lũy *
                </label>
                <select
                  value={targetCritId}
                  onChange={(e) => setTargetCritId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                >
                  {normalizedCriteria.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} — {c.description.slice(0, 60)}...
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">
                  Tên hoạt động / Thành tích đạt được *
                </label>
                <input
                  type="text"
                  required
                  value={activityTitle}
                  onChange={(e) => setActivityTitle(e.target.value)}
                  placeholder="Ví dụ: Bảng điểm học kỳ ĐTB 8.6 / Giấy chứng nhận Mùa hè xanh..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">
                  Ngày diễn ra / Ngày cấp
                </label>
                <input
                  type="text"
                  value={activityDate}
                  onChange={(e) => setActivityDate(e.target.value)}
                  placeholder="Ví dụ: 25/10/2026"
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              {/* Direct Image / PDF File Upload from Phone or Computer */}
              <div className="space-y-2">
                <label className="block font-bold text-[#23432B]">
                  Tải Ảnh chụp hoặc File PDF Minh chứng từ máy *
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <label className="flex-1 py-2.5 px-3.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition">
                    <Upload className="w-4 h-4 text-emerald-700" />
                    <span>Chọn Ảnh hoặc File PDF từ Thiết Bị</span>
                    <input
                      type="file"
                      accept="image/*,.pdf,application/pdf"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {proofUrl && (
                  <div className="p-3 rounded-xl bg-white border border-emerald-300 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      {attachmentType === 'pdf' ? (
                        <FileText className="w-8 h-8 text-rose-600 shrink-0" />
                      ) : (
                        <img
                          src={proofUrl}
                          alt="Preview"
                          className="w-12 h-12 rounded-lg object-cover border border-stone-200 shrink-0"
                        />
                      )}
                      <div className="min-w-0">
                        <div className="font-bold text-xs text-emerald-900 truncate">
                          {attachmentName || 'Đã đính kèm tệp minh chứng'}
                        </div>
                        <div className="text-[10px] text-emerald-700">
                          {attachmentType === 'pdf' ? 'Tài liệu PDF nguyên bản' : 'Hình ảnh minh chứng'}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setProofUrl('');
                        setAttachmentName('');
                      }}
                      className="p-1.5 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}

                <div className="pt-1">
                  <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                    Hoặc dán đường dẫn (URL) hình ảnh / tài liệu (nếu có):
                  </label>
                  <input
                    type="text"
                    value={proofUrl.startsWith('data:') ? '' : proofUrl}
                    onChange={(e) => {
                      setProofUrl(e.target.value);
                      setAttachmentType('link');
                      setAttachmentName('Liên kết minh chứng');
                    }}
                    placeholder="https://..."
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs"
                  />
                </div>

                {uploadError && (
                  <p className="text-xs text-rose-600 font-semibold">{uploadError}</p>
                )}
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">
                  Mô tả quá trình tham gia & đóng góp *
                </label>
                <textarea
                  rows={3}
                  required
                  value={proofDescription}
                  onChange={(e) => setProofDescription(e.target.value)}
                  placeholder="Nêu rõ kết quả đạt được (VD: Điểm trung bình học kỳ đạt 8.6/10, hoàn thành chiến dịch tình nguyện...)"
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#DFD6C3]">
                <button
                  type="button"
                  onClick={() => setIsSubmitModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-700 font-semibold cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#23432B] hover:bg-[#1B3522] text-white font-bold bubble-3d shadow-md cursor-pointer flex items-center gap-2"
                >
                  <Send className="w-4 h-4 text-emerald-300" />
                  <span>Gửi Minh Chứng</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Preview Proof Image or PDF */}
      {previewProof && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in">
          <div className="bg-[#FAF7F0] rounded-2xl border border-[#DAD0BD] shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden">
            <div className="bg-[#1E3A24] text-white px-5 py-3.5 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-sm sm:text-base font-serif-vintage">
                  {previewProof.activityTitle}
                </h4>
                <p className="text-[11px] text-emerald-200">
                  Sinh viên: {previewProof.studentName} ({previewProof.studentId}) • {previewProof.criterionName}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={previewProof.proofUrl}
                  download={previewProof.attachmentName || `${previewProof.activityTitle}.pdf`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Tải Về Máy</span>
                </a>
                <button
                  type="button"
                  onClick={() => setPreviewProof(null)}
                  className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-4 flex-1 overflow-auto bg-stone-900 flex items-center justify-center min-h-[380px]">
              {previewProof.attachmentType === 'pdf' || previewProof.proofUrl?.startsWith('data:application/pdf') ? (
                <iframe
                  src={previewProof.proofUrl}
                  title={previewProof.activityTitle}
                  className="w-full h-[65vh] rounded-xl bg-white border-0"
                />
              ) : (
                <img
                  src={previewProof.proofUrl}
                  alt={previewProof.activityTitle}
                  className="max-w-full max-h-[68vh] object-contain rounded-xl shadow-lg"
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
