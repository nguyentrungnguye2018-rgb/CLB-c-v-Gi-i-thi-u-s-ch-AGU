import React, { useState } from 'react';
import {
  Mail,
  Send,
  Lock,
  Unlock,
  ShieldAlert,
  CheckCircle2,
  EyeOff,
  UserCheck,
  Sparkles,
  X,
  Fingerprint,
  Trash2,
  ShieldCheck,
  KeyRound
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ConfidentialReport, UserProfile, DepartmentType } from '../types';

interface ConfidentialReportSectionProps {
  currentUser: UserProfile;
  reports: ConfidentialReport[];
  isBcnMode: boolean;
  onSendReport: (report: Omit<ConfidentialReport, 'id' | 'createdAt' | 'status'>) => void;
  onUpdateBcnResponse: (reportId: string, response: string) => void;
  onDeleteReport?: (reportId: string) => void;
  onOpenAuthModal: () => void;
}

export const ConfidentialReportSection: React.FC<ConfidentialReportSectionProps> = ({
  currentUser,
  reports,
  isBcnMode,
  onSendReport,
  onUpdateBcnResponse,
  onDeleteReport,
  onOpenAuthModal
}) => {
  const isBcnAdmin = isBcnMode || currentUser.role === 'bcn_admin' || currentUser.adminType === 'master_root';
  const isDeptLeader = currentUser.departmentRole === 'leader' || currentUser.role === 'lead';

  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [recipientChoice, setRecipientChoice] = useState<'truong_ban' | 'bcn_master'>('bcn_master');
  const [category, setCategory] = useState<'Góp ý sinh hoạt' | 'Mâu thuẫn nội bộ' | 'Ý tưởng sự kiện' | 'Cơ sở vật chất Thư viện' | 'Khác'>('Góp ý sinh hoạt');
  const [targetDept, setTargetDept] = useState<DepartmentType>('Truyền thông');
  const [urgency, setUrgency] = useState<'low' | 'medium' | 'high'>('medium');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'resolved'>('all');

  // Track which report IDs BCN has toggled to reveal real identity
  const [decryptedReportIds, setDecryptedReportIds] = useState<string[]>([]);
  // Response inputs
  const [responseInputs, setResponseInputs] = useState<Record<string, string>>({});
  const [submitSuccessToast, setSubmitSuccessToast] = useState<string | null>(null);

  const handleCompose = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    const isEncrypted = recipientChoice === 'bcn_master';
    const hashDigits = Math.floor(1000 + Math.random() * 9000);
    const encryptedCode = isEncrypted
      ? `AES-256#AGU-BCN-${hashDigits}`
      : 'OPEN-TO-DEPT-LEAD';

    onSendReport({
      recipientType: recipientChoice,
      targetDepartment: recipientChoice === 'truong_ban' ? targetDept : undefined,
      category,
      title: title.trim(),
      content: content.trim(),
      isEncrypted,
      encryptedCode,
      realSenderId: currentUser.id,
      realSenderName: currentUser.name,
      realSenderNickname: currentUser.nickname,
      realSenderStudentId: currentUser.studentId,
      realSenderDept: currentUser.department,
      urgency
    });

    confetti({
      particleCount: 45,
      spread: 50,
      origin: { y: 0.6 }
    });

    setIsComposeOpen(false);
    setTitle('');
    setContent('');
    setSubmitSuccessToast('Đã gửi báo cáo ẩn danh thành công! Ban Chủ Nhiệm đã nhận được thông báo.');
    setTimeout(() => setSubmitSuccessToast(null), 5000);
  };

  const toggleDecryptIdentity = (reportId: string) => {
    if (!isBcnAdmin) return;
    setDecryptedReportIds(prev =>
      prev.includes(reportId) ? prev.filter(id => id !== reportId) : [...prev, reportId]
    );
  };

  const handleSendResponse = (reportId: string) => {
    const text = responseInputs[reportId]?.trim();
    if (!text) return;
    onUpdateBcnResponse(reportId, text);
    setResponseInputs(prev => ({ ...prev, [reportId]: '' }));
  };

  // Privacy filter:
  // - BCN sees ALL reports in the Confidential Inbox.
  // - Department Leaders see reports sent to their department + their own reports.
  // - Normal members ONLY see reports they themselves submitted, keeping everyone else's reports 100% confidential.
  const visibleReports = reports.filter(r => {
    if (isBcnAdmin) return true;
    const isMine =
      r.realSenderId === currentUser.id ||
      (r.realSenderStudentId &&
        currentUser.studentId &&
        r.realSenderStudentId.toLowerCase() === currentUser.studentId.toLowerCase()) ||
      (r.realSenderName && r.realSenderName.toLowerCase() === currentUser.name.toLowerCase());
    if (isMine) return true;
    if (isDeptLeader && r.recipientType === 'truong_ban' && r.targetDepartment === currentUser.department) {
      return true;
    }
    return false;
  }).filter(r => {
    if (filterStatus === 'pending') return r.status !== 'resolved';
    if (filterStatus === 'resolved') return r.status === 'resolved';
    return true;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="glass-vintage rounded-2xl p-6 sm:p-7 border border-[#5E936B]/30 shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E5F0E4] text-[#244A2B] text-xs font-bold border border-[#BEDBC1]">
            <Mail className="w-3.5 h-3.5 text-amber-700" />
            <span>
              {isBcnAdmin
                ? 'Hòm Thư Bảo Mật Ẩn Danh Dành Cho Ban Chủ Nhiệm'
                : 'Kênh Phản Ánh & Tâm Tư Bảo Mật 100%'}
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1F3D26] font-serif-vintage tracking-tight">
            {isBcnAdmin ? 'Trung Tâm Quản Trị Báo Cáo Ẩn Danh (BCN)' : 'Hòm Thư Báo Cáo Ẩn Danh & Kiến Nghị'}
          </h2>

          <p className="text-xs sm:text-sm text-[#48664D] leading-relaxed">
            {isBcnAdmin ? (
              <>
                Nơi lưu trữ độc lập toàn bộ thư phản ánh, góp ý và báo cáo ẩn danh của thành viên gửi về Ban Chủ Nhiệm. BCN có thể giải mã danh tính khi cần bảo hộ thành viên, gửi phản hồi trực tiếp hoặc xóa thư đã xử lý xong.
              </>
            ) : (
              <>
                Mọi ý kiến đóng góp xây dựng CLB, khúc mắc nội bộ hay đề xuất hoạt động đều được bảo mật tuyệt đối. Thư bạn gửi chỉ hiện trong lịch sử cá nhân của bạn và <strong>Hòm Thư Ẩn Danh bên Ban Chủ Nhiệm</strong> (các thành viên khác hoàn toàn không thể nhìn thấy).
              </>
            )}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          {!isBcnAdmin && (
            <button
              type="button"
              onClick={onOpenAuthModal}
              className="px-4 py-3 rounded-2xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
              title="Dành cho Ban Chủ Nhiệm mở khóa toàn bộ Hòm thư"
            >
              <KeyRound className="w-4 h-4 text-amber-700" />
              <span>Chế độ BCN</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsComposeOpen(true)}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#214128] to-[#35643F] hover:from-[#1A3420] hover:to-[#2B5434] text-white text-xs sm:text-sm font-bold flex items-center gap-2.5 shadow-lg bubble-3d cursor-pointer shrink-0"
          >
            <Mail className="w-5 h-5 text-emerald-300" />
            <span>Gửi Báo Cáo Ẩn Danh Mới</span>
          </button>
        </div>
      </div>

      {submitSuccessToast && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs sm:text-sm flex items-center justify-between gap-3 shadow-sm">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="font-semibold">{submitSuccessToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setSubmitSuccessToast(null)}
            className="text-stone-400 hover:text-stone-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Reports Inbox / Personal Sent History */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#DAD0BD]">
          <div>
            <h3 className="font-bold text-base text-[#23432B] font-serif-vintage flex items-center gap-2">
              {isBcnAdmin ? (
                <>
                  <ShieldCheck className="w-5 h-5 text-amber-600" />
                  <span>Toàn Bộ Hòm Thư Bảo Mật Gửi Tới BCN ({visibleReports.length} thư)</span>
                </>
              ) : (
                <>
                  <Fingerprint className="w-5 h-5 text-emerald-700" />
                  <span>Hộp Thư Đã Gửi Của Riêng Bạn ({visibleReports.length} thư)</span>
                </>
              )}
            </h3>
            <p className="text-[11px] text-[#638068] mt-0.5">
              {isBcnAdmin
                ? 'Tất cả báo cáo ẩn danh đều được tập trung tại tab độc lập này để BCN xét duyệt chỉn chu.'
                : 'Bảo mật riêng tư: Chỉ bạn và Ban Chủ Nhiệm mới thấy nội dung và phản hồi của những thư này.'}
            </p>
          </div>

          <div className="flex items-center gap-1.5">
            {(['all', 'pending', 'resolved'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  filterStatus === st
                    ? 'bg-[#23432B] text-white'
                    : 'bg-[#FAF6EE] text-[#4A6450] border border-[#D5CBBC] hover:bg-[#EFE9DC]'
                }`}
              >
                {st === 'all' ? 'Tất cả' : st === 'pending' ? 'Chờ phản hồi' : 'Đã giải quyết'}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          {visibleReports.length === 0 ? (
            <div className="glass-vintage rounded-2xl p-10 text-center space-y-3 border border-[#CBDAC8] bg-white">
              <Mail className="w-10 h-10 text-emerald-700/50 mx-auto" />
              <h4 className="font-bold text-base text-[#23432B]">
                {isBcnAdmin ? 'Hiện không có thư báo cáo nào trong mục này' : 'Bạn chưa gửi thư báo cáo ẩn danh nào'}
              </h4>
              <p className="text-xs text-[#526D57] max-w-md mx-auto">
                {isBcnAdmin
                  ? 'Khi thành viên gửi báo cáo ẩn danh từ bất kỳ thiết bị nào, thư sẽ tự động đồng bộ về đây.'
                  : 'Nếu bạn có tâm tư, góp ý hoặc phản ánh cần gửi riêng cho Ban Chủ Nhiệm, hãy bấm nút "Gửi Báo Cáo Ẩn Danh Mới" phía trên.'}
              </p>
            </div>
          ) : (
            visibleReports.map((report) => {
              const isEncrypted = report.isEncrypted;
              const isDecrypted = decryptedReportIds.includes(report.id);
              const isToBcn = report.recipientType === 'bcn_master';
              const isMyReport =
                report.realSenderId === currentUser.id ||
                (report.realSenderStudentId &&
                  currentUser.studentId &&
                  report.realSenderStudentId.toLowerCase() === currentUser.studentId.toLowerCase());

              return (
                <div
                  key={report.id}
                  className={`glass-vintage rounded-2xl p-5 sm:p-6 border-2 transition-all space-y-4 ${
                    isToBcn
                      ? 'border-amber-400/50 bg-gradient-to-br from-[#FFFDF7] to-[#FAF5E8]'
                      : 'border-[#CBDAC8] bg-white'
                  }`}
                >
                  {/* Header row of the report */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E7DECB]">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[11px] font-bold border flex items-center gap-1.5 ${
                          isToBcn
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                        }`}
                      >
                        {isToBcn ? (
                          <>
                            <Lock className="w-3.5 h-3.5 text-amber-700" />
                            <span>Gửi Ban Chủ Nhiệm (Bảo Mật Tối Cao)</span>
                          </>
                        ) : (
                          <>
                            <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
                            <span>Gửi Trưởng Ban {report.targetDepartment}</span>
                          </>
                        )}
                      </span>

                      <span className="text-xs font-semibold px-2.5 py-0.5 rounded-lg bg-stone-100 text-stone-700 border border-stone-200">
                        {report.category}
                      </span>

                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          report.urgency === 'high'
                            ? 'bg-rose-100 text-rose-700 border border-rose-300'
                            : report.urgency === 'medium'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-stone-100 text-stone-600'
                        }`}
                      >
                        Mức độ: {report.urgency === 'high' ? 'Khẩn cấp' : report.urgency === 'medium' ? 'Bình thường' : 'Góp ý nhẹ'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-[#708B73]">
                      <span>Gửi ngày: {report.createdAt}</span>
                      <span>•</span>
                      <span
                        className={`font-bold ${
                          report.status === 'resolved'
                            ? 'text-emerald-700'
                            : report.status === 'processing'
                            ? 'text-amber-700'
                            : 'text-stone-500'
                        }`}
                      >
                        {report.status === 'resolved'
                          ? '✓ Đã phản hồi'
                          : report.status === 'processing'
                          ? '⏳ Đang thụ lý'
                          : 'Đã tiếp nhận'}
                      </span>

                      {(isBcnAdmin || isMyReport) && onDeleteReport && (
                        <button
                          type="button"
                          onClick={() => onDeleteReport(report.id)}
                          className="ml-2 p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition cursor-pointer flex items-center gap-1 text-[11px] font-bold"
                          title="Xóa báo cáo này"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Xóa</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Identity Box: Encrypted vs Clear */}
                  <div className="p-3.5 rounded-2xl bg-[#F0EBE0] border border-[#DDD3C0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center text-[#23432B] shadow-xs">
                        {isEncrypted ? (
                          <Lock className="w-4 h-4 text-amber-700" />
                        ) : (
                          <UserCheck className="w-4 h-4 text-emerald-700" />
                        )}
                      </div>

                      <div>
                        <div className="font-bold text-[#23432B]">
                          {isEncrypted ? (
                            isBcnAdmin && isDecrypted ? (
                              <span className="text-emerald-800 flex items-center gap-1.5 font-bold flex-wrap">
                                <span>
                                  Danh tính thực:{' '}
                                  <strong>{report.realSenderName}</strong> ({report.realSenderStudentId}) - Ban {report.realSenderDept}
                                </span>
                                <span className="text-[10px] bg-emerald-100 px-1.5 py-0.2 rounded border border-emerald-300 font-normal">
                                  Đã giải mã bởi BCN
                                </span>
                              </span>
                            ) : (
                              <span className="font-mono text-stone-600 flex items-center gap-1.5 flex-wrap">
                                <span>
                                  Mã định danh ẩn danh: <strong className="text-amber-800">{report.encryptedCode}</strong>
                                </span>
                                <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded">
                                  Bảo mật AES-256
                                </span>
                              </span>
                            )
                          ) : (
                            <span className="text-[#2C4B33]">
                              Người gửi: <strong>{report.realSenderName}</strong> ({report.realSenderStudentId}) - Ban {report.realSenderDept}
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-[#718873] mt-0.5">
                          {isEncrypted
                            ? 'Danh tính người gửi được ẩn danh hoàn toàn và chỉ Ban Chủ Nhiệm mới có quyền giải mã.'
                            : 'Báo cáo gửi trực tiếp đến Trưởng ban chuyên môn.'}
                        </div>
                      </div>
                    </div>

                    {/* Decrypt trigger button ONLY visible to BCN */}
                    {isEncrypted && isBcnAdmin && (
                      <button
                        type="button"
                        onClick={() => toggleDecryptIdentity(report.id)}
                        className="px-3.5 py-1.5 rounded-xl bg-white hover:bg-[#FBF8F0] border border-[#C5B8A3] text-xs font-bold text-[#3B6E47] flex items-center gap-1.5 shadow-xs cursor-pointer transition shrink-0"
                      >
                        {isDecrypted ? (
                          <>
                            <EyeOff className="w-3.5 h-3.5 text-stone-500" />
                            <span>Khóa ẩn danh lại</span>
                          </>
                        ) : (
                          <>
                            <Unlock className="w-3.5 h-3.5 text-amber-600" />
                            <span>Giải Mã Danh Tính</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>

                  {/* Report Content */}
                  <div className="space-y-2">
                    <h4 className="font-bold text-base text-[#1F3A24] font-serif-vintage">
                      {report.title}
                    </h4>
                    <p className="text-xs sm:text-sm text-[#384C3C] leading-relaxed whitespace-pre-line bg-[#FAF7EE] p-4 rounded-2xl border border-[#E9E1CE]">
                      {report.content}
                    </p>
                  </div>

                  {/* BCN Official Feedback Response */}
                  {report.bcnResponse && (
                    <div className="p-3.5 rounded-2xl bg-emerald-50/90 border border-emerald-200 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-emerald-900">
                        <Sparkles className="w-4 h-4 text-emerald-600" />
                        <span>Phản hồi chính thức từ Ban Chủ Nhiệm CLB:</span>
                      </div>
                      <p className="text-emerald-800 leading-relaxed pl-5">
                        {report.bcnResponse}
                      </p>
                    </div>
                  )}

                  {/* BCN Response Input (BCN can reply or update reply anytime) */}
                  {(isBcnAdmin || (isDeptLeader && report.recipientType === 'truong_ban' && report.targetDepartment === currentUser.department)) && (
                    <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 text-xs">
                      <input
                        type="text"
                        placeholder={
                          report.bcnResponse
                            ? 'Cập nhật lại phản hồi của Ban Chủ Nhiệm...'
                            : 'Nhập phản hồi chính thức từ BCN cho báo cáo này...'
                        }
                        value={responseInputs[report.id] || ''}
                        onChange={(e) => setResponseInputs(prev => ({ ...prev, [report.id]: e.target.value }))}
                        onKeyDown={(e) => e.key === 'Enter' && handleSendResponse(report.id)}
                        className="flex-1 px-3.5 py-2 rounded-xl bg-white border border-[#D5CBBC] focus:ring-1 focus:ring-[#3B6E47]"
                      />
                      <button
                        type="button"
                        onClick={() => handleSendResponse(report.id)}
                        className="px-4 py-2 rounded-xl bg-[#2D5037] hover:bg-[#203D27] text-white font-bold cursor-pointer shrink-0"
                      >
                        {report.bcnResponse ? 'Cập nhật phản hồi' : 'Gửi phản hồi BCN'}
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Modal: Compose New Confidential Report */}
      {isComposeOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#FAF7F0] rounded-2xl border-2 border-[#5E936B]/50 shadow-2xl w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col">
            <div className="bg-[#24432B] text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-emerald-300" />
                <h3 className="font-bold text-base font-serif-vintage">
                  Gửi Thư Báo Cáo Ẩn Danh & Kiến Nghị
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsComposeOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCompose} className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm">
              {/* Recipient Selection Toggle */}
              <div>
                <label className="block font-bold text-[#23432B] mb-2">
                  Bạn muốn gửi báo cáo này đến ai? *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => setRecipientChoice('bcn_master')}
                    className={`p-3.5 rounded-2xl border-2 transition cursor-pointer ${
                      recipientChoice === 'bcn_master'
                        ? 'bg-amber-50 border-amber-500 shadow-sm'
                        : 'bg-white border-[#D6CBB8] hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-bold text-amber-900 text-xs">
                      <Lock className="w-4 h-4 text-amber-600" />
                      <span>Gửi Ban Chủ Nhiệm (Ẩn danh)</span>
                    </div>
                    <p className="text-[11px] text-amber-800/80 mt-1">
                      Mã hóa AES-256 danh tính của bạn. Lưu trực tiếp vào Hòm thư mật của Ban Chủ Nhiệm.
                    </p>
                  </div>

                  <div
                    onClick={() => setRecipientChoice('truong_ban')}
                    className={`p-3.5 rounded-2xl border-2 transition cursor-pointer ${
                      recipientChoice === 'truong_ban'
                        ? 'bg-emerald-50 border-[#3B6E47] shadow-sm'
                        : 'bg-white border-[#D6CBB8] hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-bold text-emerald-900 text-xs">
                      <UserCheck className="w-4 h-4 text-emerald-700" />
                      <span>Gửi Trưởng Ban chuyên môn</span>
                    </div>
                    <p className="text-[11px] text-emerald-800/80 mt-1">
                      Gửi trực tiếp tới Trưởng ban của 1 trong 4 ban chuyên môn để hỗ trợ nhanh.
                    </p>
                  </div>
                </div>
              </div>

              {/* Target Department if sending to Lead */}
              {recipientChoice === 'truong_ban' && (
                <div>
                  <label className="block font-bold text-[#23432B] mb-1">
                    Chọn ban tiếp nhận *
                  </label>
                  <select
                    value={targetDept}
                    onChange={(e) => setTargetDept(e.target.value as DepartmentType)}
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                  >
                    <option value="Truyền thông">Ban Truyền thông</option>
                    <option value="Nội dung">Ban Nội dung</option>
                    <option value="Nhân sự & Kế hoạch">Ban Nhân sự & Kế hoạch</option>
                    <option value="Hậu cần">Ban Hậu cần</option>
                  </select>
                </div>
              )}

              {/* Category & Urgency */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-[#23432B] mb-1">Danh mục vấn đề *</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as typeof category)}
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                  >
                    <option value="Góp ý sinh hoạt">Góp ý sinh hoạt CLB</option>
                    <option value="Mâu thuẫn nội bộ">Mâu thuẫn nội bộ / Nhân sự</option>
                    <option value="Ý tưởng sự kiện">Ý tưởng sự kiện & Format mới</option>
                    <option value="Cơ sở vật chất Thư viện">Cơ sở vật chất Thư viện AGU</option>
                    <option value="Khác">Khác</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-[#23432B] mb-1">Mức độ khẩn cấp</label>
                  <select
                    value={urgency}
                    onChange={(e) => setUrgency(e.target.value as typeof urgency)}
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                  >
                    <option value="low">Nhẹ / Góp ý lâu dài</option>
                    <option value="medium">Bình thường</option>
                    <option value="high">Khẩn cấp / Cần BCN giải quyết ngay</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Tiêu đề phản ánh *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ví dụ: Đề xuất cải thiện giờ mượn sách tại tủ sách tầng 3..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Nội dung chi tiết *</label>
                <textarea
                  rows={5}
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Hãy chia sẻ chân thành và cụ thể để Ban Chủ Nhiệm lắng nghe và hỗ trợ bạn..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#DFD6C3]">
                <button
                  type="button"
                  onClick={() => setIsComposeOpen(false)}
                  className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-700 font-semibold cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#23432B] hover:bg-[#1B3522] text-white font-bold bubble-3d shadow-md cursor-pointer flex items-center gap-2"
                >
                  <Send className="w-4 h-4 text-emerald-300" />
                  <span>Gửi Vào Hòm Thư Bảo Mật</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
