import React, { useState } from 'react';
import { 
  Flame, 
  Sparkles, 
  BookOpen, 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark, 
  PlusCircle, 
  Camera, 
  Send, 
  Calendar, 
  Clock, 
  Tag, 
  MapPin, 
  X, 
  CheckCircle2, 
  Feather,
  Smile,
  BookMarked,
  Upload,
  Image as ImageIcon,
  Trash2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Post, LocketMoment, UserProfile, DepartmentType } from '../types';
import { readFileAsDataUrl } from '../utils/imageUpload';

interface NewfeedSectionProps {
  currentUser: UserProfile;
  isBcnMode?: boolean;
  posts: Post[];
  locketMoments: LocketMoment[];
  onLikePost: (postId: string) => void;
  onReactLocket: (locketId: string) => void;
  onAddPost: (newPost: Omit<Post, 'id' | 'createdAt' | 'likes' | 'commentsCount'>) => void;
  onAddLocket: (newMoment: Omit<LocketMoment, 'id' | 'timestamp' | 'reactions'>) => void;
  onDeletePost?: (postId: string) => void;
  onDeleteLocket?: (locketId: string) => void;
  onCheckIn: () => void;
  onAddComment?: (postId: string, comment: { author: string; avatar: string; text: string; time: string }) => void;
}

export const NewfeedSection: React.FC<NewfeedSectionProps> = ({
  currentUser,
  isBcnMode = false,
  posts,
  locketMoments,
  onLikePost,
  onReactLocket,
  onAddPost,
  onAddLocket,
  onDeletePost,
  onDeleteLocket,
  onCheckIn,
  onAddComment
}) => {
  const todayStr = new Date().toLocaleDateString('vi-VN');
  const isCheckedInToday = currentUser.lastCheckInDate === todayStr;
  const isBcnAdmin = isBcnMode || currentUser.role === 'bcn_admin' || currentUser.adminType === 'master_root';

  const [selectedCategory, setSelectedCategory] = useState<string>('Tất cả');
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [isLocketModalOpen, setIsLocketModalOpen] = useState(false);
  const [bookmarkedPosts, setBookmarkedPosts] = useState<string[]>(['post-1']);
  const [activeCommentsPostId, setActiveCommentsPostId] = useState<string | null>(null);
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [commentsList, setCommentsList] = useState<Record<string, { author: string; avatar: string; text: string; time: string }[]>>({
    'post-1': [
      { author: 'Lê Thị Ái Vy', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', text: 'Bài viết chạm đến cảm xúc quá Nam ơi! Miền Tây sông nước qua văn cô Tư lúc nào cũng thấm thía.', time: '1 giờ trước' },
      { author: 'ThS. Huỳnh Bảo Anh', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', text: 'Rất hoan nghênh tinh thần lan tỏa văn hóa địa phương của Ban Truyền thông.', time: '30 phút trước' }
    ]
  });

  // Floating heart animation triggers
  const [floatingHearts, setFloatingHearts] = useState<{ id: number; postId: string; x: number; y: number }[]>([]);

  // Form states for new post
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'E-News' | 'Tản văn' | 'Góc Sách AGU' | 'Điểm Tin Tuần' | 'Phóng Sự CLB'>('E-News');
  const [newBookTitle, setNewBookTitle] = useState('');
  const [newBookAuthor, setNewBookAuthor] = useState('');
  const [newExcerpt, setNewExcerpt] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCover, setNewCover] = useState('https://images.unsplash.com/photo-1512820790803-83ca734da794?w=800&auto=format&fit=crop&q=80');
  const [newTags, setNewTags] = useState('AGUBookClub, SachHay, ENews');

  // Form states for new locket
  const [newLocketCaption, setNewLocketCaption] = useState('');
  const [newLocketLocation, setNewLocketLocation] = useState('Tầng 3 Thư viện AGU');
  const [newLocketImage, setNewLocketImage] = useState('https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=600&auto=format&fit=crop&q=80');

  const categories = ['Tất cả', 'E-News', 'Tản văn', 'Góc Sách AGU', 'Phóng Sự CLB'];

  const filteredPosts = selectedCategory === 'Tất cả' 
    ? posts 
    : posts.filter(p => p.category === selectedCategory);

  const triggerLike = (e: React.MouseEvent, postId: string) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const newId = Date.now();
    setFloatingHearts(prev => [...prev, { id: newId, postId, x: rect.left + 20, y: rect.top - 10 }]);
    setTimeout(() => {
      setFloatingHearts(prev => prev.filter(h => h.id !== newId));
    }, 1000);
    onLikePost(postId);
  };

  const toggleBookmark = (postId: string) => {
    setBookmarkedPosts(prev => 
      prev.includes(postId) ? prev.filter(id => id !== postId) : [...prev, postId]
    );
  };

  const handleAddComment = (postId: string) => {
    const text = commentInputs[postId]?.trim();
    if (!text) return;

    const newComment = {
      author: currentUser.name,
      avatar: currentUser.avatar,
      text,
      time: 'Vừa xong'
    };

    setCommentsList(prev => ({
      ...prev,
      [postId]: [...(prev[postId] || []), newComment]
    }));

    if (onAddComment) {
      onAddComment(postId, newComment);
    }

    setCommentInputs(prev => ({ ...prev, [postId]: '' }));
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    onAddPost({
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar,
      authorRole: currentUser.position,
      authorDept: currentUser.department,
      title: newTitle,
      bookTitle: newBookTitle || undefined,
      bookAuthor: newBookAuthor || undefined,
      category: newCategory,
      excerpt: newExcerpt || newContent.slice(0, 140) + '...',
      content: newContent,
      coverImage: newCover,
      tags: newTags.split(',').map(t => t.trim()).filter(Boolean),
      readingTimeMinutes: Math.max(2, Math.ceil(newContent.split(' ').length / 150))
    });

    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 }
    });

    setIsPostModalOpen(false);
    setNewTitle('');
    setNewContent('');
    setNewExcerpt('');
    setNewBookTitle('');
  };

  const handleCreateLocket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLocketCaption.trim()) return;

    onAddLocket({
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar,
      department: currentUser.department,
      caption: newLocketCaption,
      location: newLocketLocation,
      imageUrl: newLocketImage
    });

    confetti({
      particleCount: 50,
      spread: 50,
      origin: { y: 0.5 }
    });

    setIsLocketModalOpen(false);
    setNewLocketCaption('');
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Floating Animated Hearts */}
      {floatingHearts.map(h => (
        <div
          key={h.id}
          className="fixed z-50 pointer-events-none animate-float-heart text-rose-500 font-bold"
          style={{ left: h.x, top: h.y }}
        >
          ❤️ +1
        </div>
      ))}

      {/* Top Banner: Vintage Classic Hero + Streak Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Welcome & Philosophy Banner */}
        <div className="lg:col-span-2 glass-vintage rounded-2xl p-5 sm:p-6 relative overflow-hidden border border-[#5E936B]/30 shadow-xs">
          <div className="relative z-10 max-w-xl space-y-2.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#E4EFE3] text-[#2F5A37] text-xs font-bold border border-[#BEDBC1]">
              <Feather className="w-3.5 h-3.5" />
              <span>Không gian Đọc & Sáng tạo Sinh viên AGU</span>
            </div>
            
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#1F3D26] font-serif-vintage tracking-tight">
              Gìn giữ ngọn lửa tri thức bên dòng phù sa An Giang
            </h2>
            
            <p className="text-xs text-[#48664D] leading-relaxed">
              Chào mừng <strong>{currentUser.name}</strong> {currentUser.nickname && <span className="text-amber-800 font-bold italic">({currentUser.nickname})</span>} ({currentUser.department}) đến với Bản tin E-News & Góc Tản văn của CLB.
            </p>

            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setIsPostModalOpen(true)}
                className="px-3.5 py-2 rounded-xl bg-[#2D5337] hover:bg-[#23422B] text-white text-xs font-bold flex items-center gap-1.5 shadow-sm bubble-3d cursor-pointer"
              >
                <PlusCircle className="w-4 h-4 text-[#7EE5B0]" />
                <span>Viết Bài E-News / Tản Văn</span>
              </button>

              <button
                type="button"
                onClick={() => setIsLocketModalOpen(true)}
                className="px-3.5 py-2 rounded-xl bg-white hover:bg-[#F2EFE8] text-[#2C4A33] border border-[#CCD7C8] text-xs font-semibold flex items-center gap-1.5 shadow-2xs cursor-pointer transition"
              >
                <Camera className="w-4 h-4 text-amber-600" />
                <span>Đăng Locket Khoảnh Khắc</span>
              </button>
            </div>
          </div>

          {/* Decorative faint stamp background */}
          <div className="absolute -right-6 -bottom-8 w-44 h-44 rounded-full border-4 border-dashed border-[#5E936B]/20 flex items-center justify-center rotate-12 pointer-events-none">
            <div className="text-center font-serif-vintage text-[#5E936B]/30 font-bold text-xs uppercase leading-tight">
              CLB Đọc Sách<br/>Đại Học An Giang<br/>★ AGU ★
            </div>
          </div>
        </div>

        {/* Streak Tracker Card */}
        <div className="glass-vintage rounded-3xl p-6 border-2 border-amber-300/60 shadow-md bg-gradient-to-br from-[#FFFDF7] to-[#FBF4E6] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-amber-200/80">
              <div className="flex items-center gap-2 text-amber-900 font-bold text-sm font-serif-vintage">
                <Flame className="w-5 h-5 text-amber-500 fill-amber-500 animate-pulse" />
                <span>Chuỗi Ngày Thử Thách</span>
              </div>
              <span className="text-[11px] font-bold text-amber-800 bg-amber-100/90 px-2 py-0.5 rounded-full border border-amber-300/80">
                Tháng 10/2026
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 my-4">
              <div className="p-3 bg-white/90 rounded-2xl border border-amber-200/70 text-center shadow-xs">
                <div className="flex items-center justify-center gap-1.5 text-2xl font-black text-amber-600">
                  <Flame className="w-6 h-6 fill-amber-500 text-amber-500" />
                  <span>{currentUser.readingStreak}</span>
                </div>
                <div className="text-[11px] font-bold text-[#455D49] mt-1">Chuỗi Đọc Sách</div>
                <div className="text-[10px] text-amber-800/80 font-medium">15 trang/ngày</div>
              </div>

              <div className="p-3 bg-white/90 rounded-2xl border border-amber-200/70 text-center shadow-xs">
                <div className="flex items-center justify-center gap-1.5 text-2xl font-black text-emerald-700">
                  <Sparkles className="w-6 h-6 text-emerald-500" />
                  <span>{currentUser.enewsStreak}</span>
                </div>
                <div className="text-[11px] font-bold text-[#455D49] mt-1">Chuỗi E-News</div>
                <div className="text-[10px] text-emerald-800/80 font-medium">Ghi chép & Viết lách</div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <button
              type="button"
              onClick={onCheckIn}
              disabled={isCheckedInToday}
              className={`w-full py-2.5 px-4 rounded-2xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition shadow-md ${
                isCheckedInToday
                  ? 'bg-[#E5EFE4] text-[#3B6E47] border border-[#BFDEC2] cursor-default'
                  : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white bubble-3d cursor-pointer'
              }`}
            >
              {isCheckedInToday ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Đã giữ chuỗi hôm nay ({todayStr}) • +10 Điểm Lửa!</span>
                </>
              ) : (
                <>
                  <Flame className="w-4 h-4 fill-white text-white animate-bounce" />
                  <span>Điểm danh Chuỗi hôm nay (+1 🔥 & +10 Điểm Lửa)</span>
                </>
              )}
            </button>
            <p className="text-[10px] text-center text-[#738875]">
              Chuỗi tự động mở khóa mỗi ngày mới hoặc tự cộng khi bạn đăng bài / Locket!
            </p>
          </div>
        </div>
      </div>

      {/* Locket Moments Reel Section */}
      <div className="glass-vintage rounded-3xl p-5 border border-[#5E936B]/30 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-700">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-[#23432B] text-sm sm:text-base font-serif-vintage">
                Locket Moments • Kỷ Niệm Thường Nhật CLB
              </h3>
              <p className="text-[11px] text-[#69846E]">
                Những khoảnh khắc chân thực của các bạn thành viên tại Thư viện & Giảng đường AGU
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsLocketModalOpen(true)}
            className="text-xs font-bold text-[#3B6E47] hover:text-[#23432B] flex items-center gap-1 bg-white/80 px-3 py-1.5 rounded-xl border border-[#CCD9CB] cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Thêm ảnh</span>
          </button>
        </div>

        {/* Horizontal Scroll of Moments */}
        <div className="flex items-stretch gap-4 overflow-x-auto pb-2 pt-1 scrollbar-thin">
          {locketMoments.map((moment) => {
            const canDeleteLocket =
              isBcnAdmin ||
              moment.authorId === currentUser.id ||
              moment.authorName.toLowerCase() === currentUser.name.toLowerCase();

            return (
              <div
                key={moment.id}
                className="w-64 shrink-0 bg-white p-3 rounded-2xl border-2 border-[#E5DECD] shadow-sm hover:shadow-md transition-all group relative flex flex-col justify-between"
              >
                {/* Photo Area with polaroid look */}
                <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-stone-100 mb-2.5">
                  <img 
                    src={moment.imageUrl} 
                    alt={moment.caption} 
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-sm text-white text-[10px]">
                    <MapPin className="w-2.5 h-2.5 text-emerald-400" />
                    <span className="truncate max-w-[120px]">{moment.location}</span>
                  </div>

                  {canDeleteLocket && onDeleteLocket && (
                    <button
                      type="button"
                      onClick={() => onDeleteLocket(moment.id)}
                      className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/65 hover:bg-rose-600 text-white transition cursor-pointer"
                      title="Xóa ảnh Locket này"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Caption & Author */}
                <div className="space-y-1.5">
                  <p className="text-xs text-[#2A3F2E] font-medium line-clamp-2 leading-relaxed">
                    {moment.caption}
                  </p>
                  
                  <div className="flex items-center justify-between pt-2 border-t border-[#EFE8DA] text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <img 
                        src={moment.authorAvatar} 
                        alt={moment.authorName} 
                        className="w-5 h-5 rounded-full object-cover ring-1 ring-[#5E936B]"
                      />
                      <span className="font-bold text-[#23432B]">{moment.authorName}</span>
                      <span className="text-[9px] text-[#718874]">({moment.timestamp})</span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onReactLocket(moment.id)}
                      className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                        moment.userReacted
                          ? 'bg-rose-50 text-rose-600 border border-rose-200'
                          : 'hover:bg-stone-100 text-stone-600'
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${moment.userReacted ? 'fill-rose-500 text-rose-500' : ''}`} />
                      <span>{moment.reactions}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Feed Section */}
      <div className="space-y-4">
        {/* Category Filter Pills */}
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-[#2B5235] text-white shadow-sm'
                    : 'bg-white/80 hover:bg-white text-[#516B54] border border-[#D5CBBC]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="text-xs text-[#638068] font-medium">
            Hiển thị {filteredPosts.length} bài viết
          </div>
        </div>

        {/* Post List */}
        <div className="space-y-6">
          {filteredPosts.map((post) => {
            const isBookmarked = bookmarkedPosts.includes(post.id);
            const comments = (post.commentsList && post.commentsList.length > 0)
              ? post.commentsList
              : (post.comments && post.comments.length > 0)
              ? post.comments
              : (commentsList[post.id] || []);
            const isCommentsOpen = activeCommentsPostId === post.id;
            const canDeletePost =
              isBcnAdmin ||
              post.authorId === currentUser.id ||
              post.authorName.toLowerCase() === currentUser.name.toLowerCase();

            return (
              <article
                key={post.id}
                className="glass-vintage rounded-2xl p-5 sm:p-6 border border-[#CADBC9]/70 shadow-xs glass-vintage-hover relative space-y-3.5"
              >
                {/* Author row & category tag */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <img 
                      src={post.authorAvatar} 
                      alt={post.authorName} 
                      className="w-10 h-10 rounded-xl object-cover ring-1 ring-[#5E936B]/40 shadow-2xs"
                    />
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="font-bold text-xs sm:text-sm text-[#23432B]">
                          {post.authorName}
                        </h4>
                        {post.authorNickname && (
                          <span className="text-[11px] font-bold text-amber-700 italic">
                            ({post.authorNickname})
                          </span>
                        )}
                        <span className="text-[9px] font-bold px-2 py-0.2 rounded-full bg-[#E5F0E4] text-[#2C5734] border border-[#C5DDC6]">
                          {post.authorDept}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-[#718B74] mt-0.5">
                        <span>{post.authorRole}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {post.createdAt}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#F3ECDD] text-[#765D30] border border-[#DECFB5]">
                      {post.category}
                    </span>
                    <button
                      type="button"
                      onClick={() => toggleBookmark(post.id)}
                      className={`p-2 rounded-xl transition cursor-pointer ${
                        isBookmarked 
                          ? 'bg-amber-100 text-amber-700' 
                          : 'hover:bg-stone-200/50 text-stone-500'
                      }`}
                      title={isBookmarked ? 'Bỏ lưu' : 'Lưu bài viết'}
                    >
                      <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-600' : ''}`} />
                    </button>
                    {canDeletePost && onDeletePost && (
                      <button
                        type="button"
                        onClick={() => onDeletePost(post.id)}
                        className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition cursor-pointer"
                        title="Xóa bài viết này"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Article Header & Book Reference */}
                <div className="space-y-2">
                  <h3 className="text-lg sm:text-xl font-extrabold text-[#1F3A24] font-serif-vintage tracking-tight leading-snug">
                    {post.title}
                  </h3>

                  {post.bookTitle && (
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-[#F0EBE0] text-[#5C4D32] text-xs font-medium border border-[#DDD3BF]">
                      <BookOpen className="w-3.5 h-3.5 text-amber-700" />
                      <span>Tác phẩm: <strong>{post.bookTitle}</strong> {post.bookAuthor && `(Tác giả: ${post.bookAuthor})`}</span>
                    </div>
                  )}
                </div>

                {/* Cover Image if available */}
                {post.coverImage && (
                  <div className="relative aspect-[21/9] sm:aspect-[24/9] rounded-2xl overflow-hidden shadow-xs border border-[#E3DAC8]">
                    <img 
                      src={post.coverImage} 
                      alt={post.title} 
                      className="w-full h-full object-cover hover:scale-102 transition duration-500"
                    />
                    <div className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-black/60 text-white text-[11px] backdrop-blur-xs">
                      {post.readingTimeMinutes} phút đọc
                    </div>
                  </div>
                )}

                {/* Excerpt and Content */}
                <div className="space-y-3 text-xs sm:text-sm text-[#384C3C] font-reading leading-relaxed">
                  <p className="italic font-serif text-[#465E4A] bg-[#F7F4EA] p-3 rounded-2xl border-l-4 border-[#5E936B]">
                    "{post.excerpt}"
                  </p>
                  <p className="whitespace-pre-line text-[#2B3E2F]">
                    {post.content}
                  </p>
                </div>

                {/* Tags */}
                {post.tags && post.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {post.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] font-medium text-[#4D6D53] bg-[#E9F2E8] px-2.5 py-0.5 rounded-lg hover:bg-[#D8E9D7] cursor-pointer"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}

                {/* Interactive Footer: Likes, Comments, Share */}
                <div className="flex items-center justify-between pt-3 border-t border-[#E5DCBE] text-xs">
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={(e) => triggerLike(e, post.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
                        post.userLiked
                          ? 'bg-rose-50 text-rose-600 border border-rose-200'
                          : 'bg-white hover:bg-rose-50 text-stone-600 border border-[#D5CBBC]'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${post.userLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                      <span>{post.likes} Yêu thích</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveCommentsPostId(isCommentsOpen ? null : post.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-stone-100 text-stone-600 border border-[#D5CBBC] font-semibold transition cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4 text-emerald-700" />
                      <span>{comments.length || post.commentsCount} Bình luận</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(window.location.href);
                      alert('Đã sao chép liên kết bài viết CLB Đọc Sách AGU!');
                    }}
                    className="p-1.5 rounded-lg hover:bg-stone-200/50 text-stone-500 flex items-center gap-1 cursor-pointer"
                    title="Chia sẻ bài viết"
                  >
                    <Share2 className="w-4 h-4" />
                    <span className="hidden sm:inline text-xs">Chia sẻ</span>
                  </button>
                </div>

                {/* Comments Expandable Box */}
                {isCommentsOpen && (
                  <div className="bg-[#F8F5EE] rounded-2xl p-4 border border-[#DFD6C3] space-y-3 animate-in fade-in duration-200">
                    <h5 className="font-bold text-xs text-[#2A442F]">
                      Thảo luận ({comments.length})
                    </h5>

                    {comments.map((c, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs">
                        <img 
                          src={c.avatar} 
                          alt={c.author} 
                          className="w-7 h-7 rounded-full object-cover ring-1 ring-[#5E936B] shrink-0 mt-0.5" 
                        />
                        <div className="bg-white p-2.5 rounded-2xl border border-[#E3DAC8] flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-[#23432B]">{c.author}</span>
                            <span className="text-[10px] text-stone-400">{c.time}</span>
                          </div>
                          <p className="text-[#3A4E3E] mt-1">{c.text}</p>
                        </div>
                      </div>
                    ))}

                    {/* New Comment Input */}
                    <div className="flex items-center gap-2 pt-1">
                      <img 
                        src={currentUser.avatar} 
                        alt={currentUser.name} 
                        className="w-7 h-7 rounded-full object-cover ring-1 ring-[#5E936B] shrink-0" 
                      />
                      <input
                        type="text"
                        value={commentInputs[post.id] || ''}
                        onChange={(e) => setCommentInputs(prev => ({ ...prev, [post.id]: e.target.value }))}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddComment(post.id)}
                        placeholder="Để lại cảm nghĩ của bạn về bài viết..."
                        className="flex-1 px-3 py-2 rounded-xl bg-white border border-[#D5CABB] text-xs focus:outline-none focus:ring-1 focus:ring-[#3B6E47]"
                      />
                      <button
                        type="button"
                        onClick={() => handleAddComment(post.id)}
                        className="p-2 rounded-xl bg-[#3B6E47] hover:bg-[#2C5536] text-white cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      </div>

      {/* Modal: Write New E-News / Essay */}
      {isPostModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#FAF7F0] rounded-3xl border-2 border-[#5E936B]/50 shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
            <div className="bg-[#26472D] text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Feather className="w-5 h-5 text-emerald-300" />
                <h3 className="font-bold text-base font-serif-vintage">
                  Đăng Bài Viết E-News & Tản Văn Mới
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsPostModalOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePost} className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-[#23432B] mb-1">Chuyên mục bài viết *</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                  >
                    <option value="E-News">Bản tin E-News</option>
                    <option value="Tản văn">Tản văn & Cảm xúc</option>
                    <option value="Góc Sách AGU">Góc Sách AGU</option>
                    <option value="Phóng Sự CLB">Phóng Sự Hoạt Động CLB</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-[#23432B] mb-1">Tags (phân cách bởi dấu phẩy)</label>
                  <input
                    type="text"
                    value={newTags}
                    onChange={(e) => setNewTags(e.target.value)}
                    placeholder="AGU, DocSach, TriThuc..."
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Tiêu đề bài viết *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Ví dụ: Đọc lại 'Chiếc Lá Cuối Cùng' giữa những ngày thi..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white font-bold text-sm focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-[#23432B] mb-1">Tên cuốn sách (nếu có)</label>
                  <input
                    type="text"
                    value={newBookTitle}
                    onChange={(e) => setNewBookTitle(e.target.value)}
                    placeholder="Ví dụ: Cây Cam Ngọt Của Tôi"
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#23432B] mb-1">Tác giả cuốn sách</label>
                  <input
                    type="text"
                    value={newBookAuthor}
                    onChange={(e) => setNewBookAuthor(e.target.value)}
                    placeholder="Ví dụ: José Mauro de Vasconcelos"
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-[#23432B]">Ảnh bìa bài viết *</label>
                  <label className="text-xs font-bold text-[#2E5839] hover:underline flex items-center gap-1 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Tải ảnh từ máy</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const b64 = await readFileAsDataUrl(file, 1200, 0.82);
                            setNewCover(b64);
                          } catch (err: any) {
                            alert(err.message || 'Lỗi tải ảnh');
                          }
                        }
                      }}
                    />
                  </label>
                </div>
                <input
                  type="text"
                  value={newCover.startsWith('data:') ? 'Đã tải ảnh trực tiếp từ thiết bị ✓' : newCover}
                  onChange={(e) => setNewCover(e.target.value)}
                  placeholder="Dán link ảnh URL hoặc bấm Tải ảnh từ máy ở trên..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
                {newCover && (
                  <div className="mt-2 aspect-[21/9] rounded-xl overflow-hidden bg-stone-100 border border-stone-200">
                    <img src={newCover} alt="Cover Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Trích đoạn nổi bật (Excerpt)</label>
                <input
                  type="text"
                  value={newExcerpt}
                  onChange={(e) => setNewExcerpt(e.target.value)}
                  placeholder="Một câu quote hoặc dòng tóm tắt sâu sắc..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Nội dung chi tiết *</label>
                <textarea
                  rows={6}
                  required
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="Viết cảm nghĩ, bài điểm sách, hoặc chia sẻ góc nhìn của bạn..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white font-reading text-sm focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#DFD6C3]">
                <button
                  type="button"
                  onClick={() => setIsPostModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-700 font-semibold cursor-pointer"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#2D5337] hover:bg-[#23422B] text-white font-bold bubble-3d shadow-md cursor-pointer flex items-center gap-2"
                >
                  <Send className="w-4 h-4 text-emerald-300" />
                  <span>Xuất Bản Bài Viết</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Locket Moment */}
      {isLocketModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#FAF7F0] rounded-3xl border-2 border-amber-300 shadow-2xl w-full max-w-md overflow-hidden">
            <div className="bg-gradient-to-r from-amber-700 to-amber-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-amber-200" />
                <h3 className="font-bold text-base font-serif-vintage">
                  Đăng Locket Khoảnh Khắc CLB
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsLocketModalOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateLocket} className="p-5 space-y-4 text-xs sm:text-sm">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-[#23432B]">Ảnh khoảnh khắc Locket *</label>
                  <label className="text-xs font-bold text-amber-800 hover:underline flex items-center gap-1 cursor-pointer">
                    <Camera className="w-3.5 h-3.5" />
                    <span>Chụp / Tải ảnh từ máy</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const b64 = await readFileAsDataUrl(file, 900, 0.85);
                            setNewLocketImage(b64);
                          } catch (err: any) {
                            alert(err.message || 'Lỗi đọc ảnh');
                          }
                        }
                      }}
                    />
                  </label>
                </div>
                <input
                  type="text"
                  value={newLocketImage.startsWith('data:') ? 'Đã tải ảnh khoảnh khắc từ máy ✓' : newLocketImage}
                  onChange={(e) => setNewLocketImage(e.target.value)}
                  placeholder="Dán link ảnh URL hoặc bấm Chụp / Tải ảnh ở trên..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-amber-500"
                />
                <div className="mt-2 aspect-video rounded-xl overflow-hidden bg-stone-100 border border-stone-200">
                  <img src={newLocketImage} alt="Preview" className="w-full h-full object-cover" />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Địa điểm chụp tại AGU</label>
                <input
                  type="text"
                  value={newLocketLocation}
                  onChange={(e) => setNewLocketLocation(e.target.value)}
                  placeholder="Ví dụ: Tầng 3 Thư viện AGU / Bờ hồ khuôn viên mới"
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Lời nhắn Locket *</label>
                <textarea
                  rows={3}
                  required
                  value={newLocketCaption}
                  onChange={(e) => setNewLocketCaption(e.target.value)}
                  placeholder="Cảm nghĩ ngắn, câu nói vui cùng đồng đội..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#DFD6C3]">
                <button
                  type="button"
                  onClick={() => setIsLocketModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-700 font-semibold cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold bubble-3d shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-4 h-4" />
                  <span>Đăng Locket</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
