import React, { useState } from 'react';
import { 
  Users2, 
  Award, 
  Sparkles, 
  Mail, 
  BookOpen, 
  Crown, 
  Search, 
  ShieldCheck, 
  Layers,
  ChevronRight,
  Flame,
  Star
} from 'lucide-react';
import { ClubDepartment, UserProfile, DepartmentType } from '../types';
import { DEPARTMENTS_DATA } from '../data/mockData';

interface OrgChartSectionProps {
  currentUser: UserProfile;
  isBcnMode: boolean;
  userList: UserProfile[];
}

export const OrgChartSection: React.FC<OrgChartSectionProps> = ({
  currentUser,
  isBcnMode,
  userList
}) => {
  const [selectedDeptId, setSelectedDeptId] = useState<DepartmentType | 'all'>('all');
  const [searchMember, setSearchMember] = useState('');

  const departments = DEPARTMENTS_DATA;

  // Dynamic BCN Elected Student Leaders from userList
  const electedBcnLeaders = userList.filter(u => u.adminType === 'bcn_elected' || (u.role === 'bcn_admin' && u.id !== 'bcn-root'));

  // Filtered members list from dynamic userList
  const filteredMembers = userList.filter((user) => {
    const matchesDept = selectedDeptId === 'all' || user.department === selectedDeptId;
    const matchesSearch = user.name.toLowerCase().includes(searchMember.toLowerCase()) ||
                          (user.nickname && user.nickname.toLowerCase().includes(searchMember.toLowerCase())) ||
                          user.studentId.toLowerCase().includes(searchMember.toLowerCase()) ||
                          user.faculty.toLowerCase().includes(searchMember.toLowerCase());
    return matchesDept && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="glass-vintage p-5 sm:p-6 border border-[#5E936B]/30 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1.5 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#E5F0E4] text-[#244A2B] text-xs font-bold border border-[#BEDBC1]">
            <Users2 className="w-3.5 h-3.5 text-emerald-700" />
            <span>Cơ Cấu Tổ Chức 4 Ban Chuyên Môn CLB</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-bold text-[#1F3D26] font-serif-vintage tracking-tight">
            Sơ Đồ Nhân Sự & Đại Gia Đình CLB Sách
          </h2>

          <p className="text-xs text-[#48664D] leading-relaxed">
            Mô hình 100% tự quản bởi sinh viên với hơn 64 thành viên nhiệt huyết gắn kết qua từng trang sách. 4 ban vận hành: <strong>Truyền thông</strong>, <strong>Nội dung</strong>, <strong>Nhân sự & Kế hoạch (Trọng yếu)</strong>, và <strong>Hậu cần</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-[#FAF5E8] p-2.5 rounded-xl border border-[#DFD5C2] text-xs text-[#526B57] shrink-0">
          <Layers className="w-4 h-4 text-amber-700 shrink-0" />
          <span>4 Ban Chuyên Môn • {userList.length} Nhân Sự Sinh Viên</span>
        </div>
      </div>

      {/* Visual Organizational Hierarchy Tree */}
      <div className="space-y-5">
        {/* Tier 1: Ban Chủ Nhiệm (1 Account Gốc + 3 Account Sinh Viên Bầu Cử) */}
        <div className="flex flex-col items-center">
          <div className="bg-gradient-to-br from-[#1C3621] to-[#2B5234] text-white p-4 sm:p-5 rounded-2xl border-2 border-amber-400 shadow-md max-w-2xl w-full text-center space-y-3 relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-amber-400 text-stone-900 font-extrabold text-[10px] uppercase tracking-wider flex items-center gap-1 shadow-2xs">
              <Crown className="w-3 h-3" />
              Cơ Cấu Ban Chủ Nhiệm (100% Tự Quản Sinh Viên)
            </div>

            {/* Root Account Badge */}
            <div className="p-3 bg-[#132817] rounded-xl border border-amber-400/40 text-left flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-400/20 text-amber-300 border border-amber-400/50 flex items-center justify-center font-bold text-lg">
                  📖
                </div>
                <div>
                  <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    Tài khoản Gốc Vĩnh viễn (Master Account)
                    <span className="text-[9px] bg-amber-400 text-stone-900 px-1.5 py-0.2 rounded font-extrabold">Bất biến</span>
                  </div>
                  <div className="text-sm font-bold text-white font-serif-vintage">Câu lạc bộ Đọc và Giới thiệu sách</div>
                  <div className="text-[10px] text-emerald-200">Email chính thức: clb.docsach@agu.edu.vn • Độc quyền phân quyền BCN & Trưởng/Phó 4 Ban</div>
                </div>
              </div>
              <ShieldCheck className="w-5 h-5 text-amber-300 shrink-0" />
            </div>

            {/* Dynamic Elected Student Leaders */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1 text-left">
              {electedBcnLeaders.slice(0, 3).map((leader) => (
                <div key={leader.id} className="p-2.5 rounded-xl bg-white/10 border border-white/10 backdrop-blur-xs flex items-center gap-2.5">
                  <img
                    src={leader.avatar}
                    alt={leader.name}
                    className="w-9 h-9 rounded-lg object-cover ring-1 ring-amber-400 shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="text-[10px] font-bold text-amber-300 truncate">{leader.position || 'Ban Chủ Nhiệm'}</div>
                    <div className="text-xs font-bold text-white font-serif-vintage truncate">{leader.name}</div>
                    {leader.nickname && (
                      <div className="text-[9px] text-emerald-200 italic truncate">"{leader.nickname}"</div>
                    )}
                    <div className="text-[8px] text-stone-300 mt-0.5 truncate">{leader.studentId} • Đương nhiệm</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-[#3B6645] text-[10px] text-[#C2DEC6] flex items-center justify-between">
              <span>Được bầu chọn & bổ nhiệm qua Tài khoản Chính thức CLB</span>
              <span>Lịch sử các cựu BCN lưu tại Bảo Tàng Thành Tựu</span>
            </div>
          </div>

          <div className="w-0.5 h-6 bg-[#8BAE90] my-1" />
          <div className="w-2 h-2 rounded-full bg-[#3B6E47]" />
        </div>

        {/* Tier 2: 4 Specialized Departments Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {departments.map((dept) => {
            const isSelected = selectedDeptId === dept.id;
            const isStrategic = dept.id === 'Nhân sự & Kế hoạch';

            // Dynamically find Trưởng Ban & Phó Ban from userList if appointed
            const deptMembers = userList.filter(u => u.department === dept.id);
            const dynamicLeader =
              deptMembers.find(u => u.departmentRole === 'leader') ||
              deptMembers.find(u => u.position?.toLowerCase().includes('trưởng ban')) ||
              deptMembers.find(u => u.role === 'lead');
            const dynamicViceLeaders = deptMembers.filter(
              u =>
                u.id !== dynamicLeader?.id &&
                (u.departmentRole === 'vice_leader' || u.position?.toLowerCase().includes('phó ban'))
            );

            const leadName = dynamicLeader ? dynamicLeader.name : dept.lead;
            const leadNickname = dynamicLeader ? dynamicLeader.nickname : dept.leadNickname;
            const leadAvatar = dynamicLeader ? dynamicLeader.avatar : dept.leadAvatar;
            const leadTitle = dynamicLeader ? (dynamicLeader.position || `Trưởng ban ${dept.id}`) : dept.leadTitle;

            return (
              <div
                key={dept.id}
                onClick={() => setSelectedDeptId(isSelected ? 'all' : dept.id)}
                className={`glass-vintage p-4 sm:p-5 border transition cursor-pointer flex flex-col justify-between group ${
                  isSelected 
                    ? 'border-[#3B6E47] bg-[#F4F9F3] shadow-md scale-[1.01] ring-1 ring-[#3B6E47]' 
                    : 'border-[#DAD0BD] bg-white hover:border-[#8BAE90]'
                }`}
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span 
                        className="px-2 py-0.5 rounded-md text-white text-[10px] font-bold shadow-2xs"
                        style={{ backgroundColor: dept.color }}
                      >
                        {dept.id}
                      </span>
                      {isStrategic && (
                        <span className="text-[9px] font-extrabold bg-amber-100 text-amber-900 px-1.5 py-0.2 rounded border border-amber-300 flex items-center gap-0.5">
                          <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                          Trọng yếu
                        </span>
                      )}
                    </div>

                    <span className="text-[10px] font-bold text-[#557058] bg-[#EAE2D2] px-1.5 py-0.2 rounded">
                      {Math.max(dept.memberCount, deptMembers.length)} TV
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-[#1E3A24] font-serif-vintage group-hover:text-[#3B6E47] transition">
                      {dept.name}
                    </h4>
                    <p className="text-xs text-[#526D57] mt-1 leading-relaxed line-clamp-3">
                      {dept.mission}
                    </p>
                  </div>

                  {/* Leader info with nickname */}
                  <div className="p-2.5 rounded-xl bg-[#F8F5EE] border border-[#E3DAC9] flex items-center gap-2.5">
                    <img 
                      src={leadAvatar} 
                      alt={leadName} 
                      className="w-9 h-9 rounded-lg object-cover ring-1 ring-[#5E936B] shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="font-bold text-xs text-[#23432B] truncate">
                        {leadName}
                      </div>
                      {leadNickname && (
                        <div className="text-[10px] text-amber-700 italic truncate">
                          "{leadNickname}"
                        </div>
                      )}
                      <div className="text-[10px] text-[#5E936B] font-semibold truncate">
                        {leadTitle}
                      </div>
                    </div>
                  </div>

                  {/* Vice Leaders if any */}
                  {dynamicViceLeaders.length > 0 && (
                    <div className="space-y-1">
                      {dynamicViceLeaders.map(vl => (
                        <div key={vl.id} className="px-2.5 py-1.5 rounded-lg bg-emerald-50/70 border border-emerald-200 flex items-center gap-2">
                          <img src={vl.avatar} alt={vl.name} className="w-6 h-6 rounded-md object-cover shrink-0" />
                          <div className="min-w-0 flex-1">
                            <div className="font-bold text-[11px] text-[#1E3A24] truncate">{vl.name}</div>
                            <div className="text-[9px] text-emerald-800 font-semibold truncate">
                              {vl.position || `Phó ban ${dept.id}`}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Badges */}
                <div className="pt-2.5 mt-2.5 border-t border-[#EAE3D4] space-y-1.5">
                  <div className="flex flex-wrap gap-1">
                    {dept.badges.map((b, i) => (
                      <span key={i} className="text-[9px] font-medium bg-white px-1.5 py-0.2 rounded border border-[#DFD6C3] text-stone-700">
                        {b}
                      </span>
                    ))}
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] font-bold text-[#3B6E47] inline-flex items-center gap-0.5 group-hover:translate-x-1 transition">
                      {isSelected ? 'Đang lọc xem ban này' : 'Xem danh sách'} <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Member Directory */}
      <div className="glass-vintage p-5 sm:p-6 border border-[#5E936B]/30 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-sm sm:text-base text-[#23432B] font-serif-vintage">
              Danh Bạ Nhân Sự CLB ({filteredMembers.length} thành viên)
            </h3>
            <p className="text-xs text-[#627E67]">
              Xem hồ sơ, bút danh / nickname, và điểm lửa cống hiến
            </p>
          </div>

          <div className="flex items-center gap-2">
            {selectedDeptId !== 'all' && (
              <button
                type="button"
                onClick={() => setSelectedDeptId('all')}
                className="text-xs font-bold text-amber-800 bg-amber-100 hover:bg-amber-200 px-2.5 py-1.5 rounded-lg cursor-pointer"
              >
                Hủy lọc {selectedDeptId} ✕
              </button>
            )}

            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input 
                type="text"
                value={searchMember}
                onChange={(e) => setSearchMember(e.target.value)}
                placeholder="Tìm tên, nickname, MSSV..."
                className="pl-8 pr-3 py-1.5 rounded-xl bg-white border border-[#D5CBBC] text-xs focus:ring-1 focus:ring-[#3B6E47]"
              />
            </div>
          </div>
        </div>

        {/* Member cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {filteredMembers.map((member) => (
            <div
              key={member.id}
              className="bg-white p-3.5 rounded-xl border border-[#DED4C3] flex items-start gap-3 hover:border-[#8BAE90] transition shadow-2xs"
            >
              <img 
                src={member.avatar} 
                alt={member.name} 
                className="w-11 h-11 rounded-xl object-cover ring-1 ring-[#5E936B]/40 shrink-0"
              />
              <div className="min-w-0 flex-1 space-y-0.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs text-[#23432B] truncate">
                    {member.name}
                  </h4>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-[#E5F0E4] text-[#2C5734] shrink-0">
                    {member.department}
                  </span>
                </div>

                {member.nickname && (
                  <p className="text-[11px] font-bold text-amber-700 italic truncate">
                    {member.nickname}
                  </p>
                )}

                <p className="text-[10px] text-[#4C6B51] font-semibold truncate">
                  {member.studentId} • {member.faculty.split(' ')[0]}
                </p>

                {member.badges && member.badges.length > 0 && (
                  <div className="flex flex-wrap gap-1 pt-1">
                    {member.badges.map((b, i) => (
                      <span key={i} className="text-[8px] font-bold bg-amber-50 text-amber-800 border border-amber-200 px-1.5 py-0.2 rounded">
                        {b}
                      </span>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between pt-1.5 border-t border-[#EFE8DA] text-[10px] text-stone-500">
                  <span className="text-amber-700 font-bold flex items-center gap-0.5">
                    <Flame className="w-3 h-3 fill-amber-500" />
                    {member.readingStreak}d
                  </span>
                  <span className="text-emerald-700 font-bold">
                    +{member.meritPoints || 50} Điểm Lửa
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
