import React, { useState } from 'react';
import { 
  Vault, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart, 
  PlusCircle, 
  Download, 
  Lock, 
  ShieldCheck, 
  Receipt, 
  Filter, 
  Search, 
  FileSpreadsheet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  X,
  Sparkles,
  Calendar,
  Camera,
  Upload,
  Image as ImageIcon,
  Eye
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Transaction, UserProfile } from '../types';
import { MASTER_PASSCODE } from '../data/mockData';

interface FinancialVaultSectionProps {
  currentUser: UserProfile;
  transactions: Transaction[];
  isBcnMode: boolean;
  onUnlockBcn: (passcode: string) => boolean;
  onAddTransaction: (newTx: Omit<Transaction, 'id'>) => void;
  onOpenAuthModal: () => void;
}

export const FinancialVaultSection: React.FC<FinancialVaultSectionProps> = ({
  currentUser,
  transactions,
  isBcnMode,
  onUnlockBcn,
  onAddTransaction,
  onOpenAuthModal
}) => {
  const [passcodeInput, setPasscodeInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New Transaction form
  const [newType, setNewType] = useState<'income' | 'expense'>('expense');
  const [newTitle, setNewTitle] = useState('');
  const [newAmount, setNewAmount] = useState<number>(150000);
  const [newCategory, setNewCategory] = useState<Transaction['category']>('Mua sách mới');
  const [newPerformedBy, setNewPerformedBy] = useState(`${currentUser.name} (${currentUser.department})`);
  const [newNote, setNewNote] = useState('');
  const [newReceiptImage, setNewReceiptImage] = useState<string>('');
  const [previewReceiptTx, setPreviewReceiptTx] = useState<Transaction | null>(null);
  const receiptFileInputRef = React.useRef<HTMLInputElement>(null);

  // Calculations
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const currentBalance = totalIncome - totalExpense;

  // Filtered transactions
  const filteredList = transactions.filter(t => {
    const matchesType = filterType === 'all' || t.type === filterType;
    const matchesSearch = t.title.toLowerCase().includes(searchKeyword.toLowerCase()) ||
                          t.category.toLowerCase().includes(searchKeyword.toLowerCase()) ||
                          t.receiptCode.toLowerCase().includes(searchKeyword.toLowerCase());
    return matchesType && matchesSearch;
  });

  // Category breakdown for expense distribution bar
  const expenseByCategory = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, curr) => {
      acc[curr.category] = (acc[curr.category] || 0) + curr.amount;
      return acc;
    }, {} as Record<string, number>);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcodeInput.trim() === MASTER_PASSCODE) {
      onUnlockBcn(passcodeInput);
      setErrorMsg('');
      setPasscodeInput('');
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.5 }
      });
    } else {
      setErrorMsg('Mật mã BCN không đúng. Vui lòng nhập AGU2026.');
    }
  };

  const handleCreateTx = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || newAmount <= 0) return;

    const receiptPrefix = newType === 'income' ? 'PT' : 'PC';
    const randomCode = Math.floor(100 + Math.random() * 900);
    const receiptCode = `${receiptPrefix}-2026-${randomCode}`;

    onAddTransaction({
      type: newType,
      title: newTitle,
      amount: Number(newAmount),
      category: newCategory,
      date: new Date().toLocaleDateString('vi-VN'),
      performedBy: newPerformedBy,
      approvedBy: 'ThS. Huỳnh Bảo Anh (Chủ nhiệm CLB)',
      receiptCode,
      note: newNote,
      receiptImage: newReceiptImage || undefined
    });

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.6 }
    });

    setIsModalOpen(false);
    setNewTitle('');
    setNewNote('');
    setNewReceiptImage('');
  };

  const exportFinancialReport = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Mã phiếu,Loại,Hạng mục,Nội dung,Số tiền (VNĐ),Ngày,Người lập\n"
      + transactions.map(t => `"${t.receiptCode}","${t.type === 'income' ? 'Thu' : 'Chi'}","${t.category}","${t.title}","${t.amount}","${t.date}","${t.performedBy}"`).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `BaoCao_QuyCLB_AGU_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatVND = (num: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(num);
  };

  // If NOT in BCN mode, show the secure vault door screen
  if (!isBcnMode) {
    return (
      <div className="glass-vintage rounded-2xl p-8 sm:p-12 border-2 border-amber-300/80 shadow-2xl text-center max-w-2xl mx-auto space-y-6 animate-in zoom-in-95 duration-300">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#203D27] to-[#3B6E47] text-amber-300 flex items-center justify-center mx-auto shadow-xl border-4 border-amber-300/40">
          <Vault className="w-10 h-10" />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold border border-amber-300">
            <Lock className="w-3.5 h-3.5 text-amber-700" />
            <span>Khu Vực Bảo Mật Ban Chủ Nhiệm (Financial Vault)</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1F3D26] font-serif-vintage">
            Két Quỹ & Ngân Sách CLB Đọc Sách AGU
          </h2>
          <p className="text-xs sm:text-sm text-[#4A6450] max-w-md mx-auto leading-relaxed">
            Khu vực này lưu trữ toàn bộ hồ sơ thu/chi hội phí, hóa đơn mua sách mới tại Thư viện AGU và tiền tài trợ. Vui lòng nhập Master Passcode BCN để truy cập.
          </p>
        </div>

        <form onSubmit={handleUnlock} className="max-w-sm mx-auto space-y-3 pt-2">
          <div className="relative">
            <input
              type="password"
              value={passcodeInput}
              onChange={(e) => setPasscodeInput(e.target.value)}
              placeholder="Nhập Master Passcode (AGU2026)"
              className="w-full px-4 py-3 rounded-2xl border-2 border-[#C5BBA7] bg-white text-center font-mono font-bold text-base focus:ring-2 focus:ring-[#3B6E47] focus:outline-none"
            />
          </div>

          {errorMsg && (
            <p className="text-xs text-rose-600 font-semibold">{errorMsg}</p>
          )}

          <div className="flex items-center justify-between gap-3 pt-2">
            <button
              type="button"
              onClick={() => setPasscodeInput('AGU2026')}
              className="text-xs text-[#3B6E47] font-bold hover:underline cursor-pointer"
            >
              Mã dùng thử: AGU2026
            </button>

            <button
              type="submit"
              className="px-6 py-2.5 rounded-2xl bg-[#23432B] hover:bg-[#193220] text-white text-xs font-bold bubble-3d shadow-md cursor-pointer flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-300" />
              <span>Mở Két Quỹ BCN</span>
            </button>
          </div>
        </form>

        <div className="pt-4 border-t border-[#DFD6C3] text-xs text-stone-500">
          Chỉ 2 người trong Ban Chủ Nhiệm trường ĐH An Giang được cấp quyền quản trị ngân sách này.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="glass-vintage rounded-2xl p-6 sm:p-7 border border-[#5E936B]/30 shadow-md flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold border border-amber-300">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
            <span>Két Quỹ Ban Chủ Nhiệm • Minh Bạch 100%</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1F3D26] font-serif-vintage tracking-tight">
            Két Quỹ & Quản Lý Ngân Sách CLB
          </h2>

          <p className="text-xs sm:text-sm text-[#48664D] leading-relaxed">
            Theo dõi chi tiết các dòng tiền: Quỹ hội phí thành viên, tiền tài trợ sách, chi phí in ấn Bookmark trao tặng tân sinh viên, và tổ chức talkshow tại ĐH An Giang.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={exportFinancialReport}
            className="px-4 py-2.5 rounded-2xl bg-white hover:bg-[#F2ECE1] text-[#2C4831] border border-[#CAD5C7] text-xs sm:text-sm font-bold flex items-center gap-2 shadow-xs cursor-pointer transition"
          >
            <Download className="w-4 h-4 text-emerald-700" />
            <span>Xuất Báo Cáo CSV</span>
          </button>

          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="px-5 py-2.5 rounded-2xl bg-[#23432B] hover:bg-[#193220] text-white text-xs sm:text-sm font-bold flex items-center gap-2 shadow-md bubble-3d cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-emerald-300" />
            <span>Tạo Phiếu Thu / Chi Mới</span>
          </button>
        </div>
      </div>

      {/* Financial Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Current Net Balance */}
        <div className="glass-vintage rounded-2xl p-5 border-2 border-emerald-500/50 bg-gradient-to-br from-[#F5FAF4] to-white shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-emerald-800">
            <span>Số Dư Quỹ Hiện Có</span>
            <Vault className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-[#193D21]">
            {formatVND(currentBalance)}
          </div>
          <p className="text-[11px] text-emerald-700 font-medium">
            Sẵn sàng cho chuỗi hoạt động Tháng 11
          </p>
        </div>

        {/* Total Income */}
        <div className="glass-vintage rounded-2xl p-5 border border-[#CFDFCD] bg-white shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-[#456B4C]">
            <span>Tổng Thu Vào</span>
            <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700">
              <ArrowDownLeft className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700">
            {formatVND(totalIncome)}
          </div>
          <p className="text-[11px] text-[#69886E]">
            Gồm hội phí & tài trợ cựu sinh viên
          </p>
        </div>

        {/* Total Expense */}
        <div className="glass-vintage rounded-2xl p-5 border border-[#E8D9C8] bg-white shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-amber-900">
            <span>Tổng Đã Chi Ra</span>
            <div className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center text-amber-700">
              <ArrowUpRight className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-700">
            {formatVND(totalExpense)}
          </div>
          <p className="text-[11px] text-amber-800/80">
            Mua sách mới, in ấn, teabreak
          </p>
        </div>

        {/* Reserve Fund for Books */}
        <div className="glass-vintage rounded-2xl p-5 border border-blue-200 bg-gradient-to-br from-blue-50/60 to-white shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-blue-900">
            <span>Quỹ Mua Sách Mới</span>
            <Receipt className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-black text-blue-700">
            {formatVND(2000000)}
          </div>
          <p className="text-[11px] text-blue-600 font-medium">
            Dự kiến nhập 30 cuốn sách Tri Tôn
          </p>
        </div>
      </div>

      {/* Expense Allocation Distribution Bar */}
      <div className="glass-vintage rounded-2xl p-6 border border-[#5E936B]/30 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm sm:text-base text-[#23432B] font-serif-vintage flex items-center gap-2">
            <PieChart className="w-4 h-4 text-emerald-700" />
            <span>Cơ Cấu Phân Bổ Chi Tiêu Hoạt Động</span>
          </h3>
          <span className="text-xs text-[#638068]">Tổng chi: {formatVND(totalExpense)}</span>
        </div>

        <div className="w-full bg-[#EAE2D2] rounded-2xl h-4 overflow-hidden flex shadow-inner">
          {Object.entries(expenseByCategory).map(([cat, amount], idx) => {
            const percent = totalExpense > 0 ? (amount / totalExpense) * 100 : 0;
            const colors = ['bg-[#3B6E47]', 'bg-amber-600', 'bg-blue-600', 'bg-rose-600', 'bg-purple-600'];
            const colorClass = colors[idx % colors.length];
            return (
              <div
                key={cat}
                style={{ width: `${percent}%` }}
                className={`${colorClass} h-full transition-all duration-500`}
                title={`${cat}: ${formatVND(amount)} (${percent.toFixed(1)}%)`}
              />
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs">
          {Object.entries(expenseByCategory).map(([cat, amount], idx) => {
            const percent = totalExpense > 0 ? ((amount / totalExpense) * 100).toFixed(1) : 0;
            const dotColors = ['bg-[#3B6E47]', 'bg-amber-600', 'bg-blue-600', 'bg-rose-600', 'bg-purple-600'];
            return (
              <div key={cat} className="flex items-center gap-1.5">
                <span className={`w-3 h-3 rounded-full ${dotColors[idx % dotColors.length]}`} />
                <span className="font-medium text-[#2C4130]">{cat}:</span>
                <span className="font-bold text-[#1F3A24]">{formatVND(amount)} ({percent}%)</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Ledger & Transactions Table */}
      <div className="glass-vintage rounded-2xl p-6 border border-[#5E936B]/30 shadow-sm space-y-4">
        {/* Controls bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 bg-[#EFE8DA] p-1 rounded-2xl border border-[#D5CBBC]">
            <button
              type="button"
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                filterType === 'all' ? 'bg-[#23432B] text-white shadow-xs' : 'text-[#4F6A54]'
              }`}
            >
              Tất cả ({transactions.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterType('income')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                filterType === 'income' ? 'bg-emerald-700 text-white shadow-xs' : 'text-[#4F6A54]'
              }`}
            >
              Thu (+)
            </button>
            <button
              type="button"
              onClick={() => setFilterType('expense')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                filterType === 'expense' ? 'bg-amber-700 text-white shadow-xs' : 'text-[#4F6A54]'
              }`}
            >
              Chi (-)
            </button>
          </div>

          <div className="relative flex-1 sm:max-w-xs">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              placeholder="Tìm theo nội dung, mã phiếu..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-white border border-[#D5CBBC] text-xs focus:ring-1 focus:ring-[#3B6E47]"
            />
          </div>
        </div>

        {/* Transactions List */}
        <div className="space-y-3">
          {filteredList.map((tx) => (
            <div
              key={tx.id}
              className="bg-white p-4 rounded-2xl border border-[#DED4C3] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs hover:border-[#8BAE90] transition shadow-xs"
            >
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  tx.type === 'income' 
                    ? 'bg-emerald-100 text-emerald-800' 
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {tx.type === 'income' ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                </div>

                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm text-[#23432B]">{tx.title}</span>
                    <span className="font-mono text-[10px] bg-stone-100 px-2 py-0.5 rounded border border-stone-200 text-stone-600">
                      {tx.receiptCode}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E8F1E7] text-[#2C5C36]">
                      {tx.category}
                    </span>
                  </div>

                  <p className="text-[#647C68] mt-0.5">
                    Ngày: {tx.date} • Người lập: {tx.performedBy} • Phê duyệt: {tx.approvedBy}
                  </p>

                  {tx.note && (
                    <p className="text-stone-500 italic mt-0.5">
                      Ghi chú: {tx.note}
                    </p>
                  )}

                  {tx.receiptImage && (
                    <div className="mt-2 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setPreviewReceiptTx(tx)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[11px] font-bold border border-emerald-300 transition cursor-pointer"
                      >
                        <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Xem Biên Lai / Hóa Đơn Chụp</span>
                        <Eye className="w-3 h-3 text-emerald-600" />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div className="text-right shrink-0 self-end sm:self-center">
                <div className={`text-base font-black ${
                  tx.type === 'income' ? 'text-emerald-700' : 'text-amber-700'
                }`}>
                  {tx.type === 'income' ? '+' : '-'}{formatVND(tx.amount)}
                </div>
                <div className="flex items-center justify-end gap-1 mt-0.5">
                  {tx.receiptImage && (
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-1.5 py-0.2 rounded">
                      Đã kèm biên lai
                    </span>
                  )}
                  <span className="text-[10px] text-stone-400">Đã kiểm toán BCN</span>
                </div>
              </div>
            </div>
          ))}

          {filteredList.length === 0 && (
            <div className="text-center py-8 text-xs text-stone-500">
              Không tìm thấy giao dịch tài chính phù hợp với từ khóa.
            </div>
          )}
        </div>
      </div>

      {/* Modal: Create New Receipt / Voucher */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#FAF7F0] rounded-2xl border-2 border-[#5E936B]/50 shadow-2xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
            <div className="bg-[#24432B] text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-300" />
                <h3 className="font-bold text-base font-serif-vintage">
                  Tạo Phiếu Thu / Chi Ngân Sách CLB
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTx} className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-bold text-[#23432B] mb-1">Loại chứng từ *</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setNewType('income')}
                    className={`py-2 rounded-xl font-bold border transition cursor-pointer ${
                      newType === 'income'
                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm'
                        : 'bg-white text-stone-600 border-stone-300'
                    }`}
                  >
                    Phiếu Thu (+)
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewType('expense')}
                    className={`py-2 rounded-xl font-bold border transition cursor-pointer ${
                      newType === 'expense'
                        ? 'bg-amber-600 text-white border-amber-700 shadow-sm'
                        : 'bg-white text-stone-600 border-stone-300'
                    }`}
                  >
                    Phiếu Chi (-)
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Nội dung thu / chi *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Ví dụ: Mua 10 cuốn 'Hoàng Tử Bé' tặng học sinh nghèo..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-[#23432B] mb-1">Số tiền (VNĐ) *</label>
                  <input
                    type="number"
                    required
                    min={1000}
                    step={1000}
                    value={newAmount}
                    onChange={(e) => setNewAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs font-bold text-[#1F3D26] focus:ring-2 focus:ring-[#3B6E47]"
                  />
                </div>

                <div>
                  <label className="block font-bold text-[#23432B] mb-1">Hạng mục chi *</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                  >
                    <option value="Quỹ hội phí">Quỹ hội phí</option>
                    <option value="Mua sách mới">Mua sách mới</option>
                    <option value="Tổ chức Talkshow">Tổ chức Talkshow</option>
                    <option value="In ấn & Quà tặng">In ấn & Quà tặng</option>
                    <option value="Tài trợ & Quyên góp">Tài trợ & Quyên góp</option>
                    <option value="Tiệc trà & Teabreak">Tiệc trà & Teabreak</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Người thực hiện</label>
                <input
                  type="text"
                  value={newPerformedBy}
                  onChange={(e) => setNewPerformedBy(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#23432B] mb-1">Ghi chú chứng từ</label>
                <textarea
                  rows={2}
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Hóa đơn bán lẻ số ..., đơn vị cung cấp..."
                  className="w-full px-3 py-2 rounded-xl border border-[#C5BCAB] bg-white text-xs focus:ring-2 focus:ring-[#3B6E47]"
                />
              </div>

              {/* Chụp & Đính kèm biên lai / hóa đơn */}
              <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200/80 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Camera className="w-4 h-4 text-amber-800" />
                    <span className="font-bold text-xs text-amber-950">Chụp / Đính Kèm Biên Lai & Hóa Đơn Thu Chi</span>
                  </div>
                  {newReceiptImage && (
                    <button
                      type="button"
                      onClick={() => setNewReceiptImage('')}
                      className="text-[11px] text-rose-600 hover:underline font-semibold"
                    >
                      Xóa ảnh
                    </button>
                  )}
                </div>

                <input
                  type="file"
                  ref={receiptFileInputRef}
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = () => {
                        if (typeof reader.result === 'string') {
                          setNewReceiptImage(reader.result);
                        }
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                />

                {newReceiptImage ? (
                  <div className="relative rounded-xl overflow-hidden border border-amber-300 max-h-48 bg-stone-900 flex items-center justify-center">
                    <img
                      src={newReceiptImage}
                      alt="Receipt preview"
                      className="max-h-48 w-full object-contain"
                    />
                    <button
                      type="button"
                      onClick={() => receiptFileInputRef.current?.click()}
                      className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-black/60 text-white text-[11px] font-semibold hover:bg-black/80 flex items-center gap-1"
                    >
                      <Camera className="w-3 h-3" />
                      <span>Đổi ảnh khác</span>
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => receiptFileInputRef.current?.click()}
                    className="w-full py-3 px-4 border-2 border-dashed border-amber-300 rounded-xl bg-white hover:bg-amber-50/50 flex flex-col items-center justify-center gap-1.5 transition cursor-pointer text-amber-900"
                  >
                    <Upload className="w-5 h-5 text-amber-700" />
                    <span className="font-bold text-xs">Chụp ảnh biên lai bằng Camera hoặc tải ảnh từ máy</span>
                    <span className="text-[10px] text-amber-700/80">Lưu giữ chứng từ minh bạch cho BCN và nhà trường</span>
                  </button>
                )}
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-[#DFD6C3]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-700 font-semibold cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#23432B] hover:bg-[#1B3522] text-white font-bold bubble-3d shadow-md cursor-pointer"
                >
                  Lưu & Tạo Phiếu
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Lightbox Modal: View Receipt Image */}
      {previewReceiptTx && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative bg-[#FAF7F0] rounded-2xl border-2 border-emerald-600 shadow-2xl max-w-xl w-full max-h-[92vh] overflow-hidden flex flex-col">
            <div className="bg-[#1C3621] text-white p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <Receipt className="w-5 h-5 text-amber-300" />
                <div>
                  <h4 className="font-bold text-sm font-serif-vintage">
                    Hóa Đơn / Biên Lai: {previewReceiptTx.receiptCode}
                  </h4>
                  <p className="text-[11px] text-emerald-200/80">
                    {previewReceiptTx.title} • {formatVND(previewReceiptTx.amount)}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPreviewReceiptTx(null)}
                className="p-1 rounded-lg hover:bg-white/10 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1 flex flex-col items-center justify-center bg-stone-900/10">
              {previewReceiptTx.receiptImage ? (
                <img
                  src={previewReceiptTx.receiptImage}
                  alt={previewReceiptTx.title}
                  className="max-h-[60vh] w-auto max-w-full rounded-xl object-contain shadow-lg border border-stone-200"
                />
              ) : (
                <div className="text-center py-10 text-stone-500 text-xs">
                  Không có hình ảnh biên lai đính kèm.
                </div>
              )}
            </div>

            <div className="p-3 bg-[#EFE9DA] border-t border-[#DED4C3] flex items-center justify-between text-xs text-[#2A4B31] shrink-0">
              <span>Người lập: <strong>{previewReceiptTx.performedBy}</strong> ({previewReceiptTx.date})</span>
              <button
                type="button"
                onClick={() => setPreviewReceiptTx(null)}
                className="px-4 py-1.5 rounded-xl bg-[#23432B] text-white font-bold cursor-pointer"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
