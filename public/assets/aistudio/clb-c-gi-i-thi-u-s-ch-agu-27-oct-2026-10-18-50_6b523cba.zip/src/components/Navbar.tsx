import React from 'react';
import { 
  BookOpen, 
  Flame, 
  Award, 
  Mail, 
  Vault, 
  Users2, 
  KeyRound,
  Sparkles,
  Crown,
  Layers
} from 'lucide-react';
import { UserProfile } from '../types';

export type ActiveTab = 'feed' | 'command' | 's5t' | 'reports' | 'vault' | 'org' | 'recruitment' | 'fame';

interface NavbarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  currentUser: UserProfile;
  isBcnMode: boolean;
  onOpenAuthModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onSelectTab,
  currentUser,
  isBcnMode,
  onOpenAuthModal
}) => {
  const navItems = [
    { id: 'feed', label: 'Bảng Tin & Chuỗi', icon: Flame, badge: `${currentUser.readingStreak} 🔥` },
    { id: 'command', label: 'Kế Hoạch & BCN', icon: Crown, badge: isBcnMode ? 'Chỉ huy ★' : 'Kho đề án' },
    { id: 'reports', label: 'Báo Cáo Ẩn Danh', icon: Mail, badge: isBcnMode ? 'Hòm thư BCN' : 'Bảo mật' },
    { id: 's5t', label: 'Sinh Viên 5 Tốt', icon: Award, badge: `${currentUser.s5tProgress}%` },
    { id: 'vault', label: 'Két Quỹ CLB', icon: Vault, badge: isBcnMode ? 'Đã mở' : 'Khóa' },
    { id: 'org', label: 'Sơ Đồ 4 Ban', icon: Users2, badge: 'Nhân sự' }
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#F5F0E4]/95 backdrop-blur-md border-b border-[#D6CBB8]/80 shadow-xs pt-13 pb-2 px-3 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2.5">
        {/* Logo and Club Brand */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-2.5">
            <div className="h-10 sm:h-11 flex items-center justify-center shrink-0">
              <img 
                src="/assets/aistudio/TUYE__N_THA_NH_VIE_N_778c37b9.png" 
                alt="Logo CLB Đọc và Giới thiệu sách" 
                className="h-10 sm:h-11 object-contain drop-shadow-xs"
              />
            </div>
            <div>
              <div className="text-[10px] sm:text-[11px] font-semibold text-[#406848] leading-tight tracking-wide">
                Hội sinh viên Trường Đại học An Giang
              </div>
              <h1 className="text-sm sm:text-base font-bold text-[#23432B] font-serif-vintage tracking-tight leading-tight">
                Câu lạc bộ Đọc và Giới thiệu sách
              </h1>
            </div>
          </div>

          {/* Quick Profile Pill on mobile */}
          <button
            type="button"
            onClick={onOpenAuthModal}
            className="md:hidden flex items-center gap-1.5 p-1 pl-2 pr-2.5 bg-white/90 rounded-xl border border-[#D5CABB] shadow-2xs text-xs cursor-pointer hover:bg-white"
          >
            <img 
              src={currentUser.avatar} 
              alt={currentUser.name} 
              className="w-6 h-6 rounded-lg object-cover ring-1 ring-[#5E936B]"
            />
            <div className="text-left text-[11px] leading-tight">
              <div className="font-bold text-[#23432B] truncate max-w-[70px]">
                {currentUser.nickname ? currentUser.nickname.split(' ')[0] : currentUser.name.split(' ').slice(-1)[0]}
              </div>
              <div className="text-[9px] text-[#5E936B] font-medium">
                {isBcnMode ? '★ BCN' : currentUser.department.slice(0, 8)}
              </div>
            </div>
          </button>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex items-center gap-1 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id as ActiveTab)}
                className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#23432B] text-[#FAF6EB] shadow-xs'
                    : 'text-[#485C4C] hover:bg-[#EAE3D2] hover:text-[#23432B]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#6AD5A1]' : 'text-[#6B856F]'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-md font-bold ml-0.5 ${
                      isActive
                        ? 'bg-[#3A6343] text-[#D4F0D9]'
                        : 'bg-[#E5DEC] text-[#5E7A62] border border-[#D3C8B5]'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Desktop Profile & Role Switcher */}
        <div className="hidden md:flex items-center gap-2">
          <div 
            onClick={onOpenAuthModal}
            className={`flex items-center gap-2.5 p-1 pl-2 pr-2.5 rounded-xl border transition cursor-pointer shadow-2xs ${
              isBcnMode 
                ? 'bg-gradient-to-r from-[#1C3621] to-[#162719] border-amber-400 text-amber-100 hover:shadow-xs'
                : 'bg-white/90 hover:bg-white border-[#D6CBB8] text-[#2C3E2D]'
            }`}
            title="Đổi tài khoản hoặc mở quyền BCN"
          >
            <div className="relative">
              <img 
                src={currentUser.avatar} 
                alt={currentUser.name} 
                className="w-8 h-8 rounded-lg object-cover ring-1 ring-[#5E936B]"
              />
              {isBcnMode && (
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-amber-400 text-stone-900 rounded-full flex items-center justify-center text-[8px] font-bold ring-1 ring-white">
                  ★
                </span>
              )}
            </div>

            <div className="text-left text-xs leading-tight">
              <div className="flex items-center gap-1 font-bold">
                <span className="truncate max-w-[110px]">{currentUser.name}</span>
                {currentUser.nickname && (
                  <span className="text-[10px] text-amber-600 truncate max-w-[75px]">
                    ({currentUser.nickname.split(' ')[0]})
                  </span>
                )}
              </div>
              <div className={`text-[10px] font-medium ${isBcnMode ? 'text-amber-300' : 'text-[#5E936B]'}`}>
                {isBcnMode ? 'BCN Tối Cao' : `${currentUser.department} • ${currentUser.studentId}`}
              </div>
            </div>

            <div className="pl-1 border-l border-[#D6CBB8]/60">
              <div className="p-1 rounded-md bg-[#EFE9DA] text-[#4A6450]">
                <KeyRound className="w-3 h-3" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
