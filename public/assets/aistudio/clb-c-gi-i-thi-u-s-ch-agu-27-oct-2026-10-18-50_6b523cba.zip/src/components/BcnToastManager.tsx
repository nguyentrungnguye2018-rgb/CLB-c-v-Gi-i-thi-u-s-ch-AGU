import React, { useState, useEffect, useRef } from 'react';
import {
  Bell,
  UserPlus,
  FileSpreadsheet,
  X,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  Clock,
  ShieldAlert,
  FileText
} from 'lucide-react';
import {
  RecruitmentApplication,
  ClubPlan,
  ConfidentialReport,
  UserProfile
} from '../types';
import { ActiveTab } from './Navbar';

export interface BcnPushToastItem {
  id: string;
  type: 'new_application' | 'new_plan' | 'new_report';
  title: string;
  subtitle: string;
  meta: string;
  timestamp: string;
  targetTab: ActiveTab;
  itemId: string;
}

interface BcnToastManagerProps {
  currentUser: UserProfile;
  isBcnMode: boolean;
  isMasterRoot: boolean;
  applications: RecruitmentApplication[];
  plans: ClubPlan[];
  reports: ConfidentialReport[];
  onNavigateTab: (tab: ActiveTab) => void;
}

// Gentle Web Audio chime for BCN push notifications
function playNotificationChime() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.18); // A5
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.45);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.45);
  } catch {
    // Ignore audio context restrictions if user hasn't interacted yet
  }
}

export const BcnToastManager: React.FC<BcnToastManagerProps> = ({
  currentUser,
  isBcnMode,
  isMasterRoot,
  applications,
  plans,
  reports,
  onNavigateTab
}) => {
  const isBcnAuthorized = isBcnMode || currentUser.role === 'bcn_admin' || isMasterRoot;

  const [activeToasts, setActiveToasts] = useState<BcnPushToastItem[]>([]);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Track which application IDs and plan IDs have already triggered a push toast in this browser
  const seenIdsRef = useRef<Set<string>>(new Set());
  const isInitializedRef = useRef<boolean>(false);

  const pendingApplications = applications.filter(a => a.status === 'pending');
  const pendingPlans = plans.filter(p => p.status === 'under_discussion');
  const pendingReports = reports.filter(r => r.status !== 'resolved');

  const totalPendingCount = pendingApplications.length + pendingPlans.length;

  useEffect(() => {
    if (!isBcnAuthorized) {
      setActiveToasts([]);
      isInitializedRef.current = false;
      return;
    }

    const storageKey = `agu_bcn_toasts_seen_${currentUser.id}`;
    try {
      const saved = sessionStorage.getItem(storageKey);
      if (saved) {
        const parsed: string[] = JSON.parse(saved);
        parsed.forEach(id => seenIdsRef.current.add(id));
      }
    } catch {
      // ignore storage error
    }

    const newToasts: BcnPushToastItem[] = [];

    // 1. Check for pending recruitment applications
    for (const app of pendingApplications) {
      const toastKey = `app-${app.id}`;
      if (!seenIdsRef.current.has(toastKey)) {
        seenIdsRef.current.add(toastKey);
        newToasts.push({
          id: `toast-${toastKey}-${Date.now()}`,
          type: 'new_application',
          title: 'Đơn Đăng Ký Tham Gia CLB Mới!',
          subtitle: `${app.fullName} (${app.studentId}) • ${app.faculty}`,
          meta: `Nguyện vọng: Ban ${app.desiredDept}`,
          timestamp: app.submittedAt || 'Vừa nộp',
          targetTab: 'recruitment',
          itemId: app.id
        });
      }
    }

    // 2. Check for plans awaiting BCN approval
    for (const plan of pendingPlans) {
      const toastKey = `plan-${plan.id}`;
      if (!seenIdsRef.current.has(toastKey)) {
        seenIdsRef.current.add(toastKey);
        newToasts.push({
          id: `toast-${toastKey}-${Date.now()}`,
          type: 'new_plan',
          title: 'Yêu Cầu Phê Duyệt Kế Hoạch Mới!',
          subtitle: plan.title,
          meta: `Đề xuất bởi: ${plan.proposedBy} (Ban ${plan.department})${plan.attachmentUrl ? ` • Có đính kèm ${plan.attachmentType === 'pdf' ? 'File PDF' : 'Hình ảnh'}` : ''}`,
          timestamp: plan.timeline || 'Đang chờ BCN duyệt',
          targetTab: 'command',
          itemId: plan.id
        });
      }
    }

    // 3. Check for new confidential reports if already initialized
    if (isInitializedRef.current) {
      for (const rep of pendingReports) {
        const toastKey = `rep-${rep.id}`;
        if (!seenIdsRef.current.has(toastKey)) {
          seenIdsRef.current.add(toastKey);
          newToasts.push({
            id: `toast-${toastKey}-${Date.now()}`,
            type: 'new_report',
            title: 'Báo Cáo Ẩn Danh Mới Gửi Tới BCN!',
            subtitle: rep.title,
            meta: `Chuyên mục: ${rep.category} • Mức độ: ${rep.urgency === 'high' ? 'Khẩn cấp' : 'Bình thường'}`,
            timestamp: rep.createdAt,
            targetTab: 'reports',
            itemId: rep.id
          });
        }
      }
    } else {
      // Mark existing reports as seen on first load so we focus initial toasts on Applications & Plans
      pendingReports.forEach(r => seenIdsRef.current.add(`rep-${r.id}`));
    }

    isInitializedRef.current = true;

    if (newToasts.length > 0) {
      try {
        sessionStorage.setItem(storageKey, JSON.stringify(Array.from(seenIdsRef.current)));
      } catch {
        // ignore storage error
      }
      playNotificationChime();
      setActiveToasts(prev => [...newToasts, ...prev].slice(0, 4));
    }
  }, [isBcnAuthorized, currentUser.id, applications, plans, reports]);

  // Auto-dismiss toasts after 12 seconds
  useEffect(() => {
    if (activeToasts.length === 0) return;
    const timer = setTimeout(() => {
      setActiveToasts(prev => prev.slice(0, -1));
    }, 12000);
    return () => clearTimeout(timer);
  }, [activeToasts]);

  if (!isBcnAuthorized) return null;

  const handleDismissToast = (id: string) => {
    setActiveToasts(prev => prev.filter(t => t.id !== id));
  };

  const handleActionClick = (toast: BcnPushToastItem) => {
    onNavigateTab(toast.targetTab);
    handleDismissToast(toast.id);
    setIsDrawerOpen(false);
  };

  return (
    <>
      {/* Floating BCN Quick Notification Bell in Bottom-Right */}
      <div className="fixed bottom-5 right-5 z-40">
        <button
          type="button"
          onClick={() => setIsDrawerOpen(!isDrawerOpen)}
          className="relative flex items-center gap-2 px-3.5 py-2.5 rounded-2xl bg-gradient-to-r from-[#17321E] via-[#1F4429] to-[#17321E] text-amber-300 border border-amber-400/50 shadow-xl hover:shadow-2xl hover:scale-[1.02] transition-all cursor-pointer"
          title="Trung tâm Thông báo Đẩy dành riêng cho Ban Chủ Nhiệm"
        >
          <div className="relative">
            <Bell className="w-4 h-4 text-amber-300" />
            {totalPendingCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-black flex items-center justify-center animate-pulse">
                {totalPendingCount}
              </span>
            )}
          </div>
          <span className="text-xs font-bold hidden sm:inline">
            Thông Báo BCN ({totalPendingCount} việc chờ duyệt)
          </span>
        </button>
      </div>

      {/* Push Toast Notification Stack (Top-Right) */}
      {activeToasts.length > 0 && (
        <div className="fixed top-14 right-4 z-[90] w-[92vw] max-w-sm space-y-2.5 pointer-events-none">
          {activeToasts.map((toast) => (
            <div
              key={toast.id}
              className="pointer-events-auto rounded-2xl p-[1.5px] bg-gradient-to-r from-amber-400 via-emerald-400 to-amber-500 shadow-2xl animate-in fade-in zoom-in-95 duration-200"
            >
              <div className="bg-[#132819] text-white rounded-[14.5px] p-3.5 space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 font-bold ${
                      toast.type === 'new_application'
                        ? 'bg-amber-400 text-stone-950'
                        : toast.type === 'new_plan'
                        ? 'bg-emerald-400 text-stone-950'
                        : 'bg-rose-500 text-white'
                    }`}>
                      {toast.type === 'new_application' ? (
                        <UserPlus className="w-4 h-4" />
                      ) : toast.type === 'new_plan' ? (
                        <FileSpreadsheet className="w-4 h-4" />
                      ) : (
                        <ShieldAlert className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                          {toast.type === 'new_application'
                            ? 'Tuyển Thành Viên'
                            : toast.type === 'new_plan'
                            ? 'Duyệt Kế Hoạch'
                            : 'Báo Cáo Ẩn Danh'}
                        </span>
                        <span className="text-[10px] text-emerald-300/80 flex items-center gap-0.5">
                          <Clock className="w-2.5 h-2.5" />
                          {toast.timestamp}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-white mt-0.5 leading-snug">
                        {toast.title}
                      </h4>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleDismissToast(toast.id)}
                    className="p-1 rounded-lg text-emerald-300/70 hover:text-white hover:bg-white/10 transition cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="bg-white/10 rounded-xl p-2.5 border border-white/10 space-y-0.5">
                  <div className="text-xs font-bold text-amber-200 line-clamp-1">
                    {toast.subtitle}
                  </div>
                  <div className="text-[11px] text-emerald-100/90 line-clamp-1">
                    {toast.meta}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-0.5">
                  <button
                    type="button"
                    onClick={() => handleDismissToast(toast.id)}
                    className="text-[11px] text-emerald-300/80 hover:text-white font-medium cursor-pointer"
                  >
                    Để sau
                  </button>

                  <button
                    type="button"
                    onClick={() => handleActionClick(toast)}
                    className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-extrabold text-[11px] flex items-center gap-1 shadow-xs transition cursor-pointer"
                  >
                    <span>
                      {toast.type === 'new_application'
                        ? 'Xét Duyệt Đơn Ngay'
                        : toast.type === 'new_plan'
                        ? 'Xem & Phê Duyệt Kế Hoạch'
                        : 'Mở Hòm Thư Ẩn Danh'}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* BCN Notification Center Drawer Modal */}
      {isDrawerOpen && (
        <div className="fixed inset-0 z-[85] bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center sm:justify-end p-0 sm:p-5">
          <div className="bg-[#FAF7F0] border border-[#DAD0BD] rounded-t-3xl sm:rounded-3xl w-full max-w-md max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="bg-gradient-to-r from-[#16301D] via-[#1E3F27] to-[#16301D] text-white p-4 sm:p-5 flex items-center justify-between border-b border-amber-400/30">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-400 text-stone-950 flex items-center justify-center font-bold shadow-xs">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                      Đặc Quyền BCN
                    </span>
                  </div>
                  <h3 className="font-bold text-sm sm:text-base font-serif-vintage text-white mt-0.5">
                    Trung Tâm Thông Báo Đẩy BCN
                  </h3>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsDrawerOpen(false)}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4 flex-1 text-xs">
              {/* Section 1: Pending Recruitment Applications */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1E3A24] flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                    <UserPlus className="w-3.5 h-3.5 text-amber-700" />
                    Đơn Đăng Ký Gia Nhập CLB Chờ Duyệt ({pendingApplications.length})
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      onNavigateTab('recruitment');
                      setIsDrawerOpen(false);
                    }}
                    className="text-[11px] font-bold text-emerald-800 hover:underline cursor-pointer"
                  >
                    Mở cổng tuyển quân →
                  </button>
                </div>

                {pendingApplications.length === 0 ? (
                  <div className="p-3 rounded-xl bg-white border border-[#E5DEC9] text-stone-500 text-center text-[11px]">
                    Hiện không có đơn đăng ký thành viên nào đang chờ duyệt.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {pendingApplications.map(app => (
                      <div
                        key={app.id}
                        className="p-3 rounded-xl bg-white border border-amber-300 shadow-2xs flex items-center justify-between gap-2"
                      >
                        <div className="space-y-0.5">
                          <div className="font-bold text-[#1E3A24]">
                            {app.fullName} <span className="text-[10px] text-stone-500">({app.studentId})</span>
                          </div>
                          <div className="text-[11px] text-stone-600">
                            {app.faculty} • Nguyện vọng: <strong>Ban {app.desiredDept}</strong>
                          </div>
                          <div className="text-[10px] text-amber-700 font-semibold">
                            Nộp ngày: {app.submittedAt}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            onNavigateTab('recruitment');
                            setIsDrawerOpen(false);
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-[11px] shrink-0 cursor-pointer"
                        >
                          Duyệt Đơn
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Section 2: Pending Club Plans */}
              <div className="space-y-2 pt-2 border-t border-[#E5DEC9]">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1E3A24] flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                    <FileText className="w-3.5 h-3.5 text-emerald-700" />
                    Yêu Cầu Phê Duyệt Kế Hoạch ({pendingPlans.length})
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      onNavigateTab('command');
                      setIsDrawerOpen(false);
                    }}
                    className="text-[11px] font-bold text-emerald-800 hover:underline cursor-pointer"
                  >
                    Mở kho kế hoạch →
                  </button>
                </div>

                {pendingPlans.length === 0 ? (
                  <div className="p-3 rounded-xl bg-white border border-[#E5DEC9] text-stone-500 text-center text-[11px]">
                    Tất cả đề án kế hoạch đều đã được BCN phê chuẩn.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {pendingPlans.map(plan => (
                      <div
                        key={plan.id}
                        className="p-3 rounded-xl bg-white border border-emerald-300 shadow-2xs flex items-center justify-between gap-2"
                      >
                        <div className="space-y-0.5">
                          <div className="font-bold text-[#1E3A24] line-clamp-1">
                            {plan.title}
                          </div>
                          <div className="text-[11px] text-stone-600">
                            Đề xuất: <strong>{plan.proposedBy}</strong> • Ban {plan.department}
                          </div>
                          <div className="text-[10px] text-emerald-700 font-semibold flex items-center gap-2">
                            <span>Dự toán: {plan.budgetEstimate?.toLocaleString('vi-VN')} đ</span>
                            {plan.attachmentUrl && (
                              <span className="px-1.5 py-0.2 bg-amber-100 text-amber-900 rounded">
                                Có file {plan.attachmentType === 'pdf' ? 'PDF' : 'Ảnh'}
                              </span>
                            )}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            onNavigateTab('command');
                            setIsDrawerOpen(false);
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-[#1E3A24] hover:bg-[#2B5233] text-amber-300 font-bold text-[11px] shrink-0 cursor-pointer"
                        >
                          Phê Duyệt
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Section 3: Pending Confidential Reports */}
              <div className="space-y-2 pt-2 border-t border-[#E5DEC9]">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1E3A24] flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-700" />
                    Báo Cáo Ẩn Danh Chờ Phản Hồi ({pendingReports.length})
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      onNavigateTab('reports');
                      setIsDrawerOpen(false);
                    }}
                    className="text-[11px] font-bold text-rose-800 hover:underline cursor-pointer"
                  >
                    Mở hòm thư mật →
                  </button>
                </div>

                {pendingReports.length === 0 ? (
                  <div className="p-3 rounded-xl bg-white border border-[#E5DEC9] text-stone-500 text-center text-[11px]">
                    Không có báo cáo ẩn danh nào đang chờ xử lý.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {pendingReports.slice(0, 3).map(rep => (
                      <div
                        key={rep.id}
                        className="p-3 rounded-xl bg-white border border-rose-200 shadow-2xs flex items-center justify-between gap-2"
                      >
                        <div className="space-y-0.5">
                          <div className="font-bold text-[#1E3A24] line-clamp-1">
                            {rep.title}
                          </div>
                          <div className="text-[10px] text-stone-500">
                            Chuyên mục: {rep.category} • Ngày: {rep.createdAt}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            onNavigateTab('reports');
                            setIsDrawerOpen(false);
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-rose-700 hover:bg-rose-800 text-white font-bold text-[11px] shrink-0 cursor-pointer"
                        >
                          Xem & Giải Mã
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="p-3.5 bg-[#EFE9DC] border-t border-[#DAD0BD] flex items-center justify-between text-[11px] text-[#4A644E]">
              <span className="flex items-center gap-1 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                Tự động đẩy thông báo thời gian thực (1.5s)
              </span>
              <button
                type="button"
                onClick={() => setIsDrawerOpen(false)}
                className="px-3 py-1 rounded-lg bg-[#23432B] text-white font-bold cursor-pointer"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
