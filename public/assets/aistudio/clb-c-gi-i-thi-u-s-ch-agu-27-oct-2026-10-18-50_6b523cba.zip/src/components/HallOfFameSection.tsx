import React, { useState } from 'react';
import { 
  Award, 
  Sparkles, 
  BookOpen, 
  Crown, 
  Star, 
  Quote, 
  History, 
  ShieldCheck, 
  PlusCircle, 
  Trash2, 
  Search, 
  X, 
  Image as ImageIcon,
  CheckCircle2,
  Calendar,
  User,
  HeartHandshake
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { HallOfFameItem } from '../types';

interface HallOfFameSectionProps {
  items: HallOfFameItem[];
  isBcnMode: boolean;
  onAddItem?: (newItem: Omit<HallOfFameItem, 'id'>) => void;
  onDeleteItem?: (id: string) => void;
}

export const HallOfFameSection: React.FC<HallOfFameSectionProps> = ({ 
  items,
  isBcnMode,
  onAddItem,
  onDeleteItem
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Form states for new Hall of Fame entry
  const [name, setName] = useState('');
  const [nickname, setNickname] = useState('');
  const [studentId, setStudentId] = useState('');
  const [title, setTitle] = useState('Chủ nhiệm Danh dự');
  const [termYears, setTermYears] = useState('2024 - 2026');
  const [bestContributions, setBestContributions] = useState('');
  const [legacyQuote, setLegacyQuote] = useState('');
  const [avatar, setAvatar] = useState('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80');

  // Sample portrait avatar presets
  const sampleAvatars = [
    { label: 'Chân dung 1', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80' },
    { label: 'Chân dung 2', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80' },
    { label: 'Chân dung 3', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80' },
    { label: 'Chân dung 4', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80' },
    { label: 'Chân dung 5', url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80' },
    { label: 'Chân dung 6', url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&auto=format&fit=crop&q=80' }
  ];

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !bestContributions.trim()) return;

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#D4AF37', '#10B981', '#F59E0B', '#FAF5E8']
    });

    if (onAddItem) {
      onAddItem({
        name: name.trim(),
        nickname: nickname.trim() || undefined,
        studentId: studentId.trim() || `SV-${Math.floor(100000 + Math.random() * 900000)}`,
        title: title.trim(),
        termYears: termYears.trim(),
        bestContributions: bestContributions.trim(),
        legacyQuote: legacyQuote.trim() || 'Hành trình vạn dặm khởi đầu từ trang sách mở ra.',
        avatar: avatar.trim()
      });
    }

    // Reset and close
    setName('');
    setNickname('');
    setStudentId('');
    setBestContributions('');
    setLegacyQuote('');
    setIsAddModalOpen(false);
  };

  // Filtered list
  const filteredItems = items.filter(item => {
    const q = searchQuery.toLowerCase();
    return item.name.toLowerCase().includes(q) ||
      (item.nickname && item.nickname.toLowerCase().includes(q)) ||
      item.title.toLowerCase().includes(q) ||
      item.termYears.toLowerCase().includes(q) ||
      item.bestContributions.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Premier Luxury Banner */}
      <div className="relative p-[2px] rounded-3xl bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 shadow-xl overflow-hidden">
        <div className="bg-gradient-to-br from-[#23150C] via-[#332014] to-[#1C1109] text-white p-6 sm:p-7 rounded-[22px] backdrop-blur-md relative">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-400 to-yellow-300 text-stone-950 text-[11px] font-black uppercase tracking-wider shadow-md">
                  <Star className="w-3.5 h-3.5 fill-stone-950" />
                  Gian Trưng Bày Truyền Thống CLB
                </span>

                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/10 text-amber-200 text-[10px] font-bold border border-amber-400/30">
                  <History className="w-3 h-3 text-amber-300" />
                  {items.length} Thành Tựu Được Khắc Tên
                </span>
              </div>
              
              <h2 className="text-2xl sm:text-3xl font-bold font-serif-vintage tracking-tight text-white">
                Bảo Tàng Thành Tựu & Vinh Danh Cố Nhân
              </h2>
              
              <p className="text-xs sm:text-sm text-amber-100/90 leading-relaxed">
                Nơi trang trọng lưu giữ vĩnh viễn hình ảnh, công lao và dấu ấn thanh xuân của các thế hệ Chủ nhiệm, Phó chủ nhiệm và thành viên tiêu biểu đã hết lòng vì văn hóa đọc.
              </p>
            </div>

            {/* Admin Add Button */}
            {isBcnMode && (
              <button
                type="button"
                onClick={() => setIsAddModalOpen(true)}
                className="px-4 py-2.5 rounded-xl font-bold text-xs bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-stone-950 flex items-center gap-2 shadow-lg hover:shadow-xl transition cursor-pointer shrink-0"
              >
                <PlusCircle className="w-4 h-4 text-stone-950" />
                <span>Thêm Thành Tựu / Cố Nhân</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Search and Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-[#DFD6C3] shadow-2xs">
        <div className="flex items-center gap-2 text-xs font-bold text-[#2A4831]">
          <Award className="w-4 h-4 text-amber-600" />
          <span>Danh Sách Vinh Danh ({filteredItems.length} thành tựu)</span>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm theo tên, bút danh, khóa, chức vụ..."
            className="pl-8 pr-3 py-1.5 rounded-xl bg-[#FAF6EE] border border-[#D5CBBC] text-xs font-medium w-full sm:w-64 focus:ring-1 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* Hall of fame cards grid */}
      {filteredItems.length === 0 ? (
        <div className="p-10 text-center bg-white rounded-2xl border border-dashed border-[#DFD6C3] text-stone-500 text-xs">
          Không tìm thấy thành tựu nào khớp với từ khóa tìm kiếm.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white p-5 rounded-2xl border-2 border-[#E5DECD] shadow-xs flex flex-col justify-between space-y-3.5 hover:border-amber-400 hover:shadow-md transition relative overflow-hidden group"
            >
              {/* Top right gold ribbon */}
              <div className="absolute top-0 right-0 bg-gradient-to-l from-amber-400 to-amber-500 text-stone-900 font-extrabold text-[10px] px-3 py-1 rounded-bl-xl shadow-2xs flex items-center gap-1 z-10">
                <Star className="w-3 h-3 fill-stone-900" />
                <span>Khóa {item.termYears}</span>
              </div>

              {/* Admin delete button */}
              {isBcnMode && onDeleteItem && (
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(`Xác nhận xóa thành tựu của ${item.name} khỏi Bảo tàng?`)) {
                      onDeleteItem(item.id);
                    }
                  }}
                  className="absolute bottom-3 right-3 p-1.5 rounded-lg bg-stone-100 hover:bg-rose-100 text-stone-400 hover:text-rose-600 transition opacity-0 group-hover:opacity-100 cursor-pointer"
                  title="Xóa thành tựu này"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}

              <div className="flex items-start gap-3.5 pt-1">
                <div className="relative shrink-0">
                  <img 
                    src={item.avatar} 
                    alt={item.name} 
                    className="w-16 h-16 rounded-2xl object-cover ring-2 ring-amber-400/80 shadow-sm"
                  />
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-400 text-stone-900 flex items-center justify-center text-[10px] font-bold shadow-xs">
                    👑
                  </div>
                </div>

                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h4 className="font-bold text-sm sm:text-base text-[#1E3A24] font-serif-vintage">
                      {item.name}
                    </h4>
                    {item.nickname && (
                      <span className="text-xs font-bold text-amber-800 italic">
                        ({item.nickname})
                      </span>
                    )}
                  </div>

                  <p className="text-xs font-bold text-[#3B6E47] flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{item.title}</span>
                  </p>

                  <p className="text-[10px] text-stone-500 font-mono">
                    Mã cựu SV: {item.studentId}
                  </p>
                </div>
              </div>

              {/* Contributions */}
              <div className="p-3 rounded-xl bg-[#FAF6EC] border border-[#E8DEC9] text-xs space-y-1.5">
                <div className="font-bold text-[#23432B] flex items-center gap-1 text-[11px]">
                  <Award className="w-3.5 h-3.5 text-amber-600" />
                  <span>Dấu ấn cống hiến & Thành tựu nổi bật:</span>
                </div>
                <p className="text-[#38503C] leading-relaxed pl-1 text-[11px] sm:text-xs">
                  {item.bestContributions}
                </p>
              </div>

              {/* Quote */}
              <div className="flex items-start gap-2 pt-1 text-xs italic text-stone-600 border-t border-[#EFE8DA]">
                <Quote className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed font-serif text-[11px] sm:text-xs text-stone-700">
                  "{item.legacyQuote}"
                </p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* =========================================================================
          MODAL: THÊM THÀNH TỰU MỚI (CHO BCN QUẢN TRỊ)
         ========================================================================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in overflow-y-auto">
          <div className="bg-[#FAF7F0] w-full max-w-xl rounded-3xl border border-[#DAD0BD] shadow-2xl p-5 sm:p-6 space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-[#E3DAC7] pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 text-stone-900 flex items-center justify-center font-bold shadow-xs">
                  <Award className="w-4 h-4 text-stone-950" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#1E3A24] font-serif-vintage">
                    Thêm Thành Tựu Mới Vào Bảo Tàng
                  </h3>
                  <p className="text-[11px] text-[#557058]">
                    Quyền quản trị BCN: nhập hình ảnh và nội dung vinh danh
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-3.5 text-xs">
              {/* Image Preview & Selection */}
              <div>
                <label className="block font-bold text-stone-800 mb-1 flex items-center gap-1">
                  <ImageIcon className="w-3.5 h-3.5 text-amber-600" />
                  <span>1. Hình Ảnh / Chân Dung Thành Tựu:</span>
                </label>
                
                <div className="flex items-center gap-3 p-2.5 rounded-xl bg-white border border-[#D5CBBC]">
                  <img
                    src={avatar}
                    alt="Preview"
                    className="w-14 h-14 rounded-xl object-cover ring-2 ring-amber-400 shrink-0"
                  />
                  <div className="min-w-0 flex-1 space-y-1.5">
                    <input
                      type="url"
                      value={avatar}
                      onChange={(e) => setAvatar(e.target.value)}
                      placeholder="Dán đường dẫn ảnh (URL) tại đây..."
                      className="w-full px-2.5 py-1.5 rounded-lg bg-[#FAF6EE] border border-[#D5CBBC] text-xs font-mono text-stone-800"
                      required
                    />
                    <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
                      <span className="text-[10px] text-stone-500 shrink-0">Gợi ý ảnh:</span>
                      {sampleAvatars.map((s, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setAvatar(s.url)}
                          className="text-[9px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100 cursor-pointer shrink-0"
                        >
                          {s.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Name & Nickname */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    2. Họ và Tên Nhân Sự:
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ví dụ: Nguyễn Văn An"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#D5CBBC] font-semibold text-stone-900"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    3. Biệt Danh / Bút Danh:
                  </label>
                  <input
                    type="text"
                    value={nickname}
                    onChange={(e) => setNickname(e.target.value)}
                    placeholder="Ví dụ: An Mọt Sách, Thuyền Trưởng"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#D5CBBC] font-medium text-stone-800"
                  />
                </div>
              </div>

              {/* Title & Term & Student ID */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    4. Chức Vụ / Danh Hiệu:
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Chủ nhiệm Danh dự..."
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#D5CBBC] font-semibold text-stone-800"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    5. Niên Khóa / Nhiệm Kỳ:
                  </label>
                  <input
                    type="text"
                    value={termYears}
                    onChange={(e) => setTermYears(e.target.value)}
                    placeholder="Ví dụ: 2024 - 2026"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#D5CBBC] font-semibold text-stone-800"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    6. Mã Số Sinh Viên (MSSV):
                  </label>
                  <input
                    type="text"
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    placeholder="Ví dụ: DTH220199"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-[#D5CBBC] font-medium text-stone-800"
                  />
                </div>
              </div>

              {/* Best contributions */}
              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  7. Đóng Góp Nổi Bật & Thành Tựu Để Lại:
                </label>
                <textarea
                  rows={3}
                  value={bestContributions}
                  onChange={(e) => setBestContributions(e.target.value)}
                  placeholder="Mô tả cụ thể: Sáng lập chuỗi Tọa đàm Sách, xây dựng thư viện mini 500 đầu sách, dìu dắt hơn 40 bạn sinh viên..."
                  className="w-full px-3 py-2 rounded-xl bg-white border border-[#D5CBBC] font-medium text-stone-800 leading-relaxed"
                  required
                />
              </div>

              {/* Legacy Quote */}
              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  8. Câu Nói Tâm Đắc / Lời Nhắn Nhủ:
                </label>
                <input
                  type="text"
                  value={legacyQuote}
                  onChange={(e) => setLegacyQuote(e.target.value)}
                  placeholder="Ví dụ: Mỗi trang sách mở ra là một chân trời tri thức mới..."
                  className="w-full px-3 py-2 rounded-xl bg-white border border-[#D5CBBC] font-medium text-stone-800 italic"
                />
              </div>

              {/* Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl font-bold text-stone-600 bg-stone-200 hover:bg-stone-300 transition cursor-pointer"
                >
                  Hủy Bỏ
                </button>

                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl font-bold bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-stone-950 shadow-md hover:shadow-lg transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Crown className="w-4 h-4 text-stone-950" />
                  <span>Khắc Tên Vào Bảo Tàng Thành Tựu</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
