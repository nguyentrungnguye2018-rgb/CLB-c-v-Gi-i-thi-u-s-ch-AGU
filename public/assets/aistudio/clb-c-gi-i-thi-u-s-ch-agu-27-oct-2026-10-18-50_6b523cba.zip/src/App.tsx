import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  UserProfile, 
  Post, 
  LocketMoment, 
  S5TCriterion, 
  S5TProof, 
  ConfidentialReport, 
  Transaction,
  ClubPlan,
  ClubTask,
  ClubDecree,
  RecruitmentQuestion,
  RecruitmentApplication,
  HallOfFameItem,
  RoleType,
  AdminAccountType,
  DepartmentType
} from './types';
import { 
  SAMPLE_USERS, 
  INITIAL_POSTS, 
  INITIAL_LOCKET_MOMENTS, 
  S5T_CRITERIA_LIST, 
  INITIAL_S5T_PROOFS, 
  INITIAL_CONFIDENTIAL_REPORTS, 
  INITIAL_TRANSACTIONS,
  INITIAL_PLANS,
  INITIAL_TASKS,
  INITIAL_DECREES,
  MASTER_PASSCODE,
  SPECIAL_BCN_ACCOUNTS,
  INITIAL_RECRUITMENT_QUESTIONS,
  INITIAL_APPLICATIONS,
  HALL_OF_FAME_DATA
} from './data/mockData';
import { 
  fetchCloudState, 
  pushCloudSync, 
  registerUserToCloud, 
  ensureLocalUsersOnCloud,
  sendReportToCloud,
  sendReportResponseToCloud,
  sendPostToCloud,
  sendPostLikeToCloud,
  sendPostCommentToCloud,
  sendLocketToCloud,
  sendLocketReactToCloud,
  deleteUserFromCloud,
  transferSuccessionToCloud,
  updateProfileOnCloud,
  assignRoleOnCloud,
  addTransactionToCloud,
  addPlanToCloud,
  deleteItemFromCloud,
  GlobalSyncState 
} from './services/cloudSync';
import { DynamicIsland } from './components/DynamicIsland';
import { Navbar, ActiveTab } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { InitialAuthGate } from './components/InitialAuthGate';
import { NewfeedSection } from './components/NewfeedSection';
import { BcnCommandCenter } from './components/BcnCommandCenter';
import { S5TTrackerSection } from './components/S5TTrackerSection';
import { ConfidentialReportSection } from './components/ConfidentialReportSection';
import { FinancialVaultSection } from './components/FinancialVaultSection';
import { OrgChartSection } from './components/OrgChartSection';
import { RecruitmentSection } from './components/RecruitmentSection';
import { SuccessionModal, SuccessionTransferPayload } from './components/SuccessionModal';
import { HallOfFameSection } from './components/HallOfFameSection';
import { BcnToastManager } from './components/BcnToastManager';
import { 
  BookOpen, 
  MapPin, 
  Crown, 
  LogOut, 
  Sparkles, 
  UserPlus, 
  History, 
  ShieldCheck, 
  Cloud, 
  RefreshCw, 
  Wifi, 
  Smartphone, 
  Laptop, 
  Check 
} from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<ActiveTab>('feed');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isSuccessionModalOpen, setIsSuccessionModalOpen] = useState(false);

  // Multi-Device Cloud Sync State
  const [syncStatus, setSyncStatus] = useState<'connected' | 'syncing' | 'offline'>('syncing');
  const [lastServerUpdate, setLastServerUpdate] = useState<number>(0);
  const lastServerUpdateRef = useRef<number>(0);
  const [isManualSyncing, setIsManualSyncing] = useState<boolean>(false);
  const isInitialLoadDone = useRef(false);

  // Upfront Registration & Login Gate state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('agu_authenticated') === 'true';
  });

  // Users list state (includes permanent master root + 3 elected student leaders + registered members)
  const [userList, setUserList] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem('agu_user_list');
    return saved ? JSON.parse(saved) : SAMPLE_USERS;
  });

  // Current logged in user
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('agu_user');
    return saved ? JSON.parse(saved) : SAMPLE_USERS[0];
  });

  // Saved personal accounts on this device so switching to another account NEVER loses the user's own account
  const [mySavedAccounts, setMySavedAccounts] = useState<UserProfile[]>(() => {
    const map = new Map<string, UserProfile>();
    try {
      const savedList = localStorage.getItem('agu_my_accounts');
      if (savedList) {
        const parsed: UserProfile[] = JSON.parse(savedList);
        if (Array.isArray(parsed)) {
          parsed.forEach(u => {
            if (u && u.id && u.id !== 'bcn-root') map.set(u.id, u);
          });
        }
      }
      const personal = localStorage.getItem('agu_personal_user');
      if (personal) {
        const u: UserProfile = JSON.parse(personal);
        if (u && u.id && u.id !== 'bcn-root') map.set(u.id, u);
      }
      const current = localStorage.getItem('agu_user');
      if (current) {
        const u: UserProfile = JSON.parse(current);
        if (u && u.id && u.id !== 'bcn-root') map.set(u.id, u);
      }
    } catch {
      // ignore JSON errors
    }
    return Array.from(map.values());
  });

  // Helper to remember a user's personal account on this device
  const rememberPersonalAccount = (user: UserProfile) => {
    if (!user || !user.id || user.id === 'bcn-root' || user.adminType === 'master_root') return;
    localStorage.setItem('agu_personal_user', JSON.stringify(user));
    setMySavedAccounts(prev => {
      const filtered = prev.filter(
        u => u.id !== user.id &&
             (!user.studentId || u.studentId?.toLowerCase() !== user.studentId.toLowerCase())
      );
      const next = [user, ...filtered];
      localStorage.setItem('agu_my_accounts', JSON.stringify(next));
      return next;
    });
  };

  const [isBcnMode, setIsBcnMode] = useState<boolean>(() => {
    return localStorage.getItem('agu_is_bcn') === 'true';
  });

  // Master Root Account determination
  const isMasterRoot = isBcnMode && (currentUser.adminType === 'master_root' || currentUser.id === 'bcn-root');

  // Main Data States with localStorage persistence + Centralized Server Storage
  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem('agu_posts');
    return saved ? JSON.parse(saved) : INITIAL_POSTS;
  });

  const [locketMoments, setLocketMoments] = useState<LocketMoment[]>(() => {
    const saved = localStorage.getItem('agu_lockets');
    return saved ? JSON.parse(saved) : INITIAL_LOCKET_MOMENTS;
  });

  const [criteria, setCriteria] = useState<S5TCriterion[]>(() => {
    const saved = localStorage.getItem('agu_criteria');
    return saved ? JSON.parse(saved) : S5T_CRITERIA_LIST;
  });

  const [proofs, setProofs] = useState<S5TProof[]>(() => {
    const saved = localStorage.getItem('agu_proofs');
    return saved ? JSON.parse(saved) : INITIAL_S5T_PROOFS;
  });

  const [reports, setReports] = useState<ConfidentialReport[]>(() => {
    const saved = localStorage.getItem('agu_reports');
    return saved ? JSON.parse(saved) : INITIAL_CONFIDENTIAL_REPORTS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('agu_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  // Co-Planning, Tasks, Decrees
  const [plans, setPlans] = useState<ClubPlan[]>(() => {
    const saved = localStorage.getItem('agu_plans');
    return saved ? JSON.parse(saved) : INITIAL_PLANS;
  });

  const [tasks, setTasks] = useState<ClubTask[]>(() => {
    const saved = localStorage.getItem('agu_tasks');
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  });

  const [decrees, setDecrees] = useState<ClubDecree[]>(() => {
    const saved = localStorage.getItem('agu_decrees');
    return saved ? JSON.parse(saved) : INITIAL_DECREES;
  });

  // Recruitment & Succession & Hall of Fame States
  const [questions, setQuestions] = useState<RecruitmentQuestion[]>(() => {
    const saved = localStorage.getItem('agu_recruitment_questions');
    return saved ? JSON.parse(saved) : INITIAL_RECRUITMENT_QUESTIONS;
  });

  const [applications, setApplications] = useState<RecruitmentApplication[]>(() => {
    const saved = localStorage.getItem('agu_applications');
    return saved ? JSON.parse(saved) : INITIAL_APPLICATIONS;
  });

  const [hallOfFame, setHallOfFame] = useState<HallOfFameItem[]>(() => {
    const saved = localStorage.getItem('agu_hall_of_fame');
    return saved ? JSON.parse(saved) : HALL_OF_FAME_DATA;
  });

  // =========================================================================
  // MULTI-DEVICE CLOUD SYNCHRONIZATION LOGIC (WITH SELF-HEALING ACCOUNT MERGE)
  // =========================================================================
  // Helper to load remote state into React without ever losing local accounts
  const applyRemoteState = (cloudData: GlobalSyncState) => {
    if (cloudData.userList && Array.isArray(cloudData.userList)) {
      const deletedSet = new Set(cloudData.deletedUserIds || []);
      const cloudUsers = cloudData.userList.filter(u => u && u.id && !deletedSet.has(u.id));

      // Collect all locally known accounts so no account on this device ever vanishes
      const localCandidates: UserProfile[] = [];
      try {
        const rawCurrent = localStorage.getItem('agu_user');
        if (rawCurrent) localCandidates.push(JSON.parse(rawCurrent));
        const rawPersonal = localStorage.getItem('agu_personal_user');
        if (rawPersonal) localCandidates.push(JSON.parse(rawPersonal));
        const rawMyList = localStorage.getItem('agu_my_accounts');
        if (rawMyList) {
          const parsed = JSON.parse(rawMyList);
          if (Array.isArray(parsed)) localCandidates.push(...parsed);
        }
        const rawUserList = localStorage.getItem('agu_user_list');
        if (rawUserList) {
          const parsed = JSON.parse(rawUserList);
          if (Array.isArray(parsed)) localCandidates.push(...parsed);
        }
      } catch {
        // ignore JSON parse errors
      }

      const missingOnCloud: UserProfile[] = [];
      const mergedList = [...cloudUsers];

      for (const localUser of localCandidates) {
        if (!localUser || !localUser.id || deletedSet.has(localUser.id)) continue;
        const existsInMerged = mergedList.some(
          cu =>
            cu.id === localUser.id ||
            (cu.studentId &&
              localUser.studentId &&
              cu.studentId.toLowerCase() === localUser.studentId.toLowerCase() &&
              cu.role !== 'bcn_admin' &&
              localUser.role !== 'bcn_admin') ||
            (cu.email &&
              localUser.email &&
              cu.email.toLowerCase() === localUser.email.toLowerCase() &&
              cu.id !== 'bcn-root' &&
              localUser.id !== 'bcn-root')
        );
        if (!existsInMerged) {
          mergedList.push(localUser);
          missingOnCloud.push(localUser);
        }
      }

      setUserList(mergedList);

      // Update currentUser if server has fresher fields (e.g. role appointment, meritPoints, badges) while protecting daily streak
      const todayStr = new Date().toLocaleDateString('vi-VN');
      setCurrentUser(prev => {
        const updatedSelf = mergedList.find(
          u =>
            u.id === prev.id ||
            (u.studentId && prev.studentId && u.studentId.toLowerCase() === prev.studentId.toLowerCase() && u.role === prev.role)
        );
        if (!updatedSelf) return prev;
        const mergedLastDate = updatedSelf.lastCheckInDate || prev.lastCheckInDate;
        const checkedToday = mergedLastDate === todayStr;
        return {
          ...prev,
          ...updatedSelf,
          readingStreak: Math.max(prev.readingStreak || 1, updatedSelf.readingStreak || 1),
          enewsStreak: Math.max(prev.enewsStreak || 1, updatedSelf.enewsStreak || 1),
          lastCheckInDate: mergedLastDate,
          hasCheckedInToday: checkedToday
        };
      });

      // Keep mySavedAccounts refreshed with latest profile fields from mergedList
      setMySavedAccounts(prev => {
        const next = prev
          .filter(u => !deletedSet.has(u.id))
          .map(savedAcc => {
            const fresh = mergedList.find(
              u =>
                u.id === savedAcc.id ||
                (u.studentId && savedAcc.studentId && u.studentId.toLowerCase() === savedAcc.studentId.toLowerCase())
            );
            return fresh ? { ...savedAcc, ...fresh } : savedAcc;
          });
        localStorage.setItem('agu_my_accounts', JSON.stringify(next));
        return next;
      });

      // Self-heal: if this device had accounts not yet on the server, push them to the server
      if (missingOnCloud.length > 0) {
        ensureLocalUsersOnCloud(missingOnCloud);
      }
    }
    if (cloudData.posts && Array.isArray(cloudData.posts)) setPosts(cloudData.posts);
    if (cloudData.locketMoments && Array.isArray(cloudData.locketMoments)) setLocketMoments(cloudData.locketMoments);
    if (cloudData.criteria && Array.isArray(cloudData.criteria)) setCriteria(cloudData.criteria);
    if (cloudData.proofs && Array.isArray(cloudData.proofs)) setProofs(cloudData.proofs);
    if (cloudData.reports && Array.isArray(cloudData.reports)) setReports(cloudData.reports);
    if (cloudData.transactions && Array.isArray(cloudData.transactions)) setTransactions(cloudData.transactions);
    if (cloudData.plans && Array.isArray(cloudData.plans)) setPlans(cloudData.plans);
    if (cloudData.tasks && Array.isArray(cloudData.tasks)) setTasks(cloudData.tasks);
    if (cloudData.decrees && Array.isArray(cloudData.decrees)) setDecrees(cloudData.decrees);
    if (cloudData.questions && Array.isArray(cloudData.questions)) setQuestions(cloudData.questions);
    if (cloudData.applications && Array.isArray(cloudData.applications)) setApplications(cloudData.applications);
    if (cloudData.hallOfFame && Array.isArray(cloudData.hallOfFame)) setHallOfFame(cloudData.hallOfFame);
    
    if (cloudData.lastUpdated) {
      setLastServerUpdate(cloudData.lastUpdated);
      lastServerUpdateRef.current = cloudData.lastUpdated;
    }
    setSyncStatus('connected');
  };

  // Initial load from cloud + continuous polling every 1.5s for changes made on other devices
  useEffect(() => {
    let isMounted = true;

    async function initialSync() {
      setSyncStatus('syncing');
      const cloudData = await fetchCloudState();
      if (cloudData && isMounted) {
        applyRemoteState(cloudData);
        isInitialLoadDone.current = true;
      } else if (isMounted) {
        setSyncStatus('connected');
        isInitialLoadDone.current = true;
      }
    }
    initialSync();

    // Poll every 1.5s to catch updates from other phones/laptops without echo overwrites
    const interval = setInterval(async () => {
      const cloudData = await fetchCloudState();
      if (cloudData && isMounted) {
        // If server timestamp is newer than our last known update, apply remote state
        if (!lastServerUpdateRef.current || cloudData.lastUpdated > lastServerUpdateRef.current) {
          applyRemoteState(cloudData);
        }
      }
    }, 1500);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // Manual Trigger to force instant cloud refresh
  const handleManualSyncNow = async () => {
    setIsManualSyncing(true);
    setSyncStatus('syncing');
    const cloudData = await fetchCloudState();
    if (cloudData) {
      applyRemoteState(cloudData);
      confetti({
        particleCount: 40,
        spread: 50,
        origin: { y: 0.1 }
      });
    }
    setTimeout(() => {
      setIsManualSyncing(false);
      setSyncStatus('connected');
    }, 600);
  };

  // Local storage caching ONLY (Never auto-push on change to prevent overwriting other devices)
  useEffect(() => {
    localStorage.setItem('agu_authenticated', String(isAuthenticated));
  }, [isAuthenticated]);

  useEffect(() => {
    localStorage.setItem('agu_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('agu_is_bcn', String(isBcnMode));
  }, [isBcnMode]);

  useEffect(() => {
    localStorage.setItem('agu_user_list', JSON.stringify(userList));
  }, [userList]);

  useEffect(() => {
    localStorage.setItem('agu_posts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('agu_lockets', JSON.stringify(locketMoments));
  }, [locketMoments]);

  useEffect(() => {
    localStorage.setItem('agu_criteria', JSON.stringify(criteria));
  }, [criteria]);

  useEffect(() => {
    localStorage.setItem('agu_proofs', JSON.stringify(proofs));
  }, [proofs]);

  useEffect(() => {
    localStorage.setItem('agu_reports', JSON.stringify(reports));
  }, [reports]);

  useEffect(() => {
    localStorage.setItem('agu_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('agu_plans', JSON.stringify(plans));
  }, [plans]);

  useEffect(() => {
    localStorage.setItem('agu_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('agu_decrees', JSON.stringify(decrees));
  }, [decrees]);

  useEffect(() => {
    localStorage.setItem('agu_recruitment_questions', JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    localStorage.setItem('agu_applications', JSON.stringify(applications));
  }, [applications]);

  useEffect(() => {
    localStorage.setItem('agu_hall_of_fame', JSON.stringify(hallOfFame));
  }, [hallOfFame]);

  // Auth gate handlers (persists registration directly to cloud server)
  const handleSelectUser = (user: UserProfile) => {
    setCurrentUser(user);
    setUserList(prev => {
      const exists = prev.some(u => u.id === user.id);
      return exists ? prev.map(u => (u.id === user.id ? user : u)) : [user, ...prev];
    });
    if (user.id !== 'bcn-root' && user.adminType !== 'master_root') {
      rememberPersonalAccount(user);
    }
  };

  const handleGateLogin = (user: UserProfile, isBcn: boolean) => {
    handleSelectUser(user);
    setIsBcnMode(isBcn);
    setIsAuthenticated(true);
  };

  const handleGateRegister = async (newUser: UserProfile) => {
    setUserList(prev => [newUser, ...prev.filter(u => u.id !== newUser.id)]);
    setCurrentUser(newUser);
    rememberPersonalAccount(newUser);
    setIsBcnMode(false);
    setIsAuthenticated(true);
    const updatedState = await registerUserToCloud(newUser);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setIsBcnMode(false);
  };

  // Actions
  const handleCheckIn = async () => {
    const todayStr = new Date().toLocaleDateString('vi-VN');
    if (currentUser.lastCheckInDate === todayStr) return;

    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.6 },
      colors: ['#3B6E47', '#6AD5A1', '#C88A36', '#FAF6EB']
    });

    const updatedUser: UserProfile = {
      ...currentUser,
      readingStreak: Math.max(1, (currentUser.readingStreak || 0) + 1),
      enewsStreak: Math.max(1, (currentUser.enewsStreak || 0) + 1),
      hasCheckedInToday: true,
      lastCheckInDate: todayStr,
      meritPoints: (currentUser.meritPoints || 50) + 10
    };

    setCurrentUser(updatedUser);
    rememberPersonalAccount(updatedUser);
    setUserList(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));

    const updatedState = await updateProfileOnCloud({
      userId: updatedUser.id,
      readingStreak: updatedUser.readingStreak,
      enewsStreak: updatedUser.enewsStreak,
      hasCheckedInToday: true,
      lastCheckInDate: todayStr,
      meritPoints: updatedUser.meritPoints
    });
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleRegisterUser = async (newUser: UserProfile) => {
    setUserList(prev => [newUser, ...prev.filter(u => u.id !== newUser.id)]);
    rememberPersonalAccount(newUser);
    const updatedState = await registerUserToCloud(newUser);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleLikePost = async (postId: string) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        const nextLiked = !p.userLiked;
        return {
          ...p,
          userLiked: nextLiked,
          likes: nextLiked ? p.likes + 1 : Math.max(0, p.likes - 1)
        };
      }
      return p;
    }));
    const updatedState = await sendPostLikeToCloud(postId, currentUser.id);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleAddComment = async (postId: string, comment: { author: string; avatar: string; text: string; time: string }) => {
    const updatedState = await sendPostCommentToCloud(postId, comment);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleReactLocket = async (locketId: string) => {
    setLocketMoments(prev => prev.map(m => {
      if (m.id === locketId) {
        const nextReact = !m.userReacted;
        return {
          ...m,
          userReacted: nextReact,
          reactions: nextReact ? m.reactions + 1 : Math.max(0, m.reactions - 1)
        };
      }
      return m;
    }));
    const updatedState = await sendLocketReactToCloud(locketId);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleAddPost = async (newPost: Omit<Post, 'id' | 'createdAt' | 'likes' | 'commentsCount'>) => {
    const postItem: Post = {
      ...newPost,
      id: `post-${Date.now()}`,
      authorId: currentUser.id,
      authorNickname: currentUser.nickname,
      createdAt: 'Vừa xong',
      likes: 1,
      userLiked: true,
      commentsCount: 0
    };
    setPosts(prev => [postItem, ...prev]);
    const updatedState = await sendPostToCloud(postItem);
    if (updatedState) applyRemoteState(updatedState);

    // Auto-increment daily streak when member posts a book review or E-News article
    const todayStr = new Date().toLocaleDateString('vi-VN');
    if (currentUser.lastCheckInDate !== todayStr) {
      await handleCheckIn();
    }
  };

  const handleDeletePost = async (postId: string) => {
    setPosts(prev => prev.filter(p => p.id !== postId));
    const updatedState = await deleteItemFromCloud('posts', postId);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleAddLocket = async (newMoment: Omit<LocketMoment, 'id' | 'timestamp' | 'reactions'>) => {
    const locketItem: LocketMoment = {
      ...newMoment,
      id: `locket-${Date.now()}`,
      authorId: currentUser.id,
      authorNickname: currentUser.nickname,
      timestamp: 'Vừa xong',
      reactions: 1,
      userReacted: true
    };
    setLocketMoments(prev => [locketItem, ...prev]);
    const updatedState = await sendLocketToCloud(locketItem);
    if (updatedState) applyRemoteState(updatedState);

    // Auto-increment daily streak when member shares a Locket reading moment
    const todayStr = new Date().toLocaleDateString('vi-VN');
    if (currentUser.lastCheckInDate !== todayStr) {
      await handleCheckIn();
    }
  };

  const handleDeleteLocket = async (locketId: string) => {
    setLocketMoments(prev => prev.filter(m => m.id !== locketId));
    const updatedState = await deleteItemFromCloud('locketMoments', locketId);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleSubmitProof = async (proofData: Omit<S5TProof, 'id' | 'submittedAt' | 'status'>) => {
    const proofItem: S5TProof = {
      ...proofData,
      id: `proof-${Date.now()}`,
      userId: currentUser.id,
      submittedAt: new Date().toLocaleDateString('vi-VN'),
      status: 'pending'
    };
    const nextProofs = [proofItem, ...proofs];
    setProofs(nextProofs);
    const updatedState = await pushCloudSync('proofs', nextProofs);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleDeleteProof = async (proofId: string) => {
    setProofs(prev => prev.filter(p => p.id !== proofId));
    const updatedState = await deleteItemFromCloud('proofs', proofId);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleReviewProof = async (proofId: string, status: 'approved' | 'rejected', comment: string) => {
    const nextProofs = proofs.map(p => {
      if (p.id === proofId) {
        return {
          ...p,
          status,
          reviewedBy: currentUser.name,
          reviewComment: comment
        };
      }
      return p;
    });
    setProofs(nextProofs);

    let nextCriteria = criteria;
    if (status === 'approved') {
      const reviewedProof = proofs.find(p => p.id === proofId);
      if (reviewedProof) {
        nextCriteria = criteria.map(c => {
          if (c.id === reviewedProof.criterionId) {
            const nextCompleted = c.completedCount + 1;
            return {
              ...c,
              completedCount: nextCompleted,
              status: (nextCompleted >= c.requiredCount ? 'completed' : 'in_progress') as S5TCriterion['status']
            };
          }
          return c;
        });
        setCriteria(nextCriteria);
        await pushCloudSync('criteria', nextCriteria);
      }
    }
    const updatedState = await pushCloudSync('proofs', nextProofs);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleSendReport = async (reportData: Omit<ConfidentialReport, 'id' | 'createdAt' | 'status'>) => {
    const newReport: ConfidentialReport = {
      ...reportData,
      id: `rep-${Date.now().toString().slice(-4)}-${Math.floor(Math.random() * 1000)}`,
      realSenderId: currentUser.id,
      realSenderNickname: currentUser.nickname,
      createdAt: new Date().toLocaleDateString('vi-VN'),
      status: 'received'
    };
    setReports(prev => [newReport, ...prev]);
    const updatedState = await sendReportToCloud(newReport);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleDeleteReport = async (reportId: string) => {
    setReports(prev => prev.filter(r => r.id !== reportId));
    const updatedState = await deleteItemFromCloud('reports', reportId);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleUpdateBcnResponse = async (reportId: string, response: string) => {
    const updatedReports = reports.map(r => {
      if (r.id === reportId) {
        return {
          ...r,
          bcnResponse: response,
          status: 'resolved' as const
        };
      }
      return r;
    });
    setReports(updatedReports);
    const updatedState = await sendReportResponseToCloud(reportId, response);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleUpdateProfile = async (payload: { userId: string; avatar?: string; nickname?: string; favoriteBook?: string; newPassword?: string }) => {
    // Update local state immediately
    if (currentUser.id === payload.userId) {
      const updatedCurrent: UserProfile = {
        ...currentUser,
        avatar: payload.avatar || currentUser.avatar,
        nickname: payload.nickname !== undefined ? payload.nickname : currentUser.nickname,
        favoriteBook: payload.favoriteBook !== undefined ? payload.favoriteBook : currentUser.favoriteBook,
        password: payload.newPassword || currentUser.password
      };
      setCurrentUser(updatedCurrent);
      rememberPersonalAccount(updatedCurrent);
    }
    setUserList(prev => prev.map(u => {
      if (u.id === payload.userId) {
        return {
          ...u,
          avatar: payload.avatar || u.avatar,
          nickname: payload.nickname !== undefined ? payload.nickname : u.nickname,
          favoriteBook: payload.favoriteBook !== undefined ? payload.favoriteBook : u.favoriteBook,
          password: payload.newPassword || u.password
        };
      }
      return u;
    }));

    const updatedState = await updateProfileOnCloud(payload);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleAssignRole = async (payload: { targetUserId: string; department: string; roleTitle: string; departmentRole: 'leader' | 'vice_leader' | 'member'; roleType: 'member' | 'lead' | 'bcn_admin' }) => {
    setUserList(prev => prev.map(u => {
      if (u.id === payload.targetUserId) {
        return {
          ...u,
          department: payload.department as DepartmentType,
          departmentRole: payload.departmentRole,
          position: payload.roleTitle,
          role: payload.roleType as RoleType
        };
      }
      return u;
    }));
    const updatedState = await assignRoleOnCloud(payload);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleAddTransaction = async (newTx: Omit<Transaction, 'id'>) => {
    const txItem: Transaction = {
      ...newTx,
      id: `tx-${Date.now()}`
    };
    const nextTx = [txItem, ...transactions];
    setTransactions(nextTx);
    const updatedState = await addTransactionToCloud(txItem);
    if (updatedState) applyRemoteState(updatedState);
  };

  // Co-Planning and Tasks Handlers
  const handleAddPlan = async (newPlan: Omit<ClubPlan, 'id' | 'votesAgree' | 'votesDisagree'>) => {
    const planItem: ClubPlan = {
      ...newPlan,
      id: `plan-${Date.now()}`,
      votesAgree: 1,
      votesDisagree: 0,
      userVoted: 'agree',
      submittedByRole: currentUser.position || `${currentUser.departmentRole === 'leader' ? 'Trưởng ban' : currentUser.departmentRole === 'vice_leader' ? 'Phó ban' : 'Thành viên'} Ban ${currentUser.department}`
    };
    const nextPlans = [planItem, ...plans];
    setPlans(nextPlans);
    const updatedState = await addPlanToCloud(planItem);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleVotePlan = async (planId: string, vote: 'agree' | 'disagree') => {
    const nextPlans = plans.map(p => {
      if (p.id === planId) {
        if (p.userVoted === vote) return p;
        const agreeDelta = vote === 'agree' ? 1 : (p.userVoted === 'agree' ? -1 : 0);
        const disagreeDelta = vote === 'disagree' ? 1 : (p.userVoted === 'disagree' ? -1 : 0);
        return {
          ...p,
          votesAgree: Math.max(0, p.votesAgree + agreeDelta),
          votesDisagree: Math.max(0, p.votesDisagree + disagreeDelta),
          userVoted: vote
        };
      }
      return p;
    });
    setPlans(nextPlans);
    const updatedState = await pushCloudSync('plans', nextPlans);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleUpdatePlanStatus = async (planId: string, status: ClubPlan['status']) => {
    const nextPlans = plans.map(p =>
      p.id === planId
        ? {
            ...p,
            status,
            archivedAt: status === 'approved' ? new Date().toLocaleDateString('vi-VN') : p.archivedAt
          }
        : p
    );
    setPlans(nextPlans);
    const updatedState = await pushCloudSync('plans', nextPlans);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleDeletePlan = async (planId: string) => {
    setPlans(prev => prev.filter(p => p.id !== planId));
    const updatedState = await deleteItemFromCloud('plans', planId);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleAddTask = async (newTask: Omit<ClubTask, 'id'>) => {
    const taskItem: ClubTask = {
      ...newTask,
      id: `task-${Date.now()}`
    };
    const nextTasks = [taskItem, ...tasks];
    setTasks(nextTasks);
    const updatedState = await pushCloudSync('tasks', nextTasks);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleDeleteTask = async (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
    const updatedState = await deleteItemFromCloud('tasks', taskId);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleUpdateTaskStatus = async (taskId: string, status: ClubTask['status']) => {
    const nextTasks = tasks.map(t => t.id === taskId ? { ...t, status } : t);
    setTasks(nextTasks);
    const updatedState = await pushCloudSync('tasks', nextTasks);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleCompleteTaskAndReward = async (taskId: string, memberName: string, points: number) => {
    const nextTasks = tasks.map(t => t.id === taskId ? { ...t, status: 'done' as const } : t);
    setTasks(nextTasks);
    
    // Reward points to that member
    const nextUsers = userList.map(u => {
      if (u.name.toLowerCase().includes(memberName.toLowerCase()) || memberName.toLowerCase().includes(u.name.toLowerCase())) {
        return { ...u, meritPoints: (u.meritPoints || 50) + points };
      }
      return u;
    });
    setUserList(nextUsers);

    if (currentUser.name.toLowerCase().includes(memberName.toLowerCase())) {
      setCurrentUser(prev => ({ ...prev, meritPoints: (prev.meritPoints || 50) + points }));
    }

    await pushCloudSync('tasks', nextTasks);
    const updatedState = await pushCloudSync('userList', nextUsers);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleAwardBadge = async (userId: string, badgeName: string, points: number) => {
    const nextUsers = userList.map(u => {
      if (u.id === userId) {
        const nextBadges = u.badges.includes(badgeName) ? u.badges : [...u.badges, badgeName];
        return { ...u, badges: nextBadges, meritPoints: (u.meritPoints || 50) + points };
      }
      return u;
    });
    setUserList(nextUsers);

    if (currentUser.id === userId) {
      setCurrentUser(prev => ({
        ...prev,
        badges: prev.badges.includes(badgeName) ? prev.badges : [...prev.badges, badgeName],
        meritPoints: (prev.meritPoints || 50) + points
      }));
    }

    const updatedState = await pushCloudSync('userList', nextUsers);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleIssueDecree = async (newDecree: Omit<ClubDecree, 'id' | 'issuedAt'>) => {
    const decreeItem: ClubDecree = {
      ...newDecree,
      id: `dec-${Date.now()}`,
      issuedAt: new Date().toLocaleDateString('vi-VN')
    };
    const nextDecrees = [decreeItem, ...decrees];
    setDecrees(nextDecrees);
    const updatedState = await pushCloudSync('decrees', nextDecrees);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleDeleteDecree = async (decreeId: string) => {
    setDecrees(prev => prev.filter(d => d.id !== decreeId));
    const updatedState = await deleteItemFromCloud('decrees', decreeId);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleUnlockBcn = (passcode: string) => {
    if (passcode.trim() === MASTER_PASSCODE) {
      setIsBcnMode(true);
      return true;
    }
    return false;
  };

  const handleExitBcnMode = () => {
    setIsBcnMode(false);
  };

  // Recruitment Question & Application Handlers
  const handleAddQuestion = async (q: Omit<RecruitmentQuestion, 'id'>) => {
    const newQ: RecruitmentQuestion = {
      ...q,
      id: `q-${Date.now()}`
    };
    const nextQ = [...questions, newQ];
    setQuestions(nextQ);
    const updatedState = await pushCloudSync('questions', nextQ);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleDeleteQuestion = async (id: string) => {
    const nextQ = questions.filter(q => q.id !== id);
    setQuestions(nextQ);
    const updatedState = await pushCloudSync('questions', nextQ);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleSubmitApplication = async (app: Omit<RecruitmentApplication, 'id' | 'status' | 'submittedAt'>) => {
    const newApp: RecruitmentApplication = {
      ...app,
      id: `app-${Date.now().toString().slice(-4)}`,
      status: 'pending',
      submittedAt: new Date().toLocaleDateString('vi-VN')
    };
    const nextApps = [newApp, ...applications];
    setApplications(nextApps);
    const updatedState = await pushCloudSync('applications', nextApps);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleReviewApplication = async (appId: string, status: 'approved' | 'rejected', notes: string) => {
    const nextApps = applications.map(a => {
      if (a.id === appId) {
        return {
          ...a,
          status,
          bcnNotes: notes
        };
      }
      return a;
    });
    setApplications(nextApps);
    const updatedState = await pushCloudSync('applications', nextApps);
    if (updatedState) applyRemoteState(updatedState);
  };

  // Succession Transfer Handler: Named Transfer (Bàn giao đích danh) + Preserve Outgoing Leader
  const handleTransferSuccession = async (payload: SuccessionTransferPayload) => {
    const {
      positionTitle,
      outgoingLeader,
      incomingMemberId,
      isNewCustomMember,
      newCustomInfo,
      hallOfFameRecord
    } = payload;

    // 1. Add record to Hall of Fame locally
    setHallOfFame(prev => [hallOfFameRecord, ...prev]);

    // Create new custom leader object if custom
    let newLeaderObj: UserProfile | undefined;
    if (isNewCustomMember && newCustomInfo) {
      newLeaderObj = {
        id: `bcn-elected-${Date.now()}`,
        name: newCustomInfo.name,
        nickname: newCustomInfo.nickname,
        studentId: newCustomInfo.studentId,
        faculty: newCustomInfo.faculty,
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        role: 'bcn_admin' as RoleType,
        adminType: 'bcn_elected' as AdminAccountType,
        department: 'BQT' as DepartmentType,
        position: positionTitle,
        term: 'Nhiệm kỳ mới (2026-2027)',
        readingStreak: 1,
        enewsStreak: 1,
        hasCheckedInToday: false,
        s5tProgress: 50,
        favoriteBook: newCustomInfo.favoriteBook || 'Nhà Giả Kim',
        joinDate: 'Tháng 10/2026',
        meritPoints: 600,
        badges: ['Tân BCN Đương Nhiệm 👑', 'Người Dẫn Đường AGU 🔥']
      };
    }

    // Call server endpoint for succession
    const updatedState = await transferSuccessionToCloud({
      outgoingLeaderId: outgoingLeader.id,
      incomingMemberId: incomingMemberId || undefined,
      newLeader: newLeaderObj,
      hallOfFameRecord,
      positionTitle
    });

    if (updatedState) {
      applyRemoteState(updatedState);
    } else {
      // Local fallback
      setUserList(prev => {
        let updated = [...prev];
        updated = updated.map(u => {
          if (u.id === outgoingLeader.id) {
            const isVice = outgoingLeader.position.toLowerCase().includes('phó');
            return {
              ...u,
              role: 'member' as RoleType,
              adminType: 'member' as AdminAccountType,
              position: isVice ? 'Cựu Phó Chủ nhiệm CLB (Tiền bối danh dự)' : 'Cựu Chủ nhiệm CLB (Tiền bối danh dự)',
              badges: u.badges.includes('Cựu BCN Tiền Nhiệm 🎖️') ? u.badges : [...u.badges, 'Cựu BCN Tiền Nhiệm 🎖️']
            };
          }
          return u;
        });
        if (newLeaderObj) updated = [newLeaderObj, ...updated];
        return updated;
      });
    }

    // If currently logged into the outgoing leader account, reflect updated emeritus title
    if (currentUser.id === outgoingLeader.id) {
      const isVice = outgoingLeader.position.toLowerCase().includes('phó');
      const emeritusPosition = isVice 
        ? 'Cựu Phó Chủ nhiệm CLB (Tiền bối danh dự)' 
        : 'Cựu Chủ nhiệm CLB (Tiền bối danh dự)';
      setCurrentUser(prev => ({
        ...prev,
        role: 'member',
        adminType: 'member',
        position: emeritusPosition,
        badges: [...prev.badges.filter(b => !b.includes('Chủ Nhiệm Nhiệm Kỳ')), 'Cựu BCN Tiền Nhiệm 🎖️']
      }));
    }
  };

  // Admin Account Deletion Handler (Deletes account with security bounds and cloud sync)
  const handleDeleteUser = async (userId: string) => {
    const target = userList.find(u => u.id === userId);
    if (!target) return;
    if (target.id === 'bcn-root' || target.adminType === 'master_root') {
      alert('Không thể xóa Tài khoản Gốc Vĩnh Viễn của CLB!');
      return;
    }

    const updatedList = userList.filter(u => u.id !== userId);
    setUserList(updatedList);
    localStorage.setItem('agu_user_list', JSON.stringify(updatedList));

    const updatedState = await deleteUserFromCloud(userId);
    if (updatedState) applyRemoteState(updatedState);

    // If active user was deleted, fallback to bcn-root or first member
    if (currentUser.id === userId) {
      const rootUser = (updatedState ? updatedState.userList : updatedList).find(u => u.id === 'bcn-root') || updatedList[0];
      if (rootUser) {
        setCurrentUser(rootUser);
      }
    }
  };

  // Hall of Fame manual add and delete by BCN admin
  const handleAddToHallOfFame = async (newItem: Omit<HallOfFameItem, 'id'>) => {
    const record: HallOfFameItem = {
      ...newItem,
      id: `hof-${Date.now()}`
    };
    const nextHof = [record, ...hallOfFame];
    setHallOfFame(nextHof);
    const updatedState = await pushCloudSync('hallOfFame', nextHof);
    if (updatedState) applyRemoteState(updatedState);
  };

  const handleDeleteFromHallOfFame = async (id: string) => {
    const nextHof = hallOfFame.filter(item => item.id !== id);
    setHallOfFame(nextHof);
    const updatedState = await pushCloudSync('hallOfFame', nextHof);
    if (updatedState) applyRemoteState(updatedState);
  };

  // If user is not authenticated yet, show Upfront Registration & Login Gate
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col justify-between">
        {/* Top Multi-Device Sync Banner */}
        <div className="bg-[#1C3621] text-emerald-200 text-xs py-1.5 px-4 border-b border-[#3B6645] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <Cloud className="w-3.5 h-3.5 text-emerald-300" />
            <span className="font-semibold text-white">Đồng Bộ Đa Thiết Bị:</span>
            <span>Tài khoản & dữ liệu liên kết trực tiếp giữa Máy tính ↔ Điện thoại</span>
          </div>

          <button
            type="button"
            onClick={handleManualSyncNow}
            disabled={isManualSyncing}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-white/10 hover:bg-white/20 text-[11px] font-bold text-white transition cursor-pointer"
          >
            <RefreshCw className={`w-3 h-3 ${isManualSyncing ? 'animate-spin' : ''}`} />
            <span>Làm Mới Máy Chủ</span>
          </button>
        </div>

        <InitialAuthGate
          onLogin={handleGateLogin}
          onRegister={handleGateRegister}
          userList={userList}
          mySavedAccounts={mySavedAccounts}
        />

        <div className="text-center py-3 text-stone-500 text-[11px]">
          CLB Đọc và Giới thiệu sách • Hệ thống máy chủ đồng bộ thời gian thực
        </div>
      </div>
    );
  }

  const pinnedDecree = decrees.find(d => d.pinToIsland) || decrees[0];

  return (
    <div className="min-h-screen flex flex-col selection:bg-[#5E936B] selection:text-white pb-10">
      {/* Multi-Device Cloud Sync Floating Status Bar */}
      <div className="bg-[#172D1C] text-emerald-200 text-xs py-1 px-3 sm:px-6 border-b border-[#2C4F33] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <div className="flex items-center gap-1 text-white font-bold">
              <Cloud className="w-3.5 h-3.5 text-emerald-400" />
              <span>Đồng Bộ Đa Thiết Bị Trực Tiếp:</span>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 text-emerald-300">
              <Laptop className="w-3 h-3" />
              <span>Máy tính</span>
              <span>↔</span>
              <Smartphone className="w-3 h-3" />
              <span>Điện thoại</span>
              <span>•</span>
              <span>{userList.length} tài khoản thành viên</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleManualSyncNow}
              disabled={isManualSyncing}
              className="flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-800/80 hover:bg-emerald-700 text-emerald-100 text-[10px] font-bold transition cursor-pointer border border-emerald-600/50"
              title="Đồng bộ ngay dữ liệu mới nhất từ các thiết bị khác"
            >
              <RefreshCw className={`w-3 h-3 ${isManualSyncing ? 'animate-spin text-amber-300' : ''}`} />
              <span>{isManualSyncing ? 'Đang đồng bộ...' : 'Đồng Bộ Ngay'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Dynamic Book Island at top */}
      <DynamicIsland
        currentUser={currentUser}
        onCheckIn={handleCheckIn}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        isBcnMode={isBcnMode}
        latestDecree={pinnedDecree}
      />

      {/* Main Navbar */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        currentUser={currentUser}
        isBcnMode={isBcnMode}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Sub-header notification bar for Master Root Account or quick switches */}
      {isMasterRoot && (
        <div className="bg-[#1C3621] text-amber-200 text-xs py-2 px-4 border-b border-amber-400/40">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-bold text-white">Tài Khoản Gốc Vĩnh Viễn:</span>
              <span>{currentUser.name} ({currentUser.email})</span>
              <span className="hidden md:inline text-[10px] bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded border border-amber-400/30">
                Toàn Quyền Quản Trị
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('recruitment')}
                className={`px-2.5 py-1 rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer transition ${
                  activeTab === 'recruitment' ? 'bg-amber-400 text-stone-900' : 'bg-white/10 hover:bg-white/20 text-white'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                Tuyển Thành Viên
              </button>

              <button
                type="button"
                onClick={() => setIsSuccessionModalOpen(true)}
                className="px-2.5 py-1 rounded-lg font-bold text-xs bg-amber-500 hover:bg-amber-400 text-stone-900 flex items-center gap-1 cursor-pointer transition shadow-2xs"
              >
                <Crown className="w-3.5 h-3.5" />
                Bàn Giao Nhiệm Kỳ
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('fame')}
                className={`px-2.5 py-1 rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer transition ${
                  activeTab === 'fame' ? 'bg-amber-400 text-stone-900' : 'bg-white/10 hover:bg-white/20 text-white'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                Bảo Tàng Thành Tựu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Application Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 pt-5 pb-10">
        {activeTab === 'feed' && (
          <NewfeedSection
            currentUser={currentUser}
            isBcnMode={isBcnMode}
            posts={posts}
            locketMoments={locketMoments}
            onLikePost={handleLikePost}
            onReactLocket={handleReactLocket}
            onAddPost={handleAddPost}
            onDeletePost={handleDeletePost}
            onAddLocket={handleAddLocket}
            onDeleteLocket={handleDeleteLocket}
            onCheckIn={handleCheckIn}
            onAddComment={handleAddComment}
          />
        )}

        {activeTab === 'command' && (
          <BcnCommandCenter
            currentUser={currentUser}
            isBcnMode={isBcnMode}
            isMasterRoot={isMasterRoot}
            plans={plans}
            tasks={tasks}
            decrees={decrees}
            userList={userList}
            reports={reports}
            transactions={transactions}
            posts={posts}
            onAddPlan={handleAddPlan}
            onDeletePlan={handleDeletePlan}
            onVotePlan={handleVotePlan}
            onUpdatePlanStatus={handleUpdatePlanStatus}
            onAddTask={handleAddTask}
            onDeleteTask={handleDeleteTask}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onCompleteTaskAndReward={handleCompleteTaskAndReward}
            onAwardBadge={handleAwardBadge}
            onIssueDecree={handleIssueDecree}
            onDeleteDecree={handleDeleteDecree}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onOpenRecruitment={() => setActiveTab('recruitment')}
            onOpenSuccession={() => setIsSuccessionModalOpen(true)}
            onOpenHallOfFame={() => setActiveTab('fame')}
            onOpenReports={() => setActiveTab('reports')}
            onDeleteUser={handleDeleteUser}
            onStateRestored={applyRemoteState}
            onAssignRole={handleAssignRole}
          />
        )}

        {activeTab === 's5t' && (
          <S5TTrackerSection
            currentUser={currentUser}
            criteria={criteria}
            proofs={proofs}
            isBcnMode={isBcnMode}
            onSubmitProof={handleSubmitProof}
            onReviewProof={handleReviewProof}
            onDeleteProof={handleDeleteProof}
          />
        )}

        {activeTab === 'reports' && (
          <ConfidentialReportSection
            currentUser={currentUser}
            reports={reports}
            isBcnMode={isBcnMode}
            onSendReport={handleSendReport}
            onUpdateBcnResponse={handleUpdateBcnResponse}
            onDeleteReport={handleDeleteReport}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
          />
        )}

        {activeTab === 'vault' && (
          <FinancialVaultSection
            currentUser={currentUser}
            transactions={transactions}
            isBcnMode={isBcnMode}
            onUnlockBcn={handleUnlockBcn}
            onAddTransaction={handleAddTransaction}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
          />
        )}

        {activeTab === 'org' && (
          <OrgChartSection
            currentUser={currentUser}
            isBcnMode={isBcnMode}
            userList={userList}
          />
        )}

        {activeTab === 'recruitment' && (
          <RecruitmentSection
            currentUser={currentUser}
            isMasterRoot={isMasterRoot}
            questions={questions}
            applications={applications}
            onAddQuestion={handleAddQuestion}
            onDeleteQuestion={handleDeleteQuestion}
            onSubmitApplication={handleSubmitApplication}
            onReviewApplication={handleReviewApplication}
          />
        )}

        {activeTab === 'fame' && (
          <HallOfFameSection
            items={hallOfFame}
            isBcnMode={isBcnMode}
            onAddItem={handleAddToHallOfFame}
            onDeleteItem={handleDeleteFromHallOfFame}
          />
        )}
      </main>

      {/* Vintage Classic Footer */}
      <footer className="border-t border-[#DFD6C3] bg-[#EFE9DC]/90 backdrop-blur-md pt-7 pb-5 px-4 sm:px-6 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-5 text-xs text-[#526B57]">
          <div className="flex items-center gap-2.5">
            <div className="h-10 flex items-center justify-center shrink-0">
              <img 
                src="/assets/aistudio/TUYE__N_THA_NH_VIE_N_778c37b9.png" 
                alt="Logo CLB Đọc và Giới thiệu sách" 
                className="h-10 object-contain drop-shadow-xs"
              />
            </div>
            <div>
              <div className="text-[10px] sm:text-[11px] font-semibold text-[#406848] leading-tight">
                Hội sinh viên Trường Đại học An Giang
              </div>
              <div className="font-bold text-xs sm:text-sm text-[#1F3D26] font-serif-vintage leading-tight">
                Câu lạc bộ Đọc và Giới thiệu sách
              </div>
              <div className="text-[10px] sm:text-[11px] text-[#69886E] flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3 text-[#3B6E47] shrink-0" />
                <span>Địa điểm: Trường Đại học An Giang</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 text-xs font-semibold">
            <button 
              type="button" 
              onClick={() => setActiveTab('feed')} 
              className="hover:text-[#1F3D26] transition cursor-pointer"
            >
              Bản Tin E-News
            </button>
            <button 
              type="button" 
              onClick={() => setActiveTab('command')} 
              className="hover:text-[#1F3D26] transition cursor-pointer font-bold text-[#23432B]"
            >
              Kế Hoạch & BCN
            </button>
            <button 
              type="button" 
              onClick={() => setActiveTab('s5t')} 
              className="hover:text-[#1F3D26] transition cursor-pointer"
            >
              Sinh Viên 5 Tốt
            </button>
            <button 
              type="button" 
              onClick={() => setActiveTab('vault')} 
              className="hover:text-[#1F3D26] transition cursor-pointer"
            >
              Két Quỹ BCN
            </button>
            <button 
              type="button" 
              onClick={() => setActiveTab('org')} 
              className="hover:text-[#1F3D26] transition cursor-pointer"
            >
              Sơ Đồ 4 Ban
            </button>
            <button 
              type="button" 
              onClick={() => setActiveTab('fame')} 
              className="hover:text-[#1F3D26] transition cursor-pointer text-amber-800"
            >
              Bảo Tàng Thành Tựu
            </button>
            <button 
              type="button" 
              onClick={handleLogout} 
              className="hover:text-red-700 transition cursor-pointer flex items-center gap-1 text-red-800"
              title="Đăng xuất khỏi hệ thống"
            >
              <LogOut className="w-3 h-3" />
              Đăng Xuất
            </button>
          </div>

          <div className="text-center md:text-right text-[10px] sm:text-[11px] text-[#718874]">
            <p className="font-semibold text-[#37583F]">Định vị tư duy, bản lĩnh tri thức</p>
            <p className="mt-0.5">Địa điểm: Trường Đại học An Giang</p>
          </div>
        </div>
      </footer>

      {/* Authentication, Registration & BCN Portal Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        onSelectUser={handleSelectUser}
        onRegisterUser={handleRegisterUser}
        isBcnMode={isBcnMode}
        onUnlockBcn={handleUnlockBcn}
        onExitBcnMode={handleExitBcnMode}
        userList={userList}
        mySavedAccounts={mySavedAccounts}
        onDeleteUser={handleDeleteUser}
        onUpdateProfile={handleUpdateProfile}
      />

      {/* Succession Modal for BCN Turnovers */}
      <SuccessionModal
        isOpen={isSuccessionModalOpen}
        onClose={() => setIsSuccessionModalOpen(false)}
        bcnAccounts={userList.filter(u => u.adminType === 'bcn_elected')}
        userList={userList}
        currentOperator={currentUser}
        onTransferSuccession={handleTransferSuccession}
      />

      {/* Push Toast Notification System Dedicated to Ban Chủ Nhiệm */}
      <BcnToastManager
        currentUser={currentUser}
        isBcnMode={isBcnMode}
        isMasterRoot={isMasterRoot}
        applications={applications}
        plans={plans}
        reports={reports}
        onNavigateTab={(tab: ActiveTab) => setActiveTab(tab)}
      />
    </div>
  );
}
