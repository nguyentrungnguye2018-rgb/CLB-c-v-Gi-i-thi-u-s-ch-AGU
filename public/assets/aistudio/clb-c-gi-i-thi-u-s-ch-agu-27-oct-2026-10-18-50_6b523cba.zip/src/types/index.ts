/**
 * Data types for AGU Book Club Web Application
 * Câu lạc bộ Đọc và Giới thiệu sách
 */

export type RoleType = 'member' | 'lead' | 'bcn_admin';

export type AdminAccountType = 'master_root' | 'bcn_elected' | 'member';

export type DepartmentType = 'BQT' | 'Truyền thông' | 'Nội dung' | 'Nhân sự & Kế hoạch' | 'Hậu cần';

export interface UserProfile {
  id: string;
  name: string;
  nickname?: string; // Tên biệt danh vui nhộn e.g. "Mọt Sách AGU", "Vy Mộng Mơ"
  studentId: string; // e.g. DTH215842
  faculty: string; // e.g. Khoa Sư phạm, Khoa Du lịch & VHNT, Khoa CNTT
  avatar: string;
  role: RoleType;
  adminType?: AdminAccountType; // master_root = không bao giờ đổi thông tin; bcn_elected = 3 account đổi theo nhiệm kỳ
  department: DepartmentType;
  position: string; // Chủ Nhiệm, Phó Chủ Nhiệm, Trưởng Ban, Thành viên...
  departmentRole?: 'leader' | 'vice_leader' | 'member'; // Trưởng ban, Phó ban, Thành viên của 4 ban
  term?: string; // e.g. "Vĩnh Cửu" hoặc "Nhiệm kỳ VI (2026-2027)"
  email?: string;
  password?: string; // Mật khẩu riêng của từng tài khoản để bảo mật
  readingStreak: number; // ngày
  enewsStreak: number; // ngày
  hasCheckedInToday: boolean;
  lastCheckInDate?: string; // Ngày điểm danh gần nhất (VD: 27/10/2026) để tự động mở khóa chuỗi mỗi ngày mới
  s5tProgress: number; // 0 - 100%
  favoriteBook: string;
  joinDate: string;
  meritPoints: number; // Điểm lửa cống hiến do BCN trao
  badges: string[]; // Huy hiệu danh dự BCN trao
}

export interface PostComment {
  id: string;
  author: string;
  avatar: string;
  text: string;
  time: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorNickname?: string;
  authorAvatar: string;
  authorRole: string;
  authorDept: DepartmentType;
  title: string;
  bookTitle?: string;
  bookAuthor?: string;
  category: 'E-News' | 'Tản văn' | 'Góc Sách AGU' | 'Điểm Tin Tuần' | 'Phóng Sự CLB';
  content: string;
  excerpt: string;
  coverImage?: string;
  createdAt: string;
  likes: number;
  userLiked?: boolean;
  commentsCount: number;
  comments?: PostComment[];
  commentsList?: PostComment[];
  tags: string[];
  readingTimeMinutes: number;
}

export interface LocketMoment {
  id: string;
  authorId?: string;
  authorName: string;
  authorNickname?: string;
  authorAvatar: string;
  department: DepartmentType;
  imageUrl: string;
  caption: string;
  location: string;
  timestamp: string;
  reactions: number;
  userReacted?: boolean;
}

export interface S5TCriterion {
  id: string;
  name: string;
  description: string;
  iconName: string;
  requiredCount: number;
  completedCount: number;
  status: 'completed' | 'in_progress' | 'pending_review';
}

export interface S5TProof {
  id: string;
  userId?: string;
  studentId: string;
  studentName: string;
  department: DepartmentType;
  criterionId: string;
  criterionName: string;
  activityTitle: string;
  activityDate: string;
  proofUrl: string;
  attachmentType?: 'image' | 'pdf' | 'link';
  attachmentName?: string;
  proofDescription: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  reviewedBy?: string;
  reviewComment?: string;
}

export interface ConfidentialReport {
  id: string;
  recipientType: 'truong_ban' | 'bcn_master';
  targetDepartment?: DepartmentType;
  category: 'Góp ý sinh hoạt' | 'Mâu thuẫn nội bộ' | 'Ý tưởng sự kiện' | 'Cơ sở vật chất Thư viện' | 'Khác';
  title: string;
  content: string;
  isEncrypted: boolean;
  encryptedCode: string;
  realSenderId?: string;
  realSenderName: string;
  realSenderNickname?: string;
  realSenderStudentId: string;
  realSenderDept: DepartmentType;
  createdAt: string;
  status: 'received' | 'processing' | 'resolved';
  bcnResponse?: string;
  urgency: 'low' | 'medium' | 'high';
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  title: string;
  amount: number; // VNĐ
  category: 'Quỹ hội phí' | 'Mua sách mới' | 'Tổ chức Talkshow' | 'In ấn & Quà tặng' | 'Tài trợ & Quyên góp' | 'Tiệc trà & Teabreak';
  date: string;
  performedBy: string;
  approvedBy: string;
  receiptCode: string;
  receiptImage?: string; // Chụp / tải ảnh biên lai hóa đơn chứng từ
  note?: string;
}

export interface ClubDepartment {
  id: DepartmentType;
  name: string;
  lead: string;
  leadNickname?: string;
  leadTitle: string;
  leadAvatar: string;
  leadContact: string;
  memberCount: number;
  mission: string;
  color: string;
  badges: string[];
}

export interface ClubPlan {
  id: string;
  title: string;
  proposedBy: string;
  proposedById?: string;
  submittedByRole?: string; // e.g. "Trưởng Ban Nhân sự & Kế hoạch"
  department: DepartmentType;
  description: string;
  timeline: string;
  targetAudience: string;
  priority: 'high' | 'medium' | 'normal';
  status: 'under_discussion' | 'approved' | 'in_action' | 'completed';
  budgetEstimate: number;
  votesAgree: number;
  votesDisagree: number;
  userVoted?: 'agree' | 'disagree';
  assignedDept: DepartmentType;
  actionItems: string[];
  archivedAt?: string; // Thời điểm lưu trữ chính thức khi kế hoạch đã được duyệt
  attachmentUrl?: string; // File PDF hoặc Hình ảnh kế hoạch nguyên bản (DataURL/URL)
  attachmentName?: string; // Tên file gốc (VD: Ke_Hoach_Hoi_Sach_AGU_2026.pdf)
  attachmentType?: 'pdf' | 'image'; // Loại file đính kèm
  createdAt?: string;
}

export interface ClubTask {
  id: string;
  planId?: string;
  title: string;
  assignedToDept: DepartmentType;
  assignedToMemberName: string;
  deadline: string;
  status: 'todo' | 'in_progress' | 'review' | 'done';
  rewardPoints: number;
  description: string;
  feedback?: string;
}

export interface ClubDecree {
  id: string;
  title: string;
  content: string;
  issuedAt: string;
  issuedBy: string;
  type: 'urgent' | 'announcement' | 'award';
  pinToIsland: boolean;
}

// Hall of Fame / Gian Trưng Bày Thành Tựu Cố Nhân (Khi chuyển giao nhiệm kỳ)
export interface HallOfFameItem {
  id: string;
  name: string;
  nickname?: string;
  studentId: string;
  title: string;
  termYears: string;
  bestContributions: string;
  avatar: string;
  legacyQuote: string;
}

// Tuyển Thành Viên: Bộ Câu Hỏi & Đơn Sơ Tuyển
export interface RecruitmentQuestion {
  id: string;
  text: string;
  type: 'multiple_choice' | 'short_answer';
  options?: string[];
  required: boolean;
}

export interface RecruitmentApplication {
  id: string;
  fullName: string;
  nickname?: string;
  studentId: string;
  faculty: string;
  email: string;
  phone: string;
  desiredDept: DepartmentType;
  answers: Record<string, string>;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  reviewNotes?: string;
}
