import { 
  UserProfile, 
  Post, 
  LocketMoment, 
  S5TCriterion, 
  S5TProof, 
  ConfidentialReport, 
  Transaction, 
  ClubDepartment,
  ClubPlan,
  ClubTask,
  ClubDecree,
  HallOfFameItem,
  RecruitmentQuestion,
  RecruitmentApplication
} from '../types';

export const MASTER_PASSCODE = 'AGU2026';

// 4 Accounts BCN: 1 Master Root (Vĩnh Viễn, không đổi info) + 3 Nhiệm Kỳ (Đổi info theo khóa)
export const SPECIAL_BCN_ACCOUNTS: UserProfile[] = [
  {
    id: 'bcn-root',
    name: 'Câu lạc bộ Đọc và Giới thiệu sách',
    nickname: 'CLB Gốc Tối Cao 🏛️',
    studentId: 'CLB-ROOT-PERMANENT',
    email: 'clb.docsach@agu.edu.vn',
    password: 'AGU2026',
    faculty: 'Đại Diện Toàn Thể Sinh Viên CLB',
    avatar: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=150&auto=format&fit=crop&q=80',
    role: 'bcn_admin',
    adminType: 'master_root',
    department: 'BQT',
    position: 'Tài Khoản Vĩnh Viễn Không Thay Đổi',
    departmentRole: 'leader',
    term: 'Vĩnh Cửu (Không Đổi)',
    readingStreak: 99,
    enewsStreak: 99,
    hasCheckedInToday: true,
    s5tProgress: 100,
    favoriteBook: 'Tủ Sách Tri Thức Toàn Năng',
    joinDate: 'Tháng 10/2020',
    meritPoints: 9999,
    badges: ['Account Gốc Tối Cao 🏛️', 'Bảo Chứng CLB ⭐']
  },
  {
    id: 'bcn-lead-1',
    name: 'Lê Gia Huy',
    nickname: 'Huy Trưởng Bản 👑',
    studentId: 'DTH211045',
    email: 'giahuy.le@agu.edu.vn',
    password: 'AGU2026',
    faculty: 'Khoa Sư phạm - Ngữ Văn K22',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
    role: 'bcn_admin',
    adminType: 'bcn_elected',
    department: 'BQT',
    position: 'Chủ nhiệm CLB (Sinh viên)',
    departmentRole: 'leader',
    term: 'Nhiệm kỳ VI (2026-2027)',
    readingStreak: 45,
    enewsStreak: 32,
    hasCheckedInToday: true,
    s5tProgress: 100,
    favoriteBook: 'Nhà Giả Kim - Paulo Coelho',
    joinDate: 'Tháng 10/2022',
    meritPoints: 850,
    badges: ['Chủ Nhiệm Nhiệm Kỳ 👑', 'Người Dẫn Đường AGU 🔥']
  },
  {
    id: 'bcn-lead-2',
    name: 'Trần Đỗ Bích Ngọc',
    nickname: 'Ngọc Mọt Sách 🌸',
    studentId: 'DTH212890',
    email: 'bichngoc.tran@agu.edu.vn',
    password: 'AGU2026',
    faculty: 'Khoa Ngoại ngữ - Anh văn K22',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    role: 'bcn_admin',
    adminType: 'bcn_elected',
    department: 'BQT',
    position: 'Phó Chủ nhiệm Học thuật & Nội dung',
    departmentRole: 'vice_leader',
    term: 'Nhiệm kỳ VI (2026-2027)',
    readingStreak: 38,
    enewsStreak: 29,
    hasCheckedInToday: true,
    s5tProgress: 95,
    favoriteBook: 'Hoàng Tử Bé - Antoine de Saint-Exupéry',
    joinDate: 'Tháng 10/2022',
    meritPoints: 720,
    badges: ['Đại Sứ Học Thuật 🌟', 'Biên Tập Xuất Sắc 🖋️']
  },
  {
    id: 'bcn-lead-3',
    name: 'Võ Thành Đạt',
    nickname: 'Đạt Deadline ⚡',
    studentId: 'DTH223145',
    email: 'thanhdat.vo@agu.edu.vn',
    password: 'AGU2026',
    faculty: 'Khoa Kỹ thuật - CNTT K23',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    role: 'bcn_admin',
    adminType: 'bcn_elected',
    department: 'BQT',
    position: 'Phó Chủ nhiệm Phong trào & Kế hoạch',
    departmentRole: 'vice_leader',
    term: 'Nhiệm kỳ VI (2026-2027)',
    readingStreak: 29,
    enewsStreak: 24,
    hasCheckedInToday: false,
    s5tProgress: 90,
    favoriteBook: 'Lược Sử Loài Người - Yuval Noah Harari',
    joinDate: 'Tháng 10/2023',
    meritPoints: 680,
    badges: ['Chỉ Huy Kế Hoạch 📋', 'Chiến Binh Deadline ⚡']
  }
];

export const SAMPLE_USERS: UserProfile[] = [
  ...SPECIAL_BCN_ACCOUNTS,
  {
    id: 'user-1',
    name: 'Nguyễn Hoàng Nam',
    nickname: 'Nam Bút Mực 🖋️',
    studentId: 'DTH215842',
    email: 'nam.nh@agu.edu.vn',
    password: '123456',
    faculty: 'Khoa Sư phạm - Ngữ Văn',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    role: 'lead',
    adminType: 'member',
    department: 'Truyền thông',
    position: 'Trưởng Ban Truyền thông & E-News',
    departmentRole: 'leader',
    readingStreak: 18,
    enewsStreak: 12,
    hasCheckedInToday: false,
    s5tProgress: 80,
    favoriteBook: 'Cánh Đồng Bất Tận - Nguyễn Ngọc Tư',
    joinDate: 'Tháng 10/2023',
    meritPoints: 340,
    badges: ['Cây Bút Vàng E-News 🖋️', 'Chiến Binh Deadline ⚡']
  },
  {
    id: 'user-2',
    name: 'Lê Thị Ái Vy',
    nickname: 'Vy Mộng Mơ 🌸',
    studentId: 'DTH220145',
    email: 'vy.lta@agu.edu.vn',
    password: '123456',
    faculty: 'Khoa Ngoại ngữ - Anh văn',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    role: 'lead',
    adminType: 'member',
    department: 'Nội dung',
    position: 'Trưởng Ban Nội dung',
    departmentRole: 'leader',
    readingStreak: 25,
    enewsStreak: 19,
    hasCheckedInToday: true,
    s5tProgress: 95,
    favoriteBook: 'Cây Cam Ngọt Của Tôi',
    joinDate: 'Tháng 09/2023',
    meritPoints: 480,
    badges: ['Đại Sứ Sách 🌟', 'Bậc Thầy Đọc Đêm 🦉']
  },
  {
    id: 'user-3',
    name: 'Phạm Quỳnh Trâm',
    nickname: 'Trâm Kế Hoạch 📋',
    studentId: 'DTH210342',
    email: 'tram.pq@agu.edu.vn',
    password: '123456',
    faculty: 'Khoa Kinh tế - QTKD',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    role: 'lead',
    adminType: 'member',
    department: 'Nhân sự & Kế hoạch',
    position: 'Trưởng Ban Nhân sự & Kế hoạch',
    departmentRole: 'leader',
    readingStreak: 32,
    enewsStreak: 28,
    hasCheckedInToday: true,
    s5tProgress: 100,
    favoriteBook: 'Đắc Nhân Tâm',
    joinDate: 'Tháng 09/2022',
    meritPoints: 520,
    badges: ['Trụ Cột CLB 🏛️', 'Bậc Thầy Tổ Chức 📋']
  },
  {
    id: 'user-4',
    name: 'Trần Minh Khang',
    nickname: 'Khang Hậu Cần 📦',
    studentId: 'DTH230891',
    email: 'khang.tm@agu.edu.vn',
    password: '123456',
    faculty: 'Khoa Kỹ thuật - CNTT',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    role: 'lead',
    adminType: 'member',
    department: 'Hậu cần',
    position: 'Trưởng Ban Hậu cần & Tủ sách',
    departmentRole: 'leader',
    readingStreak: 12,
    enewsStreak: 8,
    hasCheckedInToday: false,
    s5tProgress: 65,
    favoriteBook: 'Tư Duy Nhanh Và Chậm',
    joinDate: 'Tháng 11/2024',
    meritPoints: 240,
    badges: ['Người Gác Đêm Thư Viện 📚']
  }
];

export const HALL_OF_FAME_DATA: HallOfFameItem[] = [
  {
    id: 'hof-1',
    name: 'Nguyễn Văn Minh',
    nickname: 'Minh Sách Cũ 📜',
    studentId: 'DTH190112',
    title: 'Cựu Chủ nhiệm CLB (Khóa IV: 2023 - 2024)',
    termYears: '2023 - 2024',
    bestContributions: 'Sáng lập Tủ sách Tầng 3 Thư viện AGU và phát hành 10 số E-News đầu tiên, quyên góp được hơn 2.000 đầu sách cho sinh viên.',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    legacyQuote: 'Mỗi cuốn sách trao đi là một ngọn đuốc thắp sáng lòng nhiệt huyết của thanh xuân sinh viên.'
  },
  {
    id: 'hof-2',
    name: 'Lâm Thảo My',
    nickname: 'My Hoa Cúc 🌼',
    studentId: 'DTH201489',
    title: 'Cựu Phó Chủ nhiệm Đối ngoại (Khóa V: 2024 - 2025)',
    termYears: '2024 - 2025',
    bestContributions: 'Khởi xướng chiến dịch "Trang Sách Vùng Cao Tri Tôn" và kết nối tài trợ hơn 25 triệu đồng từ cựu sinh viên AGU.',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    legacyQuote: 'Đọc sách giúp ta bao dung hơn với cuộc đời và kết nối với nhau chân thật nhất.'
  }
];

export const INITIAL_RECRUITMENT_QUESTIONS: RecruitmentQuestion[] = [
  {
    id: 'rq-1',
    text: 'Bạn thường dành thời gian đọc những thể loại sách nào nhiều nhất?',
    type: 'multiple_choice',
    options: ['Văn học kinh điển & Tản văn', 'Kỹ năng mềm & Phát triển bản thân', 'Tâm lý & Triết học', 'Khoa học & Công nghệ', 'Truyện tranh & Trinh thám'],
    required: true
  },
  {
    id: 'rq-2',
    text: 'Bạn có nguyện vọng cống hiến cho Ban chuyên môn nào?',
    type: 'multiple_choice',
    options: ['Ban Truyền thông (Thiết kế poster, viết E-News, TikTok)', 'Ban Nội dung (Biên tập sách, đàm đạo văn học)', 'Ban Nhân sự & Kế hoạch (Lên plan, tổ chức sự kiện, SV5T)', 'Ban Hậu cần (Quản lý tủ sách, âm thanh, quà tặng)'],
    required: true
  },
  {
    id: 'rq-3',
    text: 'Nếu được chọn 1 cuốn sách làm bạn đồng hành trên hoang đảo, bạn chọn cuốn nào và vì sao?',
    type: 'short_answer',
    required: true
  },
  {
    id: 'rq-4',
    text: 'Bạn có thể dành ra bao nhiêu giờ mỗi tuần cho các hoạt động của CLB?',
    type: 'multiple_choice',
    options: ['3 - 5 giờ / tuần', '5 - 8 giờ / tuần', 'Trên 8 giờ / tuần (Toàn tâm toàn ý)'],
    required: true
  },
  {
    id: 'rq-5',
    text: 'Điều gì khiến bạn muốn nộp đơn gia nhập CLB Đọc và Giới thiệu sách kỳ này?',
    type: 'short_answer',
    required: true
  }
];

export const INITIAL_APPLICATIONS: RecruitmentApplication[] = [
  {
    id: 'app-001',
    fullName: 'Dương Quốc Bảo',
    nickname: 'Bảo Cú Đêm 🦉',
    studentId: 'DTH241890',
    faculty: 'Khoa Kỹ thuật - CNTT K24',
    email: 'baodq.dth241890@agu.edu.vn',
    phone: '0912.345.678',
    desiredDept: 'Truyền thông',
    answers: {
      'rq-1': 'Khoa học & Công nghệ',
      'rq-2': 'Ban Truyền thông (Thiết kế poster, viết E-News, TikTok)',
      'rq-3': 'Lược Sử Thời Gian của Stephen Hawking, để ngắm nhìn vũ trụ khi cô đơn.',
      'rq-4': '5 - 8 giờ / tuần',
      'rq-5': 'Em muốn đem kỹ năng edit video của mình để làm sống động các clip review sách ngắn trên TikTok CLB.'
    },
    status: 'pending',
    submittedAt: '25/10/2026'
  },
  {
    id: 'app-002',
    fullName: 'Nguyễn Hà Phương',
    nickname: 'Phương Mơ Màng 🍃',
    studentId: 'DTH242104',
    faculty: 'Khoa Ngoại ngữ - Sư phạm Anh K24',
    email: 'phuongnh.dth242104@agu.edu.vn',
    phone: '0938.765.432',
    desiredDept: 'Nội dung',
    answers: {
      'rq-1': 'Văn học kinh điển & Tản văn',
      'rq-2': 'Ban Nội dung (Biên tập sách, đàm đạo văn học)',
      'rq-3': 'Kiêu Hãnh và Định Kiến - Jane Austen, để học cách thấu hiểu tâm lý con người.',
      'rq-4': '3 - 5 giờ / tuần',
      'rq-5': 'Em rất mê đọc văn học dịch và muốn cùng các anh chị viết bài cảm nhận cho chuyên san E-News.'
    },
    status: 'approved',
    submittedAt: '24/10/2026',
    reviewNotes: 'Câu trả lời sâu sắc, tư duy văn học tốt. Đã duyệt sơ tuyển vào Vòng Phỏng Vấn!'
  }
];

export const BOOK_ISLAND_QUOTES = [
  { text: 'Sách là tấm vé khứ hồi tới những miền đất ta chưa từng đặt chân.', author: 'CLB Đọc Sách' },
  { text: 'Hôm nay bạn đã đọc được 15 trang sách chưa? Giữ chuỗi lửa nào! 🔥', author: 'Thư viện Sách' },
  { text: 'Đọc một cuốn sách hay cũng như trò chuyện với người thông tuệ nhất.', author: 'René Descartes' },
  { text: 'Trang sách lật mở, chân trời nở hoa - Tự hào tuổi trẻ đọc sách! 🌿', author: 'Bản tin E-News' }
];

export const INITIAL_POSTS: Post[] = [
  {
    id: 'post-1',
    authorId: 'user-1',
    authorName: 'Nguyễn Hoàng Nam',
    authorNickname: 'Nam Bút Mực 🖋️',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    authorRole: 'Trưởng Ban Truyền thông',
    authorDept: 'Truyền thông',
    title: 'Gặp gỡ "Cánh Đồng Bất Tận" bên dòng kênh Thoại Hà mộng mơ',
    bookTitle: 'Cánh Đồng Bất Tận',
    bookAuthor: 'Nguyễn Ngọc Tư',
    category: 'E-News',
    excerpt: 'Những câu chữ gãy gọn, xót xa mà đong đầy tình người miền Tây sông nước được đọc dưới bóng cây phượng vĩ sân trường.',
    content: `Có những buổi chiều sau giờ học tại khu giảng đường, ghé góc ban công thư viện nhìn ra dòng kênh Thoại Hà lộng gió, mở lại những trang viết của cô Nguyễn Ngọc Tư.

"Cánh đồng bất tận" không đơn thuần là một tác phẩm văn học Nam Bộ, mà là sự lắng đọng của những phận đời trôi nổi theo con nước ròng nước lớn. Mỗi trang văn như chở nặng hạt phù sa, nhức nhối nhưng đượm tình người.

CLB Đọc sách kỳ này xin gửi gắm chuyên đề: "Văn học miền Tây - Tiếng lòng phù sa", mời các bạn ghé tủ sách CLB để mượn và cùng đàm đạo nhé!`,
    coverImage: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&auto=format&fit=crop&q=80',
    createdAt: 'Hôm nay lúc 08:30',
    likes: 42,
    userLiked: true,
    commentsCount: 9,
    tags: ['E-News', 'VănHocMienTay', 'SachHay', 'CLBDocSach'],
    readingTimeMinutes: 4
  },
  {
    id: 'post-2',
    authorId: 'user-2',
    authorName: 'Lê Thị Ái Vy',
    authorNickname: 'Vy Mộng Mơ 🌸',
    authorAvatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    authorRole: 'Trưởng Ban Nội dung',
    authorDept: 'Nội dung',
    title: 'Học cách kiên định qua "Lối Sống Tối Giản Của Người Nhật"',
    bookTitle: 'Lối Sống Tối Giản Của Người Nhật',
    bookAuthor: 'Sasaki Fumio',
    category: 'Góc Sách AGU',
    excerpt: 'Làm thế nào để sinh viên giữ được tinh thần thanh thản, tập trung cao độ giữa mùa thi cử bận rộn nhờ tư duy tối giản.',
    content: `Giữa những áp lực bài tập nhóm, hoạt động phong trào và ôn thi cuối kỳ, đôi khi thứ chúng ta cần không phải là thêm vào, mà là buông bớt.

Cuốn sách của Sasaki Fumio đem lại cho mình một góc nhìn tươi sáng: Khi giảm bớt những đồ đạc dư thừa trong căn phòng trọ, tâm trí tự khắc có khoảng trống cho việc đọc sách, suy ngẫm và kết nối chân thật với bạn bè. 

Các thành viên CLB hãy thử dọn dẹp góc bàn học tối nay, thắp một ngọn nến thơm và mở một cuốn sách ngắn 20 trang xem sao nhé!`,
    coverImage: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=800&auto=format&fit=crop&q=80',
    createdAt: 'Hôm qua lúc 19:15',
    likes: 38,
    userLiked: false,
    commentsCount: 6,
    tags: ['GócSách', 'ToiGian', 'KyNangSong'],
    readingTimeMinutes: 3
  }
];

export const INITIAL_LOCKET_MOMENTS: LocketMoment[] = [
  {
    id: 'locket-1',
    authorName: 'Hoàng Nam',
    authorNickname: 'Nam Bút Mực 🖋️',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    department: 'Truyền thông',
    imageUrl: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=600&auto=format&fit=crop&q=80',
    caption: 'Góc đọc sách chill nhất Tầng 3 Thư viện sáng chủ nhật 🌿☕',
    location: 'Thư viện Tầng 3',
    timestamp: '15 phút trước',
    reactions: 27,
    userReacted: true
  },
  {
    id: 'locket-2',
    authorName: 'Ái Vy',
    authorNickname: 'Vy Mộng Mơ 🌸',
    authorAvatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    department: 'Nội dung',
    imageUrl: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=600&auto=format&fit=crop&q=80',
    caption: 'Tập san E-News số 12 đã hoàn thiện trang bìa vintage siêu ưng ý!',
    location: 'Phòng họp CLB',
    timestamp: '2 giờ trước',
    reactions: 34,
    userReacted: false
  }
];

export const S5T_CRITERIA_LIST: S5TCriterion[] = [
  {
    id: 'crit-1',
    name: 'Đạo đức tốt',
    description: 'Điểm rèn luyện từ 80 điểm trở lên; Không vi phạm nội quy thư viện; Tích cực tham gia diễn đàn văn hóa đọc.',
    iconName: 'ShieldCheck',
    requiredCount: 2,
    completedCount: 2,
    status: 'completed'
  },
  {
    id: 'crit-2',
    name: 'Học tập tốt',
    description: 'Điểm trung bình học tập đạt từ 8.5/10 (hoặc 80 - 85 điểm) trở lên; Có ít nhất 1 bài viết chuyên đề / cảm nhận học thuật đăng trên E-News.',
    iconName: 'GraduationCap',
    requiredCount: 2,
    completedCount: 2,
    status: 'completed'
  },
  {
    id: 'crit-3',
    name: 'Thể lực tốt',
    description: 'Đạt danh hiệu "Thanh niên khỏe" hoặc tham gia Giải chạy bộ "Run For Books" / Hoạt động thể thao sinh viên.',
    iconName: 'Activity',
    requiredCount: 1,
    completedCount: 1,
    status: 'completed'
  },
  {
    id: 'crit-4',
    name: 'Tình nguyện tốt',
    description: 'Tham gia ít nhất 2 hoạt động tình nguyện vì cộng đồng (Chiến dịch Trang Sách Vùng Cao, Tiếp sức mùa thi, Mùa hè xanh).',
    iconName: 'HeartHandshake',
    requiredCount: 2,
    completedCount: 1,
    status: 'in_progress'
  },
  {
    id: 'crit-5',
    name: 'Hội nhập tốt',
    description: 'Chứng chỉ ngoại ngữ (B1/IELTS 5.5+) hoặc tham gia Buổi giao lưu trao đổi sách quốc tế.',
    iconName: 'Globe',
    requiredCount: 1,
    completedCount: 0,
    status: 'in_progress'
  }
];

export const INITIAL_S5T_PROOFS: S5TProof[] = [
  {
    id: 'proof-1',
    studentId: 'DTH215842',
    studentName: 'Nguyễn Hoàng Nam',
    department: 'Truyền thông',
    criterionId: 'crit-4',
    criterionName: 'Tình nguyện tốt',
    activityTitle: 'Tham gia đóng gói 500 phần quà sách cho học sinh vùng cao',
    activityDate: '15/10/2026',
    proofUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=600&auto=format&fit=crop&q=80',
    proofDescription: 'Đã hoàn thành 8 giờ công tác tình nguyện tại kho sách Thư viện, có giấy xác nhận Đoàn trường.',
    status: 'pending',
    submittedAt: '24/10/2026'
  }
];

export const INITIAL_CONFIDENTIAL_REPORTS: ConfidentialReport[] = [
  {
    id: 'rep-001',
    recipientType: 'bcn_master',
    category: 'Mâu thuẫn nội bộ',
    title: 'Phản ánh về việc phân chia ca trực nhật tủ sách chưa đồng đều ở K23',
    content: 'Em xin được phép gửi riêng đến BCN. Hiện tại một số bạn thường xuyên vắng mặt vào ca trực thứ 7 khiến các bạn còn lại phải gánh việc, rất mong BCN có biện pháp sinh hoạt nhắc nhở chung kín đáo.',
    isEncrypted: true,
    encryptedCode: 'AES-256#BCN-TOPSECRET-984A1',
    realSenderName: 'Phạm Quỳnh Trâm',
    realSenderNickname: 'Trâm Kế Hoạch 📋',
    realSenderStudentId: 'DTH210342',
    realSenderDept: 'Nhân sự & Kế hoạch',
    createdAt: '24/10/2026',
    status: 'processing',
    urgency: 'high',
    bcnResponse: 'BCN sinh viên đã nắm thông tin và Ban Nhân sự & Kế hoạch sẽ điều chỉnh lại bảng phân ca vào buổi họp giao ban đầu tháng.'
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-001',
    type: 'income',
    title: 'Thu hội phí sinh hoạt Học kỳ I',
    amount: 3200000,
    category: 'Quỹ hội phí',
    date: '05/10/2026',
    performedBy: 'Phạm Quỳnh Trâm (Ban Nhân sự & Kế hoạch)',
    approvedBy: 'Lê Gia Huy (Chủ nhiệm CLB)',
    receiptCode: 'PT-2026-001',
    note: 'Thu từ 64 thành viên chính thức x 50.000đ/học kỳ'
  },
  {
    id: 'tx-002',
    type: 'income',
    title: 'Học bổng tài trợ từ Cựu sinh viên yêu sách',
    amount: 5000000,
    category: 'Tài trợ & Quyên góp',
    date: '10/10/2026',
    performedBy: 'Lê Thị Ái Vy (Ban Nội dung)',
    approvedBy: 'Lê Gia Huy (Chủ nhiệm CLB)',
    receiptCode: 'PT-2026-002',
    note: 'Tài trợ dành riêng cho tủ sách vùng cao Tri Tôn'
  },
  {
    id: 'tx-003',
    type: 'expense',
    title: 'Mua bổ sung 25 đầu sách văn học & kỹ năng từ NXB Trẻ',
    amount: 2150000,
    category: 'Mua sách mới',
    date: '14/10/2026',
    performedBy: 'Trần Minh Khang (Ban Hậu cần)',
    approvedBy: 'Lê Gia Huy (Chủ nhiệm CLB)',
    receiptCode: 'PC-2026-001',
    note: 'Hóa đơn chiết khấu 25% cho CLB sinh viên'
  }
];

export const DEPARTMENTS_DATA: ClubDepartment[] = [
  {
    id: 'Truyền thông',
    name: 'Ban Truyền Thông (Media & PR)',
    lead: 'Nguyễn Hoàng Nam',
    leadNickname: 'Nam Bút Mực 🖋️',
    leadTitle: 'Trưởng Ban Truyền Thông',
    leadAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    leadContact: 'nam.nh@agu.edu.vn | 0918.xxx.123',
    memberCount: 16,
    mission: 'Chịu trách nhiệm quản lý Fanpage CLB, biên tập ấn phẩm E-News định kỳ, thiết kế poster sự kiện, chụp ảnh Locket lưu giữ khoảnh khắc thanh xuân.',
    color: '#3B6E47',
    badges: ['E-News Editor', 'Visual Master', 'Viral Content']
  },
  {
    id: 'Nội dung',
    name: 'Ban Nội Dung',
    lead: 'Lê Thị Ái Vy',
    leadNickname: 'Vy Mộng Mơ 🌸',
    leadTitle: 'Trưởng Ban Nội Dung',
    leadAvatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    leadContact: 'vy.lta@agu.edu.vn | 0945.xxx.456',
    memberCount: 18,
    mission: 'Tuyển chọn đầu sách chất lượng, soạn thảo kịch bản các buổi sinh hoạt chuyên đề, xây dựng câu hỏi đàm đạo văn học, cùng Ban Kế Hoạch đưa ra định hướng sách của CLB.',
    color: '#C88A36',
    badges: ['Sách & Tri Thức', 'Kịch Bản Sinh Hoạt', 'Đại Sứ Văn Hóa Đọc']
  },
  {
    id: 'Nhân sự & Kế hoạch',
    name: 'Ban Nhân Sự & Kế Hoạch',
    lead: 'Phạm Quỳnh Trâm',
    leadNickname: 'Trâm Kế Hoạch 📋',
    leadTitle: 'Trưởng Ban Nhân Sự & Kế Hoạch',
    leadAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    leadContact: 'tram.pq@agu.edu.vn | 0973.xxx.321',
    memberCount: 16,
    mission: 'Ban trọng yếu! Trực tiếp cùng BCN và Ban Nội Dung lên kế hoạch hành động toàn diện, phân bổ nhân sự, theo dõi điểm danh chuỗi đọc sách, quản lý hồ sơ xét Sinh viên 5 tốt.',
    color: '#8D5B8C',
    badges: ['Kế Hoạch Chiến Lược', 'Điều Phối Nhân Lực', 'Hồ Sơ S5T Chuẩn']
  },
  {
    id: 'Hậu cần',
    name: 'Ban Hậu Cần & Tủ Sách',
    lead: 'Trần Minh Khang',
    leadNickname: 'Khang Hậu Cần 📦',
    leadTitle: 'Trưởng Ban Hậu Cần',
    leadAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    leadContact: 'khang.tm@agu.edu.vn | 0982.xxx.789',
    memberCount: 14,
    mission: 'Quản lý kho sách, mã số hóa thẻ mượn sách tầng 3 Thư viện, chuẩn bị âm thanh, máy chiếu, teabreak và quà tặng lưu niệm trong mọi sự kiện.',
    color: '#4B7B94',
    badges: ['Tủ Sách Thư Viện', 'Âm Thanh Ánh Sáng', 'Thủ Kho Đắc Lực']
  }
];

export const INITIAL_PLANS: ClubPlan[] = [
  {
    id: 'plan-1',
    title: 'Ngày Hội Đọc Sách & Đổi Sách Cũ ("Sách Trao Đi - Tri Thức Ở Lại")',
    proposedBy: 'Lê Thị Ái Vy (Trưởng Ban Nội dung)',
    department: 'Nội dung',
    description: 'Chương trình thường niên quy mô toàn trường tại Sảnh A Thư viện. Cho phép sinh viên mang sách cũ đổi sách mới, talkshow đàm đạo với diễn giả văn học Nam Bộ.',
    timeline: '15/11/2026 - 17/11/2026',
    targetAudience: 'Toàn thể sinh viên và giảng viên',
    priority: 'high',
    status: 'approved',
    budgetEstimate: 3500000,
    votesAgree: 14,
    votesDisagree: 1,
    userVoted: 'agree',
    assignedDept: 'Nhân sự & Kế hoạch',
    actionItems: [
      'Ban Nội dung: Hoàn thiện kịch bản 3 buổi đàm đạo sách',
      'Ban Truyền thông: Thiết kế bộ nhận diện & 3 video ngắn TikTok',
      'Ban Hậu cần: Bố trí 6 kệ sách trao đổi tại sảnh A thư viện',
      'Ban Nhân sự & Kế hoạch: Phân công 2 ca trực nhật mỗi ngày và lập danh sách cộng điểm SV5T'
    ]
  },
  {
    id: 'plan-2',
    title: 'Xuất bản Đặc San E-News: "Tiếng Thơ Phù Sa Miền Tây"',
    proposedBy: 'Nguyễn Hoàng Nam (Trưởng Ban Truyền thông)',
    department: 'Truyền thông',
    description: 'Ấn phẩm số tập hợp 15 bài tản văn, 5 bài điểm sách đặc sắc của sinh viên.',
    timeline: '01/11/2026 - 10/11/2026',
    targetAudience: 'Độc giả trẻ và cựu sinh viên yêu sách',
    priority: 'medium',
    status: 'in_action',
    budgetEstimate: 1200000,
    votesAgree: 12,
    votesDisagree: 0,
    userVoted: 'agree',
    assignedDept: 'Truyền thông',
    actionItems: [
      'Ban Nội dung duyệt 15 bài tản văn',
      'Ban Truyền thông dàn trang layout vintage',
      'BCN duyệt lời tựa số đặc san'
    ]
  }
];

export const INITIAL_TASKS: ClubTask[] = [
  {
    id: 'task-1',
    planId: 'plan-1',
    title: 'Biên tập kịch bản Mini-game đố vui văn học cho Ngày Hội Sách',
    assignedToDept: 'Nội dung',
    assignedToMemberName: 'Lê Thị Ái Vy',
    deadline: '05/11/2026',
    status: 'in_progress',
    rewardPoints: 50,
    description: 'Soạn 20 câu đố về văn học dân gian Tây Nam Bộ.'
  },
  {
    id: 'task-2',
    planId: 'plan-1',
    title: 'Thiết kế Standee và 5 Poster tuyên truyền Ngày Hội Sách',
    assignedToDept: 'Truyền thông',
    assignedToMemberName: 'Nguyễn Hoàng Nam',
    deadline: '03/11/2026',
    status: 'in_progress',
    rewardPoints: 60,
    description: 'Tone màu Sage Green kết hợp họa tiết hoa sen.'
  }
];

export const INITIAL_DECREES: ClubDecree[] = [
  {
    id: 'dec-1',
    title: 'LỆNH BCN: Phát động Chiến Dịch "Giữ Chuỗi 21 Ngày - Nhận Huy Hiệu Đại Sứ Sách"',
    content: 'Tất cả sinh viên duy trì chuỗi đọc liên tục trên Book Island sẽ được BCN đặc cách khen thưởng tại Đại hội CLB.',
    issuedAt: '25/10/2026',
    issuedBy: 'Lê Gia Huy - Chủ nhiệm CLB (Sinh viên)',
    type: 'urgent',
    pinToIsland: true
  }
];
